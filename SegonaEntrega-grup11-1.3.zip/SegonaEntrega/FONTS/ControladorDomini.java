import javafx.util.Pair;

import java.io.IOException;
import java.util.ArrayList;

public class ControladorDomini {

    private Usuari usuari;
    public Problema problema = new Problema();
    private Partida partida = new Partida();
    public Ranking ranking = new Ranking();

    public boolean rankingBuit() { return ranking.getPartidesguanyadores().size() == 0; }


    /**
     * Actualitza el Ranking, cada cop que s'elimini un problema o un usuari s'ha d'actualitzar el ranking
     * @throws IOException
     */
    public void actualitzaRanking() throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusG();
        ArrayList<String[]> pg = pers.llegirGTotal();
        System.out.println(pg.size());
        for(int i = 0; i<pg.size(); i++) {
            String[] enunciat;
            enunciat = pg.get(i);
            Long temps = Long.parseLong(enunciat[2]);
            Integer punt = Integer.parseInt(enunciat[1]);
            Integer idP = Integer.parseInt(enunciat[0]);
            Problema pr = getProblema(idP);
            if(pr != null) {
                Integer idH = Integer.parseInt(enunciat[3]);
                Huma h = trobaHumaa(idH);
                if(h!= null) {
                    PartidaGuanyada P = new PartidaGuanyada(temps, punt, pr, h);
                    ranking.afegirPartida(P);
                }
            }
        }
        pers.tancarArxiusG();
    }
    /**
     * Afegeix una partida guanyada a la base de dades i actualitza el ranking
     * @param pga
     * @throws IOException
     */
    public void afegirPG(PartidaGuanyada pga) throws IOException {
        Integer idP = pga.getProblema().getId();
        Integer puntuacio = pga.getPuntuacioguanyador();
        Long Temps = pga.getTemps();
        Temps = Temps/1000L;
        Integer idU = pga.getUsuariguanyador().getId();
        String[] partidaG = new String[4];
        partidaG[0] = idP.toString();
        partidaG[1] = puntuacio.toString();
        partidaG[2] = Long.toString(Temps);
        partidaG[3] = idU.toString();
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusG();
        pers.afegirPartidaG(partidaG);
        pers.tancarArxiusG();
        ranking.afegirPartida(pga);
    }

    public PartidaGuanyada getPG() { return partida.getPartidaGuanyadora(); }

    /**
     * Eliminar de la base de dades totes les partides guanyades amb l Usuari eliminat i actualitza el ranking
     * @param id
     * @throws IOException
     */
    public void eliminarPartidaGuanyadaUsuari(Integer id) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusG();
        pers.eliminarGU(id);
        pers.tancarArxiusG();
        actualitzaRanking();
    }

    /**
     * Eliminar de la base de dades totes les partides guanyades que tinguin el Problema idP i actualitza el ranking
     * @param idP
     * @throws IOException
     */
    public void eliminarPartidaGuanyadaProblema(Integer idP) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusG();
        pers.eliminarGP(idP);
        pers.tancarArxiusG();
        actualitzaRanking();
    }

    /**
     * Guardes el problema que esta carregat al controlador de Domini. Si aquest problema és existent a la base de
     * dades el modifica, si no hi és aquest és afegit.
     * @throws IOException
     */
    public void guardaProblema() throws IOException {
        ArrayList<Integer> problemesExistents = new ArrayList<>();
        problemesExistents = getIDProblemes();
        if(problema != null) {
            Integer id = problema.getId();
            Boolean nottrobat = true;
            for(Integer i = 0; i<problemesExistents.size() && nottrobat; i++) {
                if(id.equals(problemesExistents.get(i))) nottrobat = false;
            }
            String[] part = new String[3];
            Integer moviments = problema.getMoviments();
            part[0] = id.toString();
            part[1] = problema.getFEN();
            part[2] = moviments.toString();
            CtrlPersistencia pers = new CtrlPersistencia();
            pers.obrirArxius();
            if(nottrobat) pers.afegirPartida(part);
            else pers.modificarProblema(part);
            pers.tancarArxius();
        }
    }

    /**
     * Funcio que elimina un problema de la base de dades
     * @param id que es vol eliminar
     * @return torna true si s'ha eliminat
     * @throws IOException
     */
    public Boolean eliminarProblema(Integer id) throws IOException {
        ArrayList<Integer> problemesExistents = new ArrayList<>();
        problemesExistents = getIDProblemes();
        Boolean nottrobat = true;
        for(Integer i = 0; i<problemesExistents.size() && nottrobat; i++) {
            if(id.equals(problemesExistents.get(i))) nottrobat = false;
        }
        if(!nottrobat) {
            CtrlPersistencia d = new CtrlPersistencia();
            d.obrirArxius();
            d.eliminarP(id);
            eliminarPartidaGuanyadaProblema(id);
            return true;
        }
        return false;
    }

    /**
     *
     * @return  Retorna totes les id que estan associades a un problema creat a la base de dades.
     * @throws IOException
     */
    public ArrayList<Integer> getIDProblemes() throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxius();
        return pers.retornaTotesId();
    }

    /**
     *
     * @param id Id del problema que es vol carregar.
     * @return Si la id del problema no existeix retorna false.
     * @throws IOException
     */
    public Problema getProblema(Integer id) throws IOException {
        Problema prob = new Problema();
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxius();
        String[] enunciat = pers.llegirProblema(id);
        pers.tancarArxius();
        if(enunciat == null) return null;
        else {
            Integer moviments = Integer.parseInt(enunciat[2]);
            prob.setMovimentss(moviments);
            if(prob.setFEN(enunciat[1]) != 1) return null;
            prob.setId(Integer.parseInt(enunciat[0]));
            problema = prob;
            return prob;
        }
    }

    /**
     * Al pasar-li els parametres aquesta funció comprova que el fen esta ben escrit i si es pot fer el problema
     * Amb el número de moviments establerts. Si es pot fer genera el problema.
     * @param fen El fen que es vol afegir
     * @param moviments El numero de moviments
     * @return Retorna -1 si el fen es incorrecte, -2 si no es pot fer el problema amb el numero de moviments donats
     * I retorna 0 si s'ha pogut crear el problema
     * @throws IOException
     */
    public Integer insertarProblema(String fen, Integer moviments, Integer Id) throws IOException {
        Problema prob = new Problema();
        if (prob.setFEN(fen).equals(-1)) return -1;
        Integer a = prob.setMoviments(moviments);
        System.out.println(a);
        if(a != 0) return -2;
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxius();
        if(Id== 0) prob.setId(pers.retornaIdDisponible());
        else prob.setId(Id);
        System.out.println(prob.getId());
        pers.tancarArxius();
        String comenca;
        if(prob.isStart()) comenca = "Blanques";
        else comenca = "Negres";
        prob.setEnunciat("Escac en "+ moviments + " moviments per les " + comenca + ", hi ha " + prob.getPecesblanques() + " peces blanques i "
                + prob.getPecesnegres() + " peces negres. %n Té una Dificultat " + prob.getDificultat() + " i té la id "+ prob.getId());
        System.out.printf(prob.getEnunciat()+ "%n %n");
        problema = prob;
        return 0;
    }

    /**
     * Creació d'un usuari Humà
     * @param nom Nom de l'usuari
     * @param contra contrasenya de l'usuari
     * @throws IOException
     */
    public Boolean crearUsuari(String nom, String contra) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusH();
        Integer id = pers.retornaIdDispH();
        String[] part = new String[3];
        part[0] = id.toString();
        part[1] = nom;
        part[2] = contra;
        if(pers.existeixHuma(nom)) {
            pers.afegirHuma(part);
            pers.tancarArxiusH();
            return true;
        }
        return false;
    }

    /**
     *
     * @param id de l'usuari que es vol buscar
     * @return Un usuari Huma
     * @throws IOException
     */
    public void trobaHuma(Integer id) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusH();
        String[] enunc = pers.llegirHuma(id);
        Huma h = new Huma(true);
        h.setHuma(enunc[1], enunc[2], id);
        pers.tancarArxiusH();
        this.usuari = h;
    }

    public Huma trobaHumaa(Integer id) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusH();
        String[] enunc = pers.llegirHuma(id);
        Huma h = new Huma(true);
        h.setHuma(enunc[1], enunc[2], id);
        pers.tancarArxiusH();
        return h;
    }

    /**
     * Retorna un Usuari al pasar-li el nom i la contrasenya d'aquest, només si aquesta convinació existeix a la base
     * de dades, sino retornara null
     * @param nom
     * @param contra
     * @return
     * @throws IOException
     */
    public Integer trobaHumaNC(String nom, String contra) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusH();
        String[] enunc = pers.llegirHumaNC(nom, contra);
        if(enunc == null) return null;
        Integer id = Integer.parseInt(enunc[0]);
        Huma h = new Huma(true);
        h.setHuma(nom, contra, id);
        pers.tancarArxiusH();
        return id;
    }

    /**
     * Elimina l'usuari amb id
     * @param id
     * @return
     * @throws IOException
     */
    public boolean eliminaHuma(Integer id) throws IOException {
        CtrlPersistencia pers = new CtrlPersistencia();
        pers.obrirArxiusH();
        ArrayList<Integer> hExistents = new ArrayList<>();
        hExistents = pers.retornaTotesIdH();
        Boolean nottrobat = true;
        for(Integer i = 0; i<hExistents.size() && nottrobat; i++) {
            if(id.equals(hExistents.get(i))) nottrobat = false;
        }
        if(nottrobat) return false;
        pers.eliminarH(id);
        eliminarPartidaGuanyadaUsuari(id);
        return true;
    }

    public void setPartida(int modalitat) {
        Usuari u1, u2;

        if (usuari == null) usuari = new Huma(true);

        if (modalitat == 0) {
            if (problema.isStart()) { u1 = usuari; u2 = new Huma(false); }
            else { u2 = usuari; u1 = new Huma(false); }
        }
        else if (modalitat == 1) {
            if (problema.isStart()) { u1 = usuari; u2 = new MaquinaGreedy(false); }
            else { u2 = usuari; u1 = new MaquinaGreedy(false); }
        }
        else if (modalitat == 2) {
            if (problema.isStart()) { u1 = usuari; u2 = new MaquinaSmart(false); }
            else { u2 = usuari; u1 = new MaquinaSmart(false); }
        }
        else if (modalitat == 3) {
            if (problema.isStart()) { u1 = new MaquinaSmart(true); u2 = new MaquinaGreedy(false); }
            else { u2 = new MaquinaSmart(true); u1 = new MaquinaGreedy(false); }
        }
        else if (modalitat == 4) {
            if (problema.isStart()) { u1 = new MaquinaGreedy(true); u2 = new MaquinaSmart(false); }
            else { u2 = new MaquinaGreedy(true); u1 = new MaquinaSmart(false); }
        }
        else if (modalitat == 5) {
            u1 = new MaquinaGreedy(problema.isStart());
            u2 = new MaquinaGreedy(!problema.isStart());
        }
        else {
            u1 = new MaquinaSmart(problema.isStart());
            u2 = new MaquinaSmart(!problema.isStart());
        }
        partida.inicialitzarPartida(u1, u2, problema);
    }

    public ArrayList<ArrayList<Character>> getTaulellActual() {
        return partida.getEstatsTaulell().get(partida.getEstatsTaulell().size()-1);
    }
    public ArrayList<ArrayList<Character>> getTaulellIndex(Integer i) throws IndexOutOfBoundsException {
        return partida.getEstatsTaulell().get(i);
    }

    public boolean comprovarTorn() {
        return partida.getTorn_actual();
    }

    public ArrayList<Pair<Integer, Integer>> marcarMoviments(Integer PosX, Integer PosY) {
        return partida.marcarMoviments(PosX, PosY);
    }

    public boolean realitzarMoviment(ArrayList<Integer> moviments) throws Exception { return partida.moviment(moviments); }

    public boolean realitzarMovimentMaquina() { return partida.movimentMaquina(); }

    public boolean guanyada() { return partida.getEndGame(); }

    public void stopTimers() { partida.afegirTempsTranscorregut(false); }

    public void resumeTimers() { partida.setMoment_final(System.currentTimeMillis()); }

    public ArrayList<ArrayList<Character>> getTaulellProblema() { return problema.getMatrix(); }

}
