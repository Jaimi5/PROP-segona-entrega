import java.util.ArrayList;
import java.util.Scanner;

public class DriverMaquinaGreedy {

    public static void main(String[] args) throws Exception {
        Taulell t = new Taulell();
        MaquinaGreedy usuari = new MaquinaGreedy(true);
        Scanner input = new Scanner(System.in);
        System.out.println("DRIVER DE LA CLASSE MaquinaGreedy" + "\n");
        System.out.println("Introdueix el taulell de 8x8" + "\n");
        t = introdueixTaulell();
        System.out.println("Escull una funció a provar");
        System.out.println("1. provaFerMoviment");



        imprimeixTaulell(t.getTaulell());
        t.inicialitzarTaulell(t.getTaulell());
        Integer opcion = 0;
        opcion = input.nextInt();
        switch(opcion){
            case 1:
                provaFerMoviment(usuari, t);
                break;

        }

    }

    private static void provaFerMoviment(MaquinaGreedy usuari, Taulell t){
        Scanner input = new Scanner(System.in);
        System.out.println("Introdueix 1 per fer el moviment de les NEGRES i 2 per el de les BLANQUES \n");
        Integer i = input.nextInt();
        Boolean tornNegres;
        if(i.equals(1))tornNegres = true;
        else tornNegres = false;
        Integer profundidad = 5;
        Taulell aux = new Taulell(t);
        Boolean torn = tornNegres;
        for(int ii = 0; ii < profundidad ; ++ii){

            ArrayList<Integer> movimentAFer = usuari.getMoviment(aux, torn, profundidad);
            torn = !torn;
            aux.ferMoviment(movimentAFer);
            System.out.println("MOVIMENT " + (ii +1) + ": \n");
            System.out.println("\n" + "Coordenades inicials:  \n");

            for(int j = 0; j < 2; ++j){
                System.out.println(movimentAFer.get(j) + " ");
            }
            System.out.println("\n" + "Coordenades finals:  \n");
            for(int j = 2; j < 4; ++j){
                System.out.println(movimentAFer.get(j) + " ");
            }

        }


    }

    public static Taulell introdueixTaulell(){

        Scanner input = new Scanner(System.in);
        Taulell taulell = new Taulell();
        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                Character c = input.next().charAt(0);
                taulell.getTaulell().get(i).set(j, c);
            }
        }
        return taulell;
    }
    private static void imprimeixTaulell(ArrayList<ArrayList<Character>> matrix){
        System.out.printf("\n");
        System.out.println("   0 1 2 3 4 5 6 7");
        for(int i = 0; i < 8; ++i){
            System.out.print(i + " ");
            for(int j = 0; j < 8; ++j){
                System.out.printf(" %s", matrix.get(i).get(j));
            }
            System.out.printf("%n");
        }
        System.out.println("\n");
    }


    }




