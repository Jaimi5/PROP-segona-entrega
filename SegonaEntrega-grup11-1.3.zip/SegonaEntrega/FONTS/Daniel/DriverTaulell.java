import javafx.util.Pair;

import java.util.ArrayList;
import java.util.Scanner;


public class DriverTaulell {

    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        //int number = input.nextInt();
        System.out.println("DRIVER DE LA CLASSE TAULELL" + "\n");
        System.out.println("Introdueix el taulell de 8x8" + "\n");
        Taulell t = new Taulell();
        t = introdueixTaulell();
        imprimeixTaulell(t.getTaulell());


        System.out.println("Escull una funció a provar:");
        System.out.println("1.  movimentPossible");
        System.out.println("2.  escacImat");
        System.out.println("3.  potArribar");
        System.out.println("4.  totsMoviments");
        System.out.println("5.  esNegre");
        System.out.println("6.  buscaPeca");
        System.out.println("7.  ferMoviment");
        System.out.println("8.  heuristic");
        System.out.println("9.  peçaAliada");
        System.out.println("10. peçaEnemiga");
        System.out.println("11. inicialitzarTaulell");
        System.out.println("12. Taulell(Taulell copiar)");
        System.out.println("13. escac");
        System.out.println("14. ferMovimentIntensiu");
        System.out.println("15. reiViu");
        System.out.println("16. marcarMoviments");
        System.out.println("17. movimentsRei");


        Integer opcion = 0;
        opcion = input.nextInt();
        switch(opcion){
            case 1:
                provaMovimentPosible(t);//FUNCIONA BÉ
                break;
            case 2:
                provaEscacImat(t); // FUNCIONA BÉ
                break;
            case 3:
                provaPotArribar(t);//FUNCIONA BÉ
                break;
            case 4:
                provaTotsMoviments(t);//FUNCIONA BÉ
                break;
            case 5:
                provaEsNegre(t); //FUNCUONA BÉ
                break;
            case 6:
                provaBuscaPeca(t); //FUNCIONA BÉ
                break;
            case 7:
                provaFerMoviment(t); //FUNCIONA BÉ
                break;
            case 8:
                provaHeuristic(t);//FUNCIONA BÉ
                break;
            case 9:
                provaPeçaAliada(t);//FUNCIONA BÉ
                break;
            case 10:
                provaPeçaEnemiga(t);//FUNCIONA BÉ
                break;
            case 11:
                provaInicialitzarTaulell(t); //FUNCIONA BÉ
                break;

            case 12:
                provaTaulell(t); //FUNCIONA BÉ
                break;

            case 13:
                provaEscac(t);
                break;
            case 14:
                provaFerMovimentIntensiu(t);
                break;
            case 15:
                provareiViu(t);
            case 16:
                provaMarcarMoviments(t);
            case 17:
                provaMovimentsRei(t);
                break;
        }

    }

    private static void provaMovimentsRei(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Integer res = t.movimentsRei(true);
        System.out.println("El rei negre pot fer " + res + " moviments.");
        res = t.movimentsRei(false);
        System.out.println("El rei blanc pot fer " + res + " moviments.");

    }
    private static void provaMarcarMoviments(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        System.out.println("Introdueix les coordenades que de la peça de la qual vols conéixer els seus moviments posibles: ");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        Integer y = input.nextInt();
        ArrayList<Pair<Integer,Integer>> res = t.marcarMoviments(x,y);
        System.out.println("Posicions a les que pot arribar desde la posició " + x + " " + y + "\n");
        for(int i = 0; i < res.size(); ++i){
            System.out.println(res.get(i).getKey() + " " + res.get(i).getValue());
        }
    }
    private static void provareiViu(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        System.out.println("Indtrodueix 1 per mirar si esta viu el rei NEGRE i 2 per mirar el BLANC");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        Boolean tornNegres;
        if(x.equals(1))tornNegres = true;
        else tornNegres = false;
        if(t.reiViu(tornNegres))System.out.println("El rei esta VIU");
        else System.out.println("El rei esta MORT");
    }
    private static Integer contaNegres(Taulell t){
       Integer ret = 0;
        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                if(Character.isLetter(t.getTaulell().get(i).get(j))){
                    if(Character.isLowerCase(t.getTaulell().get(i).get(j)))++ret;
                }
            }
        }
        return ret;
    }

    private static Integer contaBlanques(Taulell t){
        Integer ret = 0;
        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                if(Character.isLetter(t.getTaulell().get(i).get(j))){
                    if(Character.isUpperCase(t.getTaulell().get(i).get(j)))++ret;
                }
            }
        }
        return ret;
    }

    private static void provaFerMovimentIntensiu(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Boolean tornNegres;
        System.out.println("Introdueix 1 per que comencin les negres y 2 per les blanques");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        if(x.equals(1))tornNegres = true;
        else tornNegres = false;
        i_provaFerMovimentIntensiu(t,tornNegres,0);


    }

    private static void i_provaFerMovimentIntensiu(Taulell t, Boolean tornNegres, Integer profunditat){
       if(profunditat.equals(4)){
           return;
       }
        ArrayList<ArrayList<Integer>> movimentsPosibles = t.totsMoviments(tornNegres);
        for(int i = 0; i < movimentsPosibles.size(); ++i){
            Taulell nouTaulell = new Taulell(t);
            nouTaulell.ferMoviment(movimentsPosibles.get(i));
            t.escacImat(tornNegres);
            if(!contaNegres(nouTaulell).equals(nouTaulell.getNegres().size()))System.out.println("ERROR NEGRES i = "+ i + "\n");
            if(!contaBlanques(nouTaulell).equals(nouTaulell.getBlanques().size()))System.out.println("ERROR BLANQUES i = "+ i + "\n");
            i_provaFerMovimentIntensiu(nouTaulell, !tornNegres, profunditat + 1);

        }
    }

    private static void provaEscac(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Boolean atacaNegre;
        System.out.println("Introdueix 1 si els atacants son els Negres, 2 si són les Blanques: ");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        if(x.equals(1))atacaNegre = true;
        else atacaNegre = false;
        Boolean escac = t.escac(atacaNegre);
        if(escac)System.out.println("Escac al rei defensor");
        else System.out.println("NO hi ha escac");
    }

    private static void provaEscacImat(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Boolean atacaNegre;
        Scanner input = new Scanner(System.in);
        System.out.println("Introdueix 1 si els atacants son els Negres, 2 si són les Blanques: ");
        Integer x = input.nextInt();
        if(x.equals(1))atacaNegre = true;
        else atacaNegre = false;
        Boolean escacmat = t.escacImat(atacaNegre);
        if(escacmat)System.out.println("Escac i mat al rei defensor");
        else System.out.println("NO hi ha escac i mat");
    }

    private static void provaMovimentPosible(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Scanner input = new Scanner(System.in);
        System.out.println("Introdueix les coordenades inicials i finals de la peça que vols moure: ");
        Integer inix = input.nextInt();
        Integer iniy = input.nextInt();
        Integer finx = input.nextInt();
        Integer finy = input.nextInt();
        while(inix != -1){
            Peca p = null;
            if(t.getTaulell().get(inix).get(iniy) != '/') p = t.buscaPeca(inix,iniy);
            Pair<Boolean, Character> ret = t.movimentPosible(inix, iniy, finx, finy);
            if(ret.getKey()){
                System.out.printf("S'ha fet el moviment. \n");
                if(!ret.getValue().equals('/')){
                    System.out.printf("S'ha matat a : " + ret.getValue() + "\n");
                    Peca pp = t.buscaPeca(finx,finy);
                    if(pp == p)System.out.println("s'ha eliminat la peça matada.");
                }
                if(p.getCoordX().equals(finx) && p.getCoordY().equals(finy))System.out.println("S'han actualitzat correctament les coordenades de la Peça. \n");
                System.out.printf("El taulell ha quedat així: \n");
                imprimeixTaulell(t.getTaulell());
            }
            else System.out.printf("NO s'ha fet el moviment \n");
            System.out.println("Introdueix les coordenades inicials i finals de la peça que vols moure: ");

             inix = input.nextInt();
             iniy = input.nextInt();
             finx = input.nextInt();
             finy = input.nextInt();

        }


    }

    private static void provaPotArribar(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        System.out.println("Introdueix les coordenades inicials i finals de la peça que vols moure: ");
        Scanner input = new Scanner(System.in);
        Integer inix = input.nextInt();
        Integer iniy = input.nextInt();
        Integer finx = input.nextInt();
        Integer finy = input.nextInt();
        while(inix != -1) {
            Boolean potarribar = t.potArribar(inix, iniy, finx, finy);
            if (potarribar) System.out.println("La peça pot arribar \n");
            else System.out.println("La peça NO pot arribar \n");
             inix = input.nextInt();
             iniy = input.nextInt();
             finx = input.nextInt();
             finy = input.nextInt();
        }
    }

    private static void provaTotsMoviments(Taulell t) {
        t.inicialitzarTaulell(t.getTaulell());
        System.out.println("Escull 1 per generar els moviments possibles de les NEGRES i 2 per els de les BLANQUES");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        Boolean Negres = false;
        if(x.equals(1)) Negres = true;
        else if(x.equals(2)) Negres = false;
        ArrayList< ArrayList<Integer>> res = t.totsMoviments(Negres);
        System.out.println("AQUESTS SÓN ELS MOVIMENT:\n");
        for(int i = 0; i < res.size(); ++i){
            System.out.println("iniX: " + res.get(i).get(0) + "  iniY: " + res.get(i).get(1) + "     ");
            System.out.println("finX: " + res.get(i).get(2) + "  finY: " + res.get(i).get(3) + "\n");
        }
    }


    //PRIVATE FUNCTIONS

    private static void provaHeuristic(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Integer resultat = t.heuristic();
        System.out.printf("Aques és el valor del Heurístic: " + resultat + "\n");
    }
    private static void provaPeçaAliada(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        System.out.printf("Escull una peça introduint les eves coordenades: \n");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        Integer y = input.nextInt();
        Boolean negre = null;
        System.out.printf("Escull 1 per ser NEGRE i 2 per ser BLANC \n");
        Integer z = input.nextInt();
        if(z.equals(1)) negre = true;
        if (z.equals(2)) negre = false;
        while(!x.equals(-1)){


            Boolean Aliada = t.peçaAliada(x,y, negre);
            if(Aliada)System.out.printf("La peça és ALIADA \n");
            else System.out.printf("La peça és ENEMIGA \n");
            x = input.nextInt();
            y = input.nextInt();
            z = input.nextInt();
            if(z.equals(1)) negre = true;
            if (z.equals(2)) negre = false;
        }
    }

    private static void provaPeçaEnemiga(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        System.out.printf("Escull una peça introduint les eves coordenades: \n");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        Integer y = input.nextInt();

        Boolean negre = null;
        System.out.printf("Escull 1 per ser NEGRE i 2 per ser BLANC \n");
        Integer z = input.nextInt();
        if(z.equals(1)) negre = true;
        if (z.equals(2)) negre = false;
        while(!x.equals(-1)){

            Boolean Enemiga = t.peçaEnemiga(x,y,negre);
            if(Enemiga)System.out.printf("La peça és ENEMIGA \n");
            else System.out.printf("La peça és ALIADA \n");
            x = input.nextInt();
            y = input.nextInt();
            z = input.nextInt();
            if(z.equals(1)) negre = true;
            if (z.equals(2)) negre = false;
        }
    }
    private static void provaEsNegre(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        System.out.printf("Escull una peça introduint les eves coordenades: \n");
        Scanner input = new Scanner(System.in);
        Integer x = input.nextInt();
        Integer y = input.nextInt();
        while(!x.equals(-1)){

            Boolean Negre = t.esNegre(x,y);
            if(Negre)System.out.printf("La peça és NEGRE \n");
            else System.out.printf("La peça és BLANCA \n");
            x = input.nextInt();
            y = input.nextInt();
        }

    }
    private static void provaBuscaPeca(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Scanner input = new Scanner(System.in);
        System.out.printf("Introdueix les coordenades de la peça que vols buscar" + "\n");
        Integer x = input.nextInt();
        Integer y = input.nextInt();
        Peca p = t.buscaPeca(x,y);
        System.out.printf("AQUESTES SÓN LES SEVES COORDENADES: " + p.CoordX + "  " + p.CoordY + "\n");
    }
    private static void provaFerMoviment(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        ArrayList<Integer> Coord = new ArrayList<>();
        System.out.printf("INTRODUEIX LES COORDENADES INICIALS I FINALS" + "\n");
        Scanner input = new Scanner(System.in);
        Coord.add(input.nextInt());
        Coord.add(input.nextInt());
        Coord.add(input.nextInt());
        Coord.add(input.nextInt());
        System.out.printf("Aquest és el taulell abans de fer el moviment: " + "\n");
        imprimeixTaulell(t.getTaulell());
        System.out.printf("\n");
        Taulell nouT = new Taulell(t);
        nouT.ferMoviment(Coord);
        System.out.printf("Aquest és el taulell després de fer el moviment: " + "\n");
        imprimeixTaulell(nouT.getTaulell());

    }
    private static void provaInicialitzarTaulell(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());

        System.out.printf("Size Blanques: " + t.getBlanques().size() + "\n");
        System.out.printf("Size Negres: " + t.getNegres().size() + "\n");
    }
    public static Taulell introdueixTaulell(){

        Scanner input = new Scanner(System.in);
        Taulell taulell = new Taulell();

        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                Character c = input.next().charAt(0);
                taulell.getTaulell().get(i).set(j, c);
            }
        }
        return taulell;
    }
    private static void imprimeixTaulell(ArrayList<ArrayList<Character>> matrix){
        System.out.printf("\n");
        System.out.println("   0 1 2 3 4 5 6 7");
        for(int i = 0; i < 8; ++i){
            System.out.print(i + " ");
            for(int j = 0; j < 8; ++j){
                System.out.printf(" %s", matrix.get(i).get(j));
            }
            System.out.printf("%n");
        }
        System.out.println("\n");
    }
    private static void provaTaulell(Taulell t){
        t.inicialitzarTaulell(t.getTaulell());
        Taulell tnou = new Taulell(t);
        Boolean igual = true;
        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                if(!t.getTaulell().get(i).get(j).equals(tnou.getTaulell().get(i).get(j)))igual = false;

            }
        }
        Integer tsize = t.getBlanques().size();
        Integer tnouSize = tnou.getBlanques().size();
        if(!tsize.equals(tnouSize))igual = false;
        tsize = t.getNegres().size();
        tnouSize = tnou.getNegres().size();
        if(!tsize.equals(tnouSize))igual = false;
        for(int i = 0; i < t.getBlanques().size(); ++i){
            if(!t.getBlanques().get(i).CoordX.equals(tnou.getBlanques().get(i).CoordX))igual = false;
            if(!t.getBlanques().get(i).CoordY.equals(tnou.getBlanques().get(i).CoordY))igual = false;
        }
        for(int i = 0; i < t.getNegres().size(); ++i){
            if(!t.getNegres().get(i).CoordX.equals(tnou.getNegres().get(i).CoordX))igual = false;
            if(!t.getNegres().get(i).CoordY.equals(tnou.getNegres().get(i).CoordY))igual = false;
        }
        if(igual)System.out.println("És una copia exacte");
        else System.out.println("NO és una copia exacte");
    }



}

