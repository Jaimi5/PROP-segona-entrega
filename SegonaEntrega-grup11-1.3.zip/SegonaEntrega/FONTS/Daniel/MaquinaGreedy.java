import com.sun.org.apache.xpath.internal.operations.Bool;
import javafx.util.Pair;
import java.util.ArrayList;
/*la màquina edtúpida només es defensa a no ser que no hi hagi cap amenaça.
    1. Demanem els possibles moviments del  contrincant amb totes les seves peces.
    2. Comprovem amb només els tipus de peça que té el contricant on ens poden perjudicar.
    3. Comprovem si als possibles moviments de la peça corresponent hiha alguna de les posicions perjudicials.
     */

public class MaquinaGreedy extends Maquina {


    private Integer profunditatInicial;
    private ArrayList<Integer> millorMoviment;

    public MaquinaGreedy(boolean atacant) {
        this.atacant = atacant;
    }

    public ArrayList<Integer> ferMoviment(Taulell tActual, Boolean tornNegres, Integer N){
        Integer profunditat = 3;
        profunditatInicial = profunditat;
        Integer result = i_ferMovimentGreedy(tActual, tornNegres, profunditat);
        return millorMoviment;
    }

    private Integer i_ferMovimentGreedy(Taulell tActual, Boolean tornNegres, Integer profunditat){
        if(profunditat == 0 ){
            return tActual.heuristic();
        }
        else{
            if(tornNegres){//MAXIMITZAR
                Integer millorTaulell = -10000;
                ArrayList<ArrayList<Integer>> movimentsPosibles = tActual.totsMoviments(tornNegres);
                if(movimentsPosibles.size() == 0){

                    return i_ferMovimentGreedy(tActual, !tornNegres, 1);
                }
                else{
                    for(int i = 0; i < movimentsPosibles.size(); ++i){
                        Taulell nouTaulell = new Taulell(tActual);
                        nouTaulell.ferMoviment(movimentsPosibles.get(i));
                        Integer res = i_ferMovimentGreedy(nouTaulell, !tornNegres, profunditat - 1);
                        if(res > millorTaulell){
                            millorTaulell = res;
                            if(profunditatInicial.equals(profunditat)){
                                millorMoviment = movimentsPosibles.get(i);
                            }
                        }
                    }
                    return millorTaulell;
                }

            }
            else{//MINIMITZAR
                Integer millorTaulell = 10000;
                ArrayList<ArrayList<Integer>> movimentsPosibles = tActual.totsMoviments(tornNegres);
                if(movimentsPosibles.size() == 0){
                    return i_ferMovimentGreedy(tActual, !tornNegres, 1);
                }
                else{
                    for(int i = 0; i < movimentsPosibles.size(); ++i){
                        Taulell nouTaulell = new Taulell(tActual);
                        nouTaulell.ferMoviment(movimentsPosibles.get(i));
                        Integer res = i_ferMovimentGreedy(nouTaulell, !tornNegres, profunditat - 1);
                        if(res < millorTaulell){
                            millorTaulell = res;
                            if(profunditatInicial.equals(profunditat)){
                                millorMoviment = movimentsPosibles.get(i);
                            }
                        }
                    }
                    return millorTaulell;
                }

            }
        }
    }
}


/*
if(movimentsPosibles.size() == 0){
                    return i_ferMovimentGreedy(tActual, !tornNegres, 1);
                }
 */

/*
public class MaquinaGreedy extends Maquina {



    public ArrayList<ArrayList<Integer>> Cami = new ArrayList<>();

    public ArrayList<ArrayList<Integer>> getCami(){
        return this.Cami;
    }

    public MaquinaGreedy(boolean atacant) {
        this.atacant = atacant;
    }

    private Pair<ArrayList<Integer>, Integer> i_ferMovimentGreedy(Taulell tActual, Boolean tornNegres, Integer profunditat, ArrayList<Integer> movimentActual){
        if(profunditat == 0){
            Pair<ArrayList<Integer>, Integer> ret = new Pair(movimentActual, tActual.heuristic());
            return ret;
        }
        else{
            if(tornNegres){//MAXIMITZAR
                Integer millorTaulell = -100000;
                ArrayList<Integer> millorMoviment = new ArrayList<>();
                ArrayList< ArrayList<Integer>> movimentsPossibles = tActual.totsMoviments(tornNegres);
                Integer sizeMovimentsPossibles = movimentsPossibles.size();
                if(sizeMovimentsPossibles.equals(0)){
                    Taulell nouTaulell = new Taulell(tActual);
                    Pair<ArrayList<Integer>, Integer> aux;
                    aux = i_ferMovimentGreedy(nouTaulell, !tornNegres, 1, movimentActual);
                    Pair<ArrayList<Integer>, Integer> ret = new Pair<>(aux.getKey(),aux.getValue());
              //      Cami.add(0,millorMoviment);
                    return ret;

                }
                else{
                    for(int i = 0; i < movimentsPossibles.size(); ++i) {
                        Pair<ArrayList<Integer>, Integer> aux;

                        // creo nou taulell auxiliar per fer els moviments.
                        Taulell nouTaulell = new Taulell(tActual);
                        nouTaulell.ferMoviment(movimentsPossibles.get(i));
                        aux = i_ferMovimentGreedy(nouTaulell, !tornNegres, 1, movimentsPossibles.get(i));
                        if (aux.getValue() > millorTaulell){
                            millorMoviment = new ArrayList<>(movimentsPossibles.get(i));
                            millorTaulell = new Integer(aux.getValue());
                        }
                    }
                    Pair<ArrayList<Integer>, Integer> ret = new Pair<>(millorMoviment,millorTaulell);
               //     Cami.add(0,millorMoviment);
                    return ret;
                }


            }
            else{//MINIMITZAR
                Integer millorTaulell = 100000;
                ArrayList<Integer> millorMoviment = new ArrayList<>();
                ArrayList< ArrayList<Integer>> movimentsPossibles = tActual.totsMoviments(tornNegres);
                Integer sizeMovimentsPossibles = movimentsPossibles.size();
                if(sizeMovimentsPossibles.equals(0)) {
                    Taulell nouTaulell = new Taulell(tActual);
                    Pair<ArrayList<Integer>, Integer> aux;
                    aux = i_ferMovimentGreedy(nouTaulell, !tornNegres, profunditat - 1, movimentActual);
                    Pair<ArrayList<Integer>, Integer> ret = new Pair<>(aux.getKey(),aux.getValue());
               //     Cami.add(0,millorMoviment);
                    return ret;
                }
                else{

                    for(int i = 0; i < movimentsPossibles.size(); ++i){
                        Pair<ArrayList<Integer>, Integer> aux;
                        // creo nou taulell auxiliar per fer els moviments.
                        Taulell nouTaulell = new Taulell(tActual);
                        nouTaulell.ferMoviment(movimentsPossibles.get(i));
                        aux = i_ferMovimentGreedy(nouTaulell, !tornNegres, profunditat - 1, movimentsPossibles.get(i));
                        if (aux.getValue() < millorTaulell){
                            millorMoviment = new ArrayList<>(movimentsPossibles.get(i));
                            millorTaulell = new Integer(aux.getValue());
                        }
                    }
                    Pair<ArrayList<Integer>, Integer> ret = new Pair<>(millorMoviment,millorTaulell);
                   // Cami.add(0,millorMoviment);
                    return ret;
                }

            }
        }
    }
}
*/