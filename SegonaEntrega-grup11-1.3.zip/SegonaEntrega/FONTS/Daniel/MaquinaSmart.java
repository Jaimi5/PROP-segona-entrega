import javafx.util.Pair;

import java.util.ArrayList;

public class MaquinaSmart extends Maquina {

    private Integer profunditatInicial;
    private ArrayList<Integer> millorMoviment;

    public MaquinaSmart(boolean atacant) {
        this.atacant = atacant;
    }

    public Boolean validar(Taulell tActual, Boolean tornNegres, Integer N){
        Integer profunditat = (N*2)-1;

        profunditatInicial = profunditat;

        //   System.out.println("NODES :" + nodes);
        Boolean escacimat = false;
        ArrayList<ArrayList<Integer>> moviments = tActual.totsMoviments(tornNegres);
        if (tornNegres) {//MAXIMITZAR
            Integer millorTaulell = -10000;
            for (int i = 0; i < moviments.size() && !escacimat; ++i) {

                Taulell nouTaulell = new Taulell(tActual);
                nouTaulell.ferMoviment(moviments.get(i));
                Pair<Integer, Boolean> result = i_ferMovimentSmartN(nouTaulell, !tornNegres, profunditat - 1, true);
                if (result.getValue()) {
                    return true;
                }
            }

            return false;
        } else {//MINIMITZAR
            Integer millorTaulell = 10000;
            for (int i = 0; i < moviments.size() && !escacimat; ++i) {

                Taulell nouTaulell = new Taulell(tActual);
                nouTaulell.ferMoviment(moviments.get(i));
                Pair<Integer, Boolean> result = i_ferMovimentSmartB(nouTaulell, !tornNegres, profunditat - 1,  true);
                if (result.getValue()) {
                    return true;
                }
            }
            return false;
        }

    }

    private Pair<Integer, Boolean> i_ferMovimentSmartN(Taulell tActual, Boolean tornNegres, Integer profunditat, Boolean totsT) {
        if (profunditat.equals(0)) {

            if (tActual.escacImat(!tornNegres)) return new Pair<>(tActual.heuristic(), true);
            else {
/*
                if (tornNegres) {
                    if (tActual.escac(tornNegres)) return new Pair<>(tActual.heuristic() + 10000, false);
                } else {
                    if (tActual.escac(tornNegres)) return new Pair<>(tActual.heuristic() - 10000, false);
                }
*/
                return new Pair<>(tActual.heuristic(), false);
            }
        } else {
            if (tornNegres) {//MAXIMITZAR
                Integer millorTaulell = -10000;

                Boolean escac = false;
                ArrayList<ArrayList<Integer>> moviments = tActual.totsMoviments(tornNegres);
                for (int i = 0; i < moviments.size() && !escac; ++i) {
                    Taulell nouTaulell = new Taulell(tActual);
                    nouTaulell.ferMoviment(moviments.get(i));
                    Pair<Integer, Boolean> res = i_ferMovimentSmartN(nouTaulell, !tornNegres, profunditat - 1, true);
                    if (millorTaulell < res.getKey()) {
                        millorTaulell = res.getKey();
                    }
                    if (res.getValue()) escac = true;


                }
                return new Pair<>(millorTaulell, escac);
            } else {//MINIMITZAR
                Integer millorTaulell = 10000;
                ArrayList<ArrayList<Integer>> moviments = tActual.totsMoviments(tornNegres);
                Boolean totsEscac = true;
                for (int i = 0; i < moviments.size(); ++i) {
                    Taulell nouTaulell = new Taulell(tActual);
                    nouTaulell.ferMoviment(moviments.get(i));
                    Pair<Integer, Boolean> res = i_ferMovimentSmartN(nouTaulell, !tornNegres, profunditat - 1,  true);
                    if (millorTaulell > res.getKey()) {
                        millorTaulell = res.getKey();
                    }
                    if (!res.getValue()) totsEscac = false;
                }
                return new Pair<>(millorTaulell, totsEscac);
            }
        }
    }

    private Pair<Integer, Boolean> i_ferMovimentSmartB(Taulell tActual, Boolean tornNegres, Integer profunditat, Boolean totsT) {
        if (profunditat.equals(0)) {

            if (tActual.escacImat(!tornNegres)) return new Pair<>(tActual.heuristic(), true);
            else {
/*
                if (tornNegres) {
                    if (tActual.escac(tornNegres)) return new Pair<>(tActual.heuristic() + 10000, false);
                } else {
                    if (tActual.escac(tornNegres)) return new Pair<>(tActual.heuristic() - 10000, false);
                }
*/
                return new Pair<>(tActual.heuristic(), false);
            }
        } else {
            if (tornNegres) {//MAXIMITZAR
                Integer millorTaulell = -10000;
                Boolean totsEscac = true;
                ArrayList<ArrayList<Integer>> moviments = tActual.totsMoviments(tornNegres);
                for (int i = 0; i < moviments.size(); ++i) {
                    Taulell nouTaulell = new Taulell(tActual);
                    nouTaulell.ferMoviment(moviments.get(i));
                    Pair<Integer, Boolean> res = i_ferMovimentSmartB(nouTaulell, !tornNegres, profunditat - 1,  true);
                    if (millorTaulell < res.getKey()) {
                        millorTaulell = res.getKey();
                    }
                    if (!res.getValue()) totsEscac = false;

                }
                return new Pair<>(millorTaulell, totsEscac);
            } else {//MINIMITZAR
                Integer millorTaulell = 10000;
                ArrayList<ArrayList<Integer>> moviments = tActual.totsMoviments(tornNegres);
                Boolean escac = false;

                for (int i = 0; i < moviments.size() && !escac; ++i) {
                    Taulell nouTaulell = new Taulell(tActual);
                    nouTaulell.ferMoviment(moviments.get(i));
                    Pair<Integer, Boolean> res = i_ferMovimentSmartB(nouTaulell, !tornNegres, profunditat - 1,  true);
                    if (millorTaulell > res.getKey()) {
                        millorTaulell = res.getKey();
                    }
                    if (res.getValue()) escac = true;


                }
                return new Pair<>(millorTaulell, escac);
            }
        }
    }



    public ArrayList<Integer> ferMoviment(Taulell tActual, Boolean tornNegres, Integer N){
        Integer profunditat;
        if(N >= 4)profunditat = 4;
        else profunditat = (2*N)-1;

        profunditatInicial = profunditat;
        Integer result = i_ferMovimentSmart(tActual, tornNegres, profunditat, -10000, 10000);
        return millorMoviment;
    }


    private Integer i_ferMovimentSmart(Taulell tActual, Boolean tornNegres, Integer profunditat, Integer alpha, Integer beta){

        if(profunditat.equals(0)){

            return tActual.heuristic();
        }
        else{
            if(tornNegres){//MAXIMITZAR
                Integer millorTaulell = -10000;
                ArrayList< ArrayList<Integer>> movimentsPosibles = tActual.totsMoviments(tornNegres);
                if(movimentsPosibles.size() == 0){
                    return tActual.heuristic();
                }
                for(int i = 0; i < movimentsPosibles.size(); ++i){

                    Taulell nouTaulell = new Taulell(tActual);
                    nouTaulell.ferMoviment(movimentsPosibles.get(i));
                   // if(nouTaulell.escacImat(tornNegres))return 10000;
                    Integer ret = i_ferMovimentSmart(nouTaulell, !tornNegres, profunditat - 1,alpha,beta);
                    if (ret > millorTaulell) {
                        millorTaulell = new Integer(ret);
                        if (profunditatInicial.equals(profunditat)) {
                            millorMoviment = new ArrayList<>(movimentsPosibles.get(i));
                        }
                    }
                    alpha = Math.max(alpha, millorTaulell);
                    if(beta <= alpha){
                        return millorTaulell;
                    }
                }
                return millorTaulell;
            }
            else{//MINIMITZAR
                Integer millorTaulell = 10000;
                ArrayList< ArrayList<Integer>> movimentsPosibles = tActual.totsMoviments(tornNegres);
                if(movimentsPosibles.size() == 0){
                    return tActual.heuristic();
                }
                for(int i = 0; i < movimentsPosibles.size(); ++i){
                    Taulell nouTaulell = new Taulell(tActual);
                    nouTaulell.ferMoviment(movimentsPosibles.get(i));
                  //  if(nouTaulell.escacImat(tornNegres))return -10000;
                    Integer ret = i_ferMovimentSmart(nouTaulell, !tornNegres, profunditat - 1,alpha,beta);
                    if (ret < millorTaulell) {
                        millorTaulell = new Integer(ret);
                        if (profunditatInicial.equals(profunditat)) {
                            millorMoviment = new ArrayList<>(movimentsPosibles.get(i));
                        }
                    }
                    beta = Math.min(beta,millorTaulell);
                    if(beta <= alpha){
                        return millorTaulell;
                    }
                }
                return millorTaulell;
            }

        }

    }



}


