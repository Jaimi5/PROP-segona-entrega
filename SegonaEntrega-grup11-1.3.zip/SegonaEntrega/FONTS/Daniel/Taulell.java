import com.sun.org.apache.xpath.internal.operations.Neg;
import com.sun.xml.internal.bind.v2.runtime.reflect.Lister;
import javafx.util.Pair;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Taulell {


    private ArrayList< ArrayList<Character>> taulell = new ArrayList<>(8);

    private ArrayList<Peca> Blanques = new ArrayList<>();
    private ArrayList<Peca> Negres = new ArrayList<>();



    public Taulell() {

        for(int i = 0; i < 8; ++i){
            ArrayList<Character> fila = new ArrayList(8);
            taulell.add(fila);
            for (int j = 0; j < 8; ++j){
                Character c = '/';
                taulell.get(i).add(c);
            }
        }
    }

    public Taulell(Taulell tCopiar){
        this.taulell = new ArrayList<>();
        for (int i = 0; i < tCopiar.getTaulell().size(); ++i) {
            ArrayList<Character> aux = new ArrayList<>();
            for (int j = 0; j < tCopiar.getTaulell().get(i).size(); ++j) {
                aux.add(new Character(tCopiar.getTaulell().get(i).get(j)));
            }
            this.taulell.add(aux);
        }
        this.Blanques = new ArrayList<>();
        for (int i = 0; i < tCopiar.getBlanques().size(); ++i) {
            if (tCopiar.getBlanques().get(i).getClass() == Peo.class) {
                Peo p = new Peo();
                p.setColor(false);
                p.setCoordX(new Integer(tCopiar.getBlanques().get(i).getCoordX()));
                p.setCoordY(new Integer(tCopiar.getBlanques().get(i).getCoordY()));
                this.Blanques.add(p);
            }
            else if (tCopiar.getBlanques().get(i).getClass() == Rei.class) {
                Rei r = new Rei();
                r.setCoordX(new Integer(tCopiar.getBlanques().get(i).getCoordX()));
                r.setCoordY(new Integer(tCopiar.getBlanques().get(i).getCoordY()));
                this.Blanques.add(r);
            }
            else if (tCopiar.getBlanques().get(i).getClass() == Cavall.class) {
                Cavall c = new Cavall();
                c.setCoordX(new Integer(tCopiar.getBlanques().get(i).getCoordX()));
                c.setCoordY(new Integer(tCopiar.getBlanques().get(i).getCoordY()));
                this.Blanques.add(c);
            }
            else if (tCopiar.getBlanques().get(i).getClass() == Alfil.class) {
                Alfil a = new Alfil();
                a.setCoordX(new Integer(tCopiar.getBlanques().get(i).getCoordX()));
                a.setCoordY(new Integer(tCopiar.getBlanques().get(i).getCoordY()));
                this.Blanques.add(a);
            }
            else if (tCopiar.getBlanques().get(i).getClass() == Torre.class) {
                Torre t = new Torre();
                t.setCoordX(new Integer(tCopiar.getBlanques().get(i).getCoordX()));
                t.setCoordY(new Integer(tCopiar.getBlanques().get(i).getCoordY()));
                this.Blanques.add(t);
            }
            else if (tCopiar.getBlanques().get(i).getClass() == Dama.class) {
                Dama d = new Dama();
                d.setCoordX(new Integer(tCopiar.getBlanques().get(i).getCoordX()));
                d.setCoordY(new Integer(tCopiar.getBlanques().get(i).getCoordY()));
                this.Blanques.add(d);
            }
        }
        this.Negres = new ArrayList<>();
        for (int i = 0; i < tCopiar.getNegres().size(); ++i) {
            if (tCopiar.getNegres().get(i).getClass() == Peo.class) {
                Peo p = new Peo();
                p.setCoordX(new Integer(tCopiar.getNegres().get(i).getCoordX()));
                p.setCoordY(new Integer(tCopiar.getNegres().get(i).getCoordY()));
                p.setColor(true);
                this.Negres.add(p);
            }
            else if (tCopiar.getNegres().get(i).getClass() == Rei.class) {
                Rei r = new Rei();
                r.setCoordX(new Integer(tCopiar.getNegres().get(i).getCoordX()));
                r.setCoordY(new Integer(tCopiar.getNegres().get(i).getCoordY()));
                this.Negres.add(r);
            }
            else if (tCopiar.getNegres().get(i).getClass() == Cavall.class) {
                Cavall c = new Cavall();
                c.setCoordX(new Integer(tCopiar.getNegres().get(i).getCoordX()));
                c.setCoordY(new Integer(tCopiar.getNegres().get(i).getCoordY()));
                this.Negres.add(c);
            }
            else if (tCopiar.getNegres().get(i).getClass() == Alfil.class) {
                Alfil a = new Alfil();
                a.setCoordX(new Integer(tCopiar.getNegres().get(i).getCoordX()));
                a.setCoordY(new Integer(tCopiar.getNegres().get(i).getCoordY()));
                this.Negres.add(a);
            }
            else if (tCopiar.getNegres().get(i).getClass() == Torre.class) {
                Torre t = new Torre();
                t.setCoordX(new Integer(tCopiar.getNegres().get(i).getCoordX()));
                t.setCoordY(new Integer(tCopiar.getNegres().get(i).getCoordY()));
                this.Negres.add(t);
            }
            else if (tCopiar.getNegres().get(i).getClass() == Dama.class) {
                Dama d = new Dama();
                d.setCoordX(new Integer(tCopiar.getNegres().get(i).getCoordX()));
                d.setCoordY(new Integer(tCopiar.getNegres().get(i).getCoordY()));
                this.Negres.add(d);
            }
        }
    }


    public Boolean reiViu(Boolean reiNegre){
        Boolean trobat = false;

        for(int i = 0; i < 8 && !trobat; ++i){
            for(int j = 0; j < 8 && !trobat; ++j){
                Character c = taulell.get(i).get(j);
                if(Character.isLetter(c)){
                    if(reiNegre){
                        if(c == 'k'){
                            trobat = true;

                        }
                    }
                    else{
                        if(c == 'K'){
                            trobat = true;

                        }
                    }
                }
            }
        }
        return trobat;
    }

    //Pre: se li pasan les posicions de la matriu inicials i finals
    //Post: Ha fet el moviment a taulell i retorna true si sha fet i false si no, en cas de matar a una peça també retorna quina peça és, sino '/'
    public Pair<Boolean, Character> movimentPosible(Integer inii, Integer inij, Integer fini, Integer finj){
        Character ini = taulell.get(inii).get(inij);//Que hi ha a la posició inicial
        Character fin = taulell.get(fini).get(finj);//Que hi ha a la posició final
        Boolean ininegre;
        Boolean finegre;
        if(!Character.isLetter(ini))return new Pair<>(false, '/'); //si a la posició inicial no hi ha una peça no es pot fer cap moviment
        if(Character.isUpperCase(ini)) ininegre = false;//si es majuscula la peça és blanca
        else ininegre = true;//si és minuscula la peça és negre

        Taulell aux = new Taulell(this);
        ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(inii, inij, fini, finj));
        aux.ferMoviment(arrayAux);

        if(aux.escac(!ininegre))return new Pair<>(false,'/'); //no es pot fer un moviment si això provocarà un escac al teu rei
        if(Character.isLetter(fin)){//si a la posició final hi ha una peça
            if(Character.isUpperCase(fin)) finegre = false; //blanca
            else finegre = true;//negre
            if(ininegre == finegre){ //si el color de la peça inicial és igual al de la final, no pots moure't allà
                System.out.println("A la posició on vols moure't, ja hi ha una peça teva");
                Pair<Boolean, Character> ret = new Pair<>(false, '/');
                return ret; //si a on vols anar hi ha una peça i es teva no pots anar
            }
            else{
                Pair<Boolean, Character> ret;
                if(potArribar(inii,inij,fini,finj)){//si pot arribar la mato

                    Peca p = buscaPeca(inii, inij);
                    p.setCoordX(fini);
                    p.setCoordY(finj);
                    taulell.get(inii).set(inij,'/');
                    p = buscaPeca(fini, finj);
                    taulell.get(fini).set(finj, ini);
                    if(finegre) Negres.remove(p);//elimiem la peça del vector
                    else Blanques.remove(p);
                    ret = new Pair<>(true, fin);//a matat la peça i retorna true i el caracter que la representava
                }
                else ret = new Pair<>(false, '/');//no pot arribar per tant retorna false, i cap peça
                return ret;
            }
        }
        else{
            Pair<Boolean, Character> ret;
            if(potArribar(inii,inij, fini, finj)){//si pot arribar haig de moure la peça
                taulell.get(fini).set(finj, ini);
                Peca p = buscaPeca(inii, inij);
                p.setCoordX(fini);
                p.setCoordY(finj);
                taulell.get(inii).set(inij, '/');

                ret = new Pair<>(true, '/');
                return ret;
            }
            else ret = new Pair<>(false, '/');//si no pot arribar retorna false
            return ret;
        }
    }

    public ArrayList< ArrayList<Character>> getTaulell(){
        return this.taulell;
    }

    public ArrayList<Peca> getBlanques() { return this.Blanques; }

    public ArrayList<Peca> getNegres() { return this.Negres; }


    public Boolean arribaPeoDiagonal(Integer inii, Integer inij, Integer fini, Integer finj, Boolean negre){
        Boolean ret = false;
        if(taulell.get(inii).get(inij).equals('p') || taulell.get(inii).get(inij).equals('P')){
            if(negre){

                if(inii + 1 == fini && inij - 1 == finj)ret = true;
                else if(inii + 1 == fini && inij + 1 == finj) ret = true;
            }
            else{
                if(inii - 1 == fini && inij == finj) return false;

                if(inii - 1 == fini && inij - 1 == finj)ret = true;
                else if(inii - 1 == fini && inij + 1 == finj ) ret = true;
            }
        }

        return ret;
    }

    public Boolean reiDavantPeo (Integer inii, Integer inij, Integer fini, Integer finj, Boolean negre){
        if(taulell.get(inii).get(inij).equals('p') || taulell.get(inii).get(inij).equals('P')) {

            if (negre) {
                if (inii + 1 == fini && inij == finj) return true;
            } else {
                if (inii - 1 == fini && inij == finj) return true;
            }
        }
        return false;
    }

    public boolean escac(Boolean atacantNegre){
        Boolean trobat = false;
        Integer CoordReiX = 0;//FICO 0 PERQUE SINO DONA ERROR AL COMPILAR PERQUE DIU QUE POTSER NO ESTA INICIALITZADA
        Integer CoordReiY = 0;
        for(int i = 0; i < 8 && !trobat; ++i){ //Bucles que busquen la posició del rei defensor i la guarden a x i y
            for(int j = 0; j < 8 && !trobat; ++j){
                Character c = taulell.get(i).get(j);
                if(Character.isLetter(c)){
                    if(atacantNegre){
                        if(c == 'K'){
                            trobat = true;
                            CoordReiX = i;
                            CoordReiY = j;
                        }
                    }
                    else{
                        if(c == 'k'){
                            trobat = true;
                            CoordReiX = i;
                            CoordReiY = j;
                        }
                    }
                }
            }
        }

        if(atacantNegre){
            Boolean AlgunaPeçaArriba = false;

            for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){//recorro totes les peces negres i miro si alguna pot matar al rei
                Integer inix = Negres.get(i).getCoordX();
                Integer iniy = Negres.get(i).getCoordY();
                if((potArribar(inix, iniy, CoordReiX, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY, true)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY, true)){
                    AlgunaPeçaArriba = true;
                }
            }
            if(!AlgunaPeçaArriba) return false;//si cap peça pot matar al rei no es escac i mat

        }
        else{
            Boolean AlgunaPeçaArriba = false;

            for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){//recorro totes les peces negres i miro si alguna pot matar al rei
                Integer inix = Blanques.get(i).getCoordX();
                Integer iniy = Blanques.get(i).getCoordY();
                if((potArribar(inix, iniy, CoordReiX, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY, false)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY, false)){
                    AlgunaPeçaArriba = true;
                }
            }
            if(!AlgunaPeçaArriba) return false;//si cap peça pot matar al rei no es escac i mat
        }
        return true;
    }

    //todo: Comprovar que cada peça que pot arribar a una posició que fa escac o que fa que el rei no pugui anar, no te cap peça en el recorregut
    //todo: Comprovar si el recorregut és interceptable
    //Pre: es pasa com a parametre si els atacants son els negres, si és false vol dir que estan atacant les blanques
    //Post: retorna true si hi ha escac i mat al rei defensor
    public boolean escacImat(Boolean atacantNegre){
        Boolean trobat = false;
        Integer CoordReiX = -1;//FICO -1 PERQUE SINO DONA ERROR AL COMPILAR PERQUE DIU QUE POTSER NO ESTA INICIALITZADA
        Integer CoordReiY = -1;
        for(int i = 0; i < 8 && !trobat; ++i){ //Bucles que busquen la posició del rei defensor i la guarden a x i y
            for(int j = 0; j < 8 && !trobat; ++j){
                Character c = taulell.get(i).get(j);
                if(Character.isLetter(c)){
                    if(atacantNegre){
                        if(c == 'K'){
                            trobat = true;
                            CoordReiX = i;
                            CoordReiY = j;
                        }
                    }
                    else{
                        if(c == 'k'){
                            trobat = true;
                            CoordReiX = i;
                            CoordReiY = j;
                        }
                    }
                }
            }
        }
if(CoordReiX.equals(-1) && CoordReiY.equals(-1))return false;
        //COSES QUE ES COMPROVEN:
        //-Que algu estigui fent escac al rei
        //-Que en cas de que 2 peces li estiguin fent escac directe al rei es escac i mat directe //todo: si el rei es pot moure ja no es escac
        //-Que el rei no pugui anar a cap posició adjacent ja que alguna peça enemiga li faria escac
        //-Que en cas de que pugui anar a una posició adjacent no hi hagi una peça aliada allà perqué en aquest cas no pot anar
        //-Que en cas de que pugui anar a una posició adjacent, si hi ha una peça enemiga la pugui matar
        if(atacantNegre){//si l'atacant son les negres vol dir que les coordenades del rei son les del blanc
            Boolean AlgunaPeçaArriba = false;
            Boolean reiPotEscapar = false;
            Integer numeroPecesEscacRei = 0;
            Peca peçaQueFaEscac = null;
            for(int i = 0; i < Negres.size(); ++i){//recorro totes les peces negres i miro si alguna pot matar al rei
                Integer inix = Negres.get(i).getCoordX();
                Integer iniy = Negres.get(i).getCoordY();
                if((potArribar(inix, iniy, CoordReiX, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY, true)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY, true)){
                    peçaQueFaEscac = Negres.get(i); // s'utilitzarà després per veure si una peça alida pot matar-la o interceptar el cami
                    AlgunaPeçaArriba = true;
                    numeroPecesEscacRei++;
                }
            }
            if(!AlgunaPeçaArriba) return false;//si cap peça pot matar al rei no es escac i mat
            else AlgunaPeçaArriba = false;
            if(CoordReiX - 1 >= 0){//Miro la posició de dalt per veure si el rei pot escapar per alla
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX - 1, CoordReiY));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX - 1, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX - 1, CoordReiY, true)) && !reiDavantPeo(inix,iniy,CoordReiX - 1, CoordReiY, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX - 1, CoordReiY, esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX - 1, CoordReiY, esNegre(CoordReiX, CoordReiY))) return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX - 1 >= 0 && CoordReiY +1 <=7){//Mira la posició en diagonal cap a dalt i dreta
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX - 1, CoordReiY + 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX - 1, CoordReiY + 1) || arribaPeoDiagonal(inix,iniy,CoordReiX - 1, CoordReiY + 1, true)) && !reiDavantPeo(inix,iniy,CoordReiX - 1, CoordReiY + 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX - 1, CoordReiY + 1, esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX - 1, CoordReiY + 1, esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiY + 1 <= 7){//Posició dreta
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX, CoordReiY + 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX, CoordReiY + 1) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY + 1, true)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY + 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX + 1 <= 7 && CoordReiY + 1 <= 7){//Posició diagonal a baix dreta
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX + 1, CoordReiY + 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX + 1, CoordReiY + 1) || arribaPeoDiagonal(inix,iniy,CoordReiX + 1, CoordReiY + 1, true)) && !reiDavantPeo(inix,iniy,CoordReiX + 1, CoordReiY + 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX + 1, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX + 1, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX + 1 <= 7){//Posició de sota
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX + 1, CoordReiY));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX + 1, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX + 1, CoordReiY, true)) && !reiDavantPeo(inix,iniy,CoordReiX + 1, CoordReiY, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX + 1, CoordReiY,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX + 1, CoordReiY,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX + 1 <= 7 && CoordReiY - 1 >= 0){//Posició diagonal a baix esquerre
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX + 1, CoordReiY - 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX + 1, CoordReiY - 1) || arribaPeoDiagonal(inix,iniy,CoordReiX + 1, CoordReiY - 1, true)) && !reiDavantPeo(inix,iniy,CoordReiX + 1, CoordReiY - 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX + 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX + 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiY - 1 >= 0){//Posició costat esquerre
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX, CoordReiY - 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX, CoordReiY - 1) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY - 1, true)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY - 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX -1 >= 0 && CoordReiY - 1 >= 0){//Posició diagonal a dalt a la esquerra
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX - 1, CoordReiY - 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Negres.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Negres.get(i).getCoordX();
                    Integer iniy = Negres.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX - 1, CoordReiY - 1) || arribaPeoDiagonal(inix,iniy,CoordReiX - 1, CoordReiY - 1, true)) && !reiDavantPeo(inix,iniy,CoordReiX - 1, CoordReiY - 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX - 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX - 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            //si el programa ha arribat aqui vol dir que el rei no ha pogut escapar i si es compleix el seguent if no cal comprovar si es pot bloquejar el cami del atacant directe
            if(numeroPecesEscacRei > 1) return true; //si més d'una peça pot matar al rei és escac i mat

            //ARA S'HA DE COMPROVAR SI LA PEÇA QUE FA ESCAC AL REI ES POT INTERCEPTAR EL SEU CAMI AMB UNA ALTRE PEÇA ALIADA
            Boolean interceptat = false;
            ArrayList<Pair <Integer, Integer>> camiEscac = peçaQueFaEscac.direccioMoviment(peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY(), CoordReiX, CoordReiY);
            for(int i = 0; i < Blanques.size() && !interceptat; ++i){
                Integer CoordXPeça = Blanques.get(i).getCoordX();
                Integer CoordYPeça = Blanques.get(i).getCoordY();
                Taulell aux = new Taulell(this);
                //ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY()));
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordXPeça, CoordYPeça, peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY()));
                aux.ferMoviment(arrayAux);
                if(potArribar(CoordXPeça, CoordYPeça, peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY()) && !aux.escac(true)){//la pot matar per tant deixa deser escac i mat
                    interceptat = true;
                }
                for(int j = 0; j < camiEscac.size() && !interceptat; ++j){
                    Taulell aux2 = new Taulell(this);
                    ArrayList<Integer> arrayAux2 = new ArrayList<>(Arrays.asList(CoordXPeça, CoordYPeça, camiEscac.get(j).getKey(), camiEscac.get(j).getValue()));
                    aux2.ferMoviment(arrayAux2);
                    if(!taulell.get(CoordXPeça).get(CoordYPeça).equals('K') && potArribar(CoordXPeça, CoordYPeça, camiEscac.get(j).getKey(), camiEscac.get(j).getValue()) && !aux2.escac(true)){//camí interceptable per tant no escac i mat
                        interceptat = true;
                    }
                }
            }
            if(interceptat)return false;

        }
        else{
            Boolean AlgunaPeçaArriba = false;
            Integer numeroPecesEscacRei = 0;
            Peca peçaQueFaEscac = null;
            for(int i = 0; i < Blanques.size(); ++i){//recorro totes les peces negres i miro si alguna pot matar al rei
                Integer inix = Blanques.get(i).getCoordX();
                Integer iniy = Blanques.get(i).getCoordY();
                if((potArribar(inix, iniy, CoordReiX, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY, false)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY, false)){
                    AlgunaPeçaArriba = true;
                    numeroPecesEscacRei++;
                    peçaQueFaEscac = Blanques.get(i); // s'utilitzarà després per veure si una peça alida pot matar-la o interceptar el cami
                }
            }
            if(!AlgunaPeçaArriba) return false;//si cap peça pot matar al rei no es escac i mat
            else AlgunaPeçaArriba = false;
            if(CoordReiX - 1 >= 0){//Miro la posició de dalt per veure si el rei pot escapar per alla
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX - 1, CoordReiY));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX - 1, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX - 1, CoordReiY, false)) && !reiDavantPeo(inix,iniy,CoordReiX - 1, CoordReiY, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX - 1, CoordReiY,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX - 1, CoordReiY,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX - 1 >= 0 && CoordReiY + 1 <=7){//Mira la posició en diagonal cap a dalt i dreta
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX - 1, CoordReiY + 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX - 1, CoordReiY + 1) || arribaPeoDiagonal(inix,iniy,CoordReiX - 1, CoordReiY + 1, false)) && !reiDavantPeo(inix,iniy,CoordReiX - 1, CoordReiY + 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX - 1, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX - 1, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiY + 1 <= 7){//Posició dreta
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX, CoordReiY + 1));

                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();

                    if((aux.potArribar(inix, iniy, CoordReiX , CoordReiY + 1) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY + 1, false)) && !reiDavantPeo(inix,iniy,CoordReiX, CoordReiY + 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(CoordReiX.equals(0) && CoordReiY.equals(0)){
                        System.out.println(" ");
                    }
                    if(!peçaAliada(CoordReiX, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX + 1 <= 7 && CoordReiY + 1 <= 7){//Posició diagonal a baix dreta
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX + 1, CoordReiY + 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX + 1, CoordReiY + 1) || arribaPeoDiagonal(inix,iniy,CoordReiX + 1, CoordReiY + 1, false)) && !reiDavantPeo(inix,iniy,CoordReiX + 1, CoordReiY + 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX + 1, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX + 1, CoordReiY + 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX + 1 <= 7){//Posició de sota
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX + 1, CoordReiY));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX + 1, CoordReiY) || arribaPeoDiagonal(inix,iniy,CoordReiX + 1, CoordReiY, false)) && !reiDavantPeo(inix,iniy,CoordReiX + 1, CoordReiY, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX + 1, CoordReiY,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX + 1, CoordReiY,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX + 1 <= 7 && CoordReiY - 1 >= 0){//Posició diagonal a baix esquerre
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX + 1, CoordReiY - 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX + 1, CoordReiY-1) || arribaPeoDiagonal(inix,iniy,CoordReiX + 1, CoordReiY - 1, false)) && !reiDavantPeo(inix,iniy,CoordReiX + 1, CoordReiY- 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX + 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX + 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiY - 1 >= 0){//Posició costat esquerre
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX, CoordReiY - 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX , CoordReiY-1) || arribaPeoDiagonal(inix,iniy,CoordReiX, CoordReiY - 1, false)) && !reiDavantPeo(inix,iniy,CoordReiX , CoordReiY- 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            if(CoordReiX -1 >= 0 && CoordReiY - 1 >= 0){//Posició diagonal a dalt a la esquerra
                Taulell aux = new Taulell(this);
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, CoordReiX - 1, CoordReiY - 1));
                aux.ferMoviment(arrayAux);
                for(int i = 0; i < Blanques.size() && !AlgunaPeçaArriba; ++i){
                    Integer inix = Blanques.get(i).getCoordX();
                    Integer iniy = Blanques.get(i).getCoordY();
                    if((aux.potArribar(inix, iniy, CoordReiX - 1, CoordReiY-1) || arribaPeoDiagonal(inix,iniy,CoordReiX - 1, CoordReiY - 1, false)) && !reiDavantPeo(inix,iniy,CoordReiX - 1, CoordReiY- 1, true))AlgunaPeçaArriba = true;
                }
                if(!AlgunaPeçaArriba){
                    if(!peçaAliada(CoordReiX - 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i no hi ha una aliada el rei pot escapar
                    if(peçaEnemiga(CoordReiX - 1, CoordReiY - 1,  esNegre(CoordReiX, CoordReiY)))return false;//si no arriba ninguna peça enemiga i el rey pot matar a la peça no es escac i mat
                }
                else AlgunaPeçaArriba = false;
            }
            //si el programa ha arribat aqui vol dir que el rei no ha pogut escapar i si es compleix el seguent if no cal comprovar si es pot bloquejar el cami del atacant directe
            if(numeroPecesEscacRei > 1) return true; //si més d'una peça pot matar al rei és escac i mat

            //ARA S'HA DE COMPROVAR SI LA PEÇA QUE FA ESCAC AL REI ES POT INTERCEPTAR EL SEU CAMI AMB UNA ALTRE PEÇA ALIADA

            Boolean interceptat = false;
            ArrayList<Pair <Integer, Integer>> camiEscac = peçaQueFaEscac.direccioMoviment(peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY(), CoordReiX, CoordReiY);
            for(int i = 0; i < Negres.size() && !interceptat; ++i){
                Integer CoordXPeça = Negres.get(i).getCoordX();
                Integer CoordYPeça = Negres.get(i).getCoordY();
                Taulell aux = new Taulell(this);
                //ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY()));
                ArrayList<Integer> arrayAux = new ArrayList<>(Arrays.asList(CoordXPeça, CoordYPeça, peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY()));

                aux.ferMoviment(arrayAux);
                Character reiNigga = taulell.get(CoordReiX).get(CoordReiY);

                if(potArribar(CoordXPeça, CoordYPeça, peçaQueFaEscac.getCoordX(), peçaQueFaEscac.getCoordY()) && !aux.escac(false)){//la pot matar per tant deixa de ser escac i mat
                    interceptat = true;
                }
                for(int j = 0; j < camiEscac.size() && !interceptat; ++j){
                    Taulell aux2 = new Taulell(this);
                    ArrayList<Integer> arrayAux2 = new ArrayList<>(Arrays.asList(CoordXPeça, CoordYPeça, camiEscac.get(j).getKey(), camiEscac.get(j).getValue()));
                    aux2.ferMoviment(arrayAux2);
                    if(!taulell.get(CoordXPeça).get(CoordYPeça).equals('k') && potArribar(CoordXPeça, CoordYPeça, camiEscac.get(j).getKey(), camiEscac.get(j).getValue()) && !aux2.escac(false)){//camí interceptable per tant no escac i mat
                        interceptat = true;
                    }
                }
            }
            if(interceptat)return false;
        }



        return true;
    }
    //todo: millora deficiencia afegint la peca com a paraetre
    //PRE: donarli les coordenades inicials i finals, a les coordenades inicials ha d'haver una peça, les finals han destar dintre del taulell
    //POST: utilitza la funció posició correcte per saber si es pot anar a la posició i despres comprova que en el camí no hi hagi cap peça
    public Boolean potArribar(Integer inix, Integer iniy, Integer finx, Integer finy){
        Boolean ret = true;
        Peca p;
        Boolean iniNegre = null;
        Boolean finNegre = null;
        Character c = taulell.get(inix).get(iniy);
        Character f = taulell.get(finx).get(finy);
        if(Character.isUpperCase(c))iniNegre = false;
        else if(Character.isLowerCase(c))iniNegre = true;
        if(c == 'p'){
            if(inix + 1 == finx && iniy - 1 == finy){
                Character cc = taulell.get(finx).get(finy);
                if(Character.isUpperCase(cc))return true;
            }
            else if(inix + 1 == finx && iniy + 1 == finy){
                Character cc = taulell.get(finx).get(finy);
                if(Character.isUpperCase(cc))return true;
            }
            else if(iniy.equals(finy) && inix - 1 == finx){
                Character cc = taulell.get(finx).get(finy);
                if(Character.isLetter(cc)) return false;
            }
        }
        if(c == 'P'){
            if(inix - 1 == finx && iniy - 1 == finy){
                Character cc = taulell.get(finx).get(finy);
                if(Character.isLowerCase(cc))return true;
            }
            else if(inix -1 == finx && iniy + 1 == finy){
                Character cc = taulell.get(finx).get(finy);
                if(Character.isLowerCase(cc))return true;
            }
            else if(iniy.equals(finy) && inix + 1 == finx){
                Character cc = taulell.get(finx).get(finy);
                if(Character.isLetter(cc)) return false;
            }
        }
        c = taulell.get(finx).get(finy);
        if(Character.isLetter(c)){
            if(Character.isUpperCase(c))finNegre = false;
            else if(Character.isLowerCase(c))finNegre = true;
        }


        p = buscaPeca(inix, iniy);

        if(!p.posiciocorrecte(inix, iniy, finx, finy)){
            ret = false;
        }
        else{
            ArrayList<Pair<Integer, Integer>> posicions = p.direccioMoviment(inix, iniy, finx, finy);
            for(int i = 0; i < posicions.size() && ret; ++i){
                Integer ii = posicions.get(i).getKey();
                Integer jj = posicions.get(i).getValue();
                if(taulell.get(ii).get(jj) != '/')ret = false;
            }
            if(Character.isLetter(c)){
                if(iniNegre.equals(finNegre))ret = false;
                else{
                    if(taulell.get(inix).get(iniy).equals('P') || taulell.get(inix).get(iniy).equals('p')) return false;
                }
            }

        }
        return ret;
    }

    public ArrayList<Pair<Integer, Integer>> marcarMoviments(Integer PosX, Integer PosY){
        Peca p = buscaPeca(PosX, PosY);
        ArrayList<Pair<Integer, Integer>> ret = new ArrayList<>();
        ArrayList<Pair<Integer, Integer>> moviments = p.movimentsPossibles(PosX, PosY);//obte tots els moviments de la peça
        for(int i = 0; i < moviments.size(); ++i){
            if(potArribar(PosX, PosY, moviments.get(i).getKey(), moviments.get(i).getValue())){
                ret.add(new Pair<>(moviments.get(i).getKey(), moviments.get(i).getValue()));
            }
        }
        Character c = taulell.get(PosX).get(PosY);
        if(c.equals('P')){
            if(PosX - 1 >= 0 && PosY - 1 >= 0){//diagonal a dalt esquerra
                if(Character.isLetter(taulell.get(PosX - 1).get(PosY - 1))){
                    if(Character.isLowerCase(taulell.get(PosX - 1).get(PosY - 1))){
                        ret.add(new Pair<>(PosX - 1, PosY - 1));
                    }
                }
            }
            if(PosX - 1 >= 0 && PosY + 1 < 8){//diagonal a dalt esquerra
                if(Character.isLetter(taulell.get(PosX - 1).get(PosY + 1))){
                    if(Character.isLowerCase(taulell.get(PosX - 1).get(PosY + 1))){
                        ret.add(new Pair<>(PosX - 1, PosY + 1));
                    }
                }
            }
        }
        else if(c.equals('p')){
            if(PosX + 1 < 8 && PosY - 1 >= 0){//diagonal a dalt esquerra
                if(Character.isLetter(taulell.get(PosX+1).get(PosY-1))){
                    if(Character.isUpperCase(taulell.get(PosX+1).get(PosY-1))){
                        ret.add(new Pair<>(PosX + 1, PosY - 1));
                    }
                }
            }
            if(PosX + 1 < 8 && PosY + 1 < 8){//diagonal a dalt esquerra
                if(Character.isLetter(taulell.get(PosX+1).get(PosY+1))){
                    if(Character.isUpperCase(taulell.get(PosX+1).get(PosY+1))){
                        ret.add(new Pair<>(PosX + 1, PosY + 1));
                    }
                }
            }
        }
        return ret;
    }

public Integer movimentsRei(Boolean Negre){
        Integer ret = 0;
    Boolean trobat = false;
    Integer CoordReiX = -1;//FICO -1 PERQUE SINO DONA ERROR AL COMPILAR PERQUE DIU QUE POTSER NO ESTA INICIALITZADA
    Integer CoordReiY = -1;
    for(int i = 0; i < 8 && !trobat; ++i){ //Bucles que busquen la posició del rei defensor i la guarden a x i y
        for(int j = 0; j < 8 && !trobat; ++j){
            Character c = taulell.get(i).get(j);
            if(Character.isLetter(c)){
                if(!Negre){
                    if(c == 'K'){
                        trobat = true;
                        CoordReiX = i;
                        CoordReiY = j;
                    }
                }
                else{
                    if(c == 'k'){
                        trobat = true;
                        CoordReiX = i;
                        CoordReiY = j;
                    }
                }
            }
        }
    }
    Peca p = buscaPeca(CoordReiX, CoordReiY);

        ArrayList<Pair <Integer, Integer>> moviments = p.movimentsPossibles(CoordReiX, CoordReiY);//Obté tots els moviments posbles del rei
        for(int i = 0; i < moviments.size(); ++i){
            if(potArribar(CoordReiX, CoordReiY, moviments.get(i).getKey(), moviments.get(i).getValue())){
                Taulell nouTaulell = new Taulell(this);
                ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(CoordReiX, CoordReiY, moviments.get(i).getKey(), moviments.get(i).getValue()));
                nouTaulell.ferMoviment(aux);
                if(!nouTaulell.escac(!Negre)){
                    ++ret;
                }
            }
        }


    return ret;
}
    //Generador de successors de MaquinaGreedy
    public ArrayList< ArrayList<Integer>> totsMoviments(Boolean tornNegres){
        ArrayList< ArrayList<Integer>> movimentsPosibles = new ArrayList<>();

        if(tornNegres){//si li toca a les negres shan de fer els moviments de les peces de Negres
            for(int i = 0; i < Negres.size(); ++i){//recorre Negres
                Integer inix = Negres.get(i).getCoordX();
                Integer iniy = Negres.get(i).getCoordY();
                ArrayList<Pair <Integer, Integer>> moviments = Negres.get(i).movimentsPossibles(inix, iniy);//Obté tots els moviments posbles d'una peca de Negres
                for(int j = 0; j < moviments.size(); ++j){//per cada moviment posible comprova que es pugui arribar i en cas de que si l'afegeix a movimentsPosibles per retornarlo
                    if(potArribar(inix,iniy,moviments.get(j).getKey(), moviments.get(j).getValue())){
                            Taulell nouTaulell = new Taulell(this);
                            ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(inix, iniy, moviments.get(j).getKey(), moviments.get(j).getValue()));
                            nouTaulell.ferMoviment(aux);
                            if(!nouTaulell.escac(!tornNegres)){
                                ArrayList<Integer> arrayAux2 = new ArrayList<>(Arrays.asList(inix, iniy, moviments.get(j).getKey(), moviments.get(j).getValue()));
                                movimentsPosibles.add(arrayAux2);
                            }
                    }
                }
                if(taulell.get(inix).get(iniy).equals('p')){//afegir el moviment diagonal del peo
                    if(inix + 1 < 8 && iniy - 1 >= 0){//diagonal a baix esquerra
                        if(Character.isLetter(taulell.get(inix+1).get(iniy-1))){
                            if(Character.isUpperCase(taulell.get(inix+1).get(iniy-1))){
                                Taulell nouTaulell = new Taulell(this);
                                ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(inix, iniy, inix + 1, iniy - 1));
                                nouTaulell.ferMoviment(aux);
                                if(!nouTaulell.escac(false))movimentsPosibles.add(aux);
                            }
                        }
                    }
                    if(inix + 1 < 8 && iniy + 1 < 8){//diagonal a baix esquerra
                        if(Character.isLetter(taulell.get(inix+1).get(iniy+1))){
                            if(Character.isUpperCase(taulell.get(inix+1).get(iniy+1))){
                                Taulell nouTaulell = new Taulell(this);
                                ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(inix, iniy, inix + 1, iniy + 1));
                                nouTaulell.ferMoviment(aux);
                                if(!nouTaulell.escac(false))movimentsPosibles.add(aux);
                            }
                        }
                    }
                }
            }
        }
        else{
            for(int i = 0; i < Blanques.size(); ++i){//recorre Blanques
                Integer inix = Blanques.get(i).getCoordX();
                Integer iniy = Blanques.get(i).getCoordY();
                ArrayList<Pair <Integer, Integer>> moviments = Blanques.get(i).movimentsPossibles(inix, iniy);//Obté tots els moviments posbles d'una peca Blanca
                for(int j = 0; j < moviments.size(); ++j){//per cada moviment posible comprova que es pugui arribar i en cas de que si l'afegeix a movimentsPosibles per retornarlo
                    if(potArribar(inix,iniy,moviments.get(j).getKey(), moviments.get(j).getValue())){
                            Taulell nouTaulell = new Taulell(this);
                            ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(inix, iniy, moviments.get(j).getKey(), moviments.get(j).getValue()));
                            nouTaulell.ferMoviment(aux);
                            if(!nouTaulell.escac(!tornNegres)){
                                ArrayList<Integer> arrayAux2 = new ArrayList<>(Arrays.asList(inix, iniy, moviments.get(j).getKey(), moviments.get(j).getValue()));
                                movimentsPosibles.add(arrayAux2);
                            }
                    }
                }
                if(taulell.get(inix).get(iniy).equals('P')){//afegir el moviment diagonal del peo
                    if(inix - 1 > 0 && iniy - 1 >= 0){//diagonal a dalt esquerra
                        if(Character.isLetter(taulell.get(inix - 1).get(iniy - 1))){
                            if(Character.isLowerCase(taulell.get(inix - 1).get(iniy - 1))){
                                Taulell nouTaulell = new Taulell(this);
                                ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(inix, iniy, inix - 1, iniy - 1));
                                nouTaulell.ferMoviment(aux);
                                if(!nouTaulell.escac(true)) movimentsPosibles.add(aux);
                            }
                        }
                    }
                    if(inix - 1 > 0 && iniy + 1 < 8){//diagonal a dalt dreta
                        if(Character.isLetter(taulell.get(inix - 1).get(iniy + 1))){
                            if(Character.isLowerCase(taulell.get(inix - 1).get(iniy + 1))){
                                Taulell nouTaulell = new Taulell(this);
                                ArrayList<Integer> aux = new ArrayList<>(Arrays.asList(inix, iniy, inix - 1, iniy + 1));
                                nouTaulell.ferMoviment(aux);
                                if(!nouTaulell.escac(true)) movimentsPosibles.add(aux);
                            }
                        }
                    }
                }
            }
        }
        return movimentsPosibles;
    }

    //PRE: a la posició hi ha una lletra, la posició està dintre del taulell
    //POST: retorna true si es una peça negre i false si es blanca
    public Boolean esNegre(Integer x, Integer y){
        Character c = this.taulell.get(x).get(y);
        Boolean negre = null; //POSO TRUE PERQUE SINO DONA ERROR JA QUE NO ESTA INICIALITZADA
        if(Character.isLetter(c)){
            if(Character.isUpperCase(c))negre = false;
            if(Character.isLowerCase(c))negre = true;
        }
        return negre;
    }
    //PRE: x, y posicions correctes
    //POST: retorna la peça que es troba a la posició x,y
    public Peca buscaPeca(Integer x, Integer y){
        Boolean trobat = false;
        //AQUI DECLARAVA LA PECA P

        if(esNegre(x,y)){
            for(int i = 0; i < Negres.size() && !trobat; ++i){
                if(Negres.get(i).getCoordX().equals(x) && Negres.get(i).getCoordY().equals(y)){
                    trobat = true;
                    Peca p = Negres.get(i);
                    return p;
                }
            }
        }
        else{

            for(int i = 0; i < Blanques.size() && !trobat; ++i){
                if(Blanques.get(i).getCoordX().equals(x) && Blanques.get(i).getCoordY().equals(y)){
                    trobat = true;
                   Peca p = Blanques.get(i);
                   return p;
                }
            }
        }
        return null;
    }

    //PRE: es dona un taulell i unes cordenades inicials i unes finals a on s'ha de moure la peça. El moviment s'ha de poder fer.
    //POST: retorna un taulell a on s'ha fet el moviment i actualitzat tot lo de taulell
    public void ferMoviment(ArrayList<Integer> coordenades){
         //t'he posat el anticTaulell per què en teoria la constructora está feta.
        Integer inix = coordenades.get(0);
        Integer iniy = coordenades.get(1);
        Integer finx = coordenades.get(2);
        Integer finy = coordenades.get(3);
        Boolean esNegre = false;
        Character pecaAMoure = this.taulell.get(inix).get(iniy);
        Character posicioFinal = this.taulell.get(finx).get(finy);
        Boolean mata = false;
        if(Character.isLetter(posicioFinal))mata = true;
        if(Character.isLetter(pecaAMoure)){
            if(Character.isUpperCase(pecaAMoure))esNegre = false;
            if(Character.isLowerCase(pecaAMoure))esNegre = true;


                if(mata) {

                    Peca m = this.buscaPeca(finx,finy);
                    if(esNegre(finx,finy)){
                        this.Negres.remove(m);
                    }
                    else{
                        this.Blanques.remove(m);
                    }
                }

                this.taulell.get(finx).set(finy, pecaAMoure);
                Peca p = this.buscaPeca(inix,iniy);
                p.setCoordX(finx);
                p.setCoordY(finy);
                this.taulell.get(inix).set(iniy, '/');


                /*
                ret.taulell.get(finx).set(finy, pecaAMoure);
                Boolean trobat = false;
                for(int i = 0; i < ret.Negres.size() && !trobat; ++i){//Actualitza les Coord de la peça
                    if(ret.Negres.get(i).CoordX.equals(inix) && ret.Negres.get(i).CoordY.equals(iniy)){
                        trobat = true;
                        ret.Negres.get(i).CoordX = finx;
                        ret.Negres.get(i).CoordY = finy;
                    }
                }
                ret.taulell.get(inix).set(iniy, '/');
                */



        }
    }

    //Faig l'heurístic de tranks
    //Peo = 5 punts, Cavall = 20 punts (més que l'alfil perquè pot saltar per sobre les peces), Alfil = 15 punts, Torre = 30 punts, Dama = 50 punts, Rei = 500 punts.
    public Integer heuristic() {


        Integer resultat = new Integer(0);

        if(escacImat(true))resultat += 5000;
        if(escacImat(false))resultat -= 5000;
/*
        Integer movRei = movimentsRei(true);
        resultat -= (10*movRei);
        movRei = movimentsRei(false);
        resultat += (10*movRei);
*/
        for (int i = 0; i < this.Negres.size(); ++i) { //negres amb valors positius
            if (this.Negres.get(i).getClass() == Peo.class) resultat += 5;
            else if (this.Negres.get(i).getClass() == Alfil.class) resultat += 15;
            else if (this.Negres.get(i).getClass() == Cavall.class) resultat += 20;
            else if (this.Negres.get(i).getClass() == Torre.class) resultat += 30;
            else if (this.Negres.get(i).getClass() == Dama.class) resultat += 50;
            else if (this.Negres.get(i).getClass() == Rei.class) resultat += 1000;
        }
        for (int i = 0; i < this.Blanques.size(); ++i) { //negres amb valors positius
            if (this.Blanques.get(i).getClass() == Peo.class) resultat -= 5;
            else if (this.Blanques.get(i).getClass() == Alfil.class) resultat -= 15;
            else if (this.Blanques.get(i).getClass() == Cavall.class) resultat -= 20;
            else if (this.Blanques.get(i).getClass() == Torre.class) resultat -= 30;
            else if (this.Blanques.get(i).getClass() == Dama.class) resultat -= 50;
            else if (this.Blanques.get(i).getClass() == Rei.class) resultat -= 1000;
        }
        return resultat;
    }

    public Boolean peçaAliada(Integer i, Integer j, Boolean esNegre){
        Character c = taulell.get(i).get(j);
        if(esNegre){

            if(Character.isLetter(c)){
                if(Character.isLowerCase(c))return true;
            }
        }
        else{
            if(Character.isLetter(c)){
                if(Character.isUpperCase(c))return true;
            }
        }
        return false;
    }
    public Boolean peçaEnemiga(Integer i, Integer j, Boolean esNegre){
        Character c = taulell.get(i).get(j);
        if(esNegre){
            if(Character.isLetter(c)){
                if(Character.isUpperCase(c)) return true;
            }
        }
        else{
            if(Character.isLetter(c)){
                if(Character.isLowerCase(c))return true;
            }
        }
        return false;
    }

    public  Integer contaNegres(){
        Integer ret = 0;
        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                if(Character.isLetter(taulell.get(i).get(j))){
                    if(Character.isLowerCase(taulell.get(i).get(j)))++ret;
                }
            }
        }
        return ret;
    }

    public  Integer contaBlanques(){
        Integer ret = 0;
        for(int i = 0; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                if(Character.isLetter(taulell.get(i).get(j))){
                    if(Character.isUpperCase(taulell.get(i).get(j)))++ret;
                }
            }
        }
        return ret;
    }

    public void inicialitzarTaulell(ArrayList< ArrayList<Character>> taul){

        Blanques = new ArrayList<>();
        Negres = new ArrayList<>();
        this.taulell = new ArrayList<>();
        for (int i = 0; i < taul.size(); i++) {
            ArrayList<Character> aux = new ArrayList<>();
            for (int j = 0; j < taul.get(i).size(); j++) {
                aux.add(new Character(taul.get(i).get(j)));
            }
            this.taulell.add(aux);
        }
        for(int i = 0 ; i < 8; ++i){
            for(int j = 0; j < 8; ++j){
                Character tmp = taulell.get(i).get(j);
                if(Character.isLetter(tmp)){
                    if(Character.isUpperCase(tmp)){
                        if(tmp == 'N'){ //CAVALL
                            Cavall c = new Cavall();
                            c.setCoordX(i);
                            c.setCoordY(j);
                            Blanques.add(c);
                        }
                        else if(tmp == 'B'){//ALFIL
                            Alfil a = new Alfil();
                            a.setCoordX(i);
                            a.setCoordY(j);
                            Blanques.add(a);
                        }
                        else if(tmp == 'R'){//TORRE
                            Torre t = new Torre();
                            t.setCoordX(i);
                            t.setCoordY(j);
                            Blanques.add(t);
                        }
                        else if(tmp == 'P'){//PEO
                            Peo p = new Peo();
                            p.setCoordX(i);
                            p.setCoordY(j);
                            p.setColor(false);
                            Blanques.add(p);
                        }
                        else if(tmp == 'K'){ //REI
                            Rei r = new Rei();
                            r.setCoordX(i);
                            r.setCoordY(j);
                            Blanques.add(r);
                        }
                        else if(tmp == 'Q'){
                            Dama d = new Dama();
                            d.setCoordX(i);
                            d.setCoordY(j);
                            Blanques.add(d);
                        }


                    }
                    else{
                        if(tmp == 'n'){ //CAVALL
                            Cavall c = new Cavall();
                            c.setCoordX(i);
                            c.setCoordY(j);
                            Negres.add(c);
                        }
                        else if(tmp == 'b'){//ALFIL
                            Alfil a = new Alfil();
                            a.setCoordX(i);
                            a.setCoordY(j);
                            Negres.add(a);
                        }
                        else if(tmp == 'r'){//TORRE
                            Torre t = new Torre();
                            t.setCoordX(i);
                            t.setCoordY(j);
                            Negres.add(t);
                        }
                        else if(tmp == 'p'){//PEO
                            Peo p = new Peo();
                            p.setColor(true);
                            p.setCoordX(i);
                            p.setCoordY(j);;
                            Negres.add(p);
                        }
                        else if(tmp == 'k'){ //REI
                            Rei r = new Rei();
                            r.setCoordX(i);
                            r.setCoordY(j);
                            Negres.add(r);
                        }
                        else if(tmp == 'q'){
                            Dama d = new Dama();
                            d.setCoordX(i);
                            d.setCoordY(j);
                            Negres.add(d);
                        }
                    }
                }
            }
        }
    }
}
