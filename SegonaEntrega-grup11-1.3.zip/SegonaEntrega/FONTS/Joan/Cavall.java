import javafx.util.Pair;

import java.util.ArrayList;

public class Cavall extends Peca {

    public boolean posiciocorrecte(Integer ix, Integer iy, Integer fx, Integer fy) {

        if(estaAlTaulell(ix, iy, fx, fy)) {
            if(ix-2 == fx || ix+2 == fx) {
                if (iy - 1 == fy || iy + 1 == fy) return true;
            }
            else if(ix-1 == fx || ix+1 == fx) {
                if (iy - 2 == fy || iy + 2 == fy) return true;
            }
            return false;
        }
        return false;
    }
    public ArrayList<Pair<Integer, Integer>> direccioMoviment(Integer ix, Integer iy, Integer fx, Integer fy) {
        java.util.ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<Pair<Integer, Integer>>();
        return moviments;
    }

    public ArrayList<Pair <Integer, Integer>> movimentsPossibles(Integer ix, Integer iy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if(!(ix < 0 || ix > 7 || iy < 0 || iy > 7)) {
            if (ix + 2 < 8) {
                if (iy - 1 >= 0) moviments.add(new Pair<>(ix + 2, iy - 1));
                if (iy + 1 < 8) moviments.add(new Pair<>(ix + 2, iy + 1));
            }
            if (ix + 1 < 8) {
                if (iy - 2 >= 0) moviments.add(new Pair<>(ix + 1, iy - 2));
                if (iy + 2 < 8) moviments.add(new Pair<>(ix + 1, iy + 2));
            }
            if (ix - 1 >= 0) {
                if (iy - 2 >= 0) moviments.add(new Pair<>(ix - 1, iy - 2));
                if (iy + 2 < 8) moviments.add(new Pair<>(ix - 1, iy + 2));
            }
            if (ix - 2 >= 0) {
                if (iy - 1 >= 0) moviments.add(new Pair<>(ix - 2, iy - 1));
                if (iy + 1 < 8) moviments.add(new Pair<>(ix - 2, iy + 1));
            }
        }
        return moviments;
    }

}
