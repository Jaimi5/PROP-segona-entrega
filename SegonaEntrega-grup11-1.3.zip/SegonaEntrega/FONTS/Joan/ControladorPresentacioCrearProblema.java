import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.IOException;

public class ControladorPresentacioCrearProblema {

    private Stage st;
    private Integer idUser;

    public TextField fen;
    public TextField moviments;
    public Label error;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuProblema.fxml").openStream());
        ControladorPresentacioMenuProblema controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Administració de problemes");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void guardarProblema(ActionEvent event) throws IOException {
        String f = fen.getText();
        String mov = moviments.getText();
        error.setText("");
        if(f == null || f.isEmpty() || mov.isEmpty() || mov == null) {
            error.setText("No has introduït cap paràmetre");
        }
        else {
            Integer mov1 = Integer.parseInt(mov);
            error.setText("");
            ControladorDomini r = new ControladorDomini();
            Integer i = r.insertarProblema(f, mov1, 0);
            if (i != 0) {
                if (i < 0) error.setText("El problema es pot fer en " + i + " moviments");
                if (i == -1) error.setText("El FEN introduït no és correcte");
                else if (i == -2) error.setText("El número de moviments no és correcte");
                else error.setText("Error");
            } else if (i.equals(0)) {
                r.guardaProblema();
                error.setText("Problema guardat correctament i te la id " + r.problema.getId());
                fen.setText("");
                moviments.setText("");
            }
        }
    }

}
