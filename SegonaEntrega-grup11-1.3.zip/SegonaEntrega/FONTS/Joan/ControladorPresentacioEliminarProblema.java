import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ControladorPresentacioEliminarProblema implements Initializable {

    private Stage st;
    private Integer idUser;

    public ComboBox llista;
    public Label label;


    public void setIdUser(Integer id) { this.idUser = id; }
    public void setStage(Stage stage) {
        this.st = stage;
    }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuProblema.fxml").openStream());
        ControladorPresentacioMenuProblema controller = loader.getController();
        controller.setStage(st);

        st.setTitle("Administració de problemes");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            ControladorDomini r = new ControladorDomini();
            ArrayList<Integer> a = r.getIDProblemes();
            llista.getItems().add(0, "Seleccionar Problema");
            for(int i = 1; i<a.size()+1; i++) {
                llista.getItems().add(i, a.get(i-1).toString());
            }
            llista.getSelectionModel().selectFirst();
        }
        catch(IOException a) {
            System.out.println("Error");
        }
    }

    public void eliminar() throws IOException {
        if(llista.getValue().toString() != "Seleccionar Problema") {
            ControladorDomini r = new ControladorDomini();
            Integer a = Integer.parseInt(llista.getValue().toString());
            if(r.eliminarProblema(a)) {
                ArrayList<Integer> c = r.getIDProblemes();
                llista.getItems().clear();
                llista.getItems().add(0, "Seleccionar Problema");
                for(int i = 1; i<c.size()+1; i++) {
                    llista.getItems().add(i, c.get(i-1).toString());
                }
                llista.getSelectionModel().selectFirst();
                label.setText("Problema eliminat correctament");
            }
            else label.setText("Error a l'eliminar el problema");
        }
    }

}
