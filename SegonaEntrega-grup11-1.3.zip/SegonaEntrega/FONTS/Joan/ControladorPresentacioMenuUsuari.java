import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class ControladorPresentacioMenuUsuari {

        public TextField nom;
        public PasswordField contra;
        public Label nomUsu;
        public Label correcte;

        public void creaUsuari(ActionEvent event) throws IOException {

            ControladorDomini c = new ControladorDomini();
            if(!c.crearUsuari(nom.getText(), contra.getText())) {
                nomUsu.setText("Nom introduït ja existent");
            }
            else {
                correcte.setText("Usuari creat correctament");
            }
        }
}
