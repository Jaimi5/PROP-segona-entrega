import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ControladorPresentacioModificarProblema implements Initializable {

    private Stage st;
    private Integer idUser;

    public ComboBox llista;
    public TextField fen;
    public TextField moviments;
    public Label label;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuProblema.fxml").openStream());
        ControladorPresentacioMenuProblema controller = loader.getController();
        controller.setStage(st);

        st.setTitle("Administració de problemes");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            ControladorDomini r = new ControladorDomini();
            ArrayList<Integer> a = r.getIDProblemes();
            llista.getItems().add(0, "Seleccionar Problema");
            for(int i = 1; i<a.size()+1; i++) {
                llista.getItems().add(i, a.get(i-1).toString());
            }
            llista.getSelectionModel().selectFirst();
        }
        catch(IOException a) {
            System.out.println("Error");
        }
    }

    public void setfen(ActionEvent event) throws IOException {
        ControladorDomini r = new ControladorDomini();
        label.setText("Modifica el Problema desitjat");
        if(llista.getValue().toString() != "Seleccionar Problema") {
            Integer a = Integer.parseInt(llista.getValue().toString());
            Problema p = r.getProblema(a);
            fen.setText(p.getFEN());
            moviments.setText(p.getMoviments().toString());
        }
        else {
            fen.setText("");
            moviments.setText("");
        }
    }

    public void modifica(ActionEvent event) throws IOException {
        ControladorDomini r = new ControladorDomini();
        label.setText("");
        if(llista.getValue().toString() != "Seleccionar Problema") {
            Integer a = Integer.parseInt(llista.getValue().toString());
            Problema p = r.getProblema(a);
            Integer c = r.insertarProblema(fen.getText(), Integer.parseInt(moviments.getText()), p.getId());
            if (c == 0) {
                r.guardaProblema();
                label.setText("Problema modificat correctament");
                fen.setText("");
                moviments.setText("");
            }
            else if(c == -1) {
                label.setText("Error en el FEN");
            }
            else {
                label.setText("Numero de moviments incorrecte");
            }
        }
        else {
            fen.setText("");
            moviments.setText("");
        }
    }

}
