
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class CtrlPersistencia {
    File arxiuP;
    File arxiuH;
    File arxiuG;
    FileReader fr;
    FileWriter fw;
    BufferedReader br;
    String path = "DadesProblema.txt";
    String path2 = "DadesHuma.txt";
    String path3 = "DadesPartidaGuanyada.txt";

    public CtrlPersistencia() {
        arxiuP = null;
        fr = null;
        br = null;
    }

    /** Funció que obra l'arxiu o el crea*/
    public void obrirArxius() throws IOException {
        arxiuP = new File(path);
        if (!arxiuP.exists()) {
            arxiuP.createNewFile();
        }
    }

    /** Funció que tanca l'arxiu*/
    public void tancarArxius() throws IOException {
        arxiuP = null;
        if (fr != null) {
            fr.close();
        }
        if (fw != null) {
            fw.close();
        }
    }

    public void obrirArxiusH() throws IOException {
        arxiuH = new File(path2);
        if (!arxiuH.exists()) {
            arxiuH.createNewFile();
        }
    }

    /** Funció que tanca l'arxiu*/
    public void tancarArxiusH() throws IOException {
        arxiuH = null;
        if (fr != null) {
            fr.close();
        }
        if (fw != null) {
            fw.close();
        }
    }

    public void obrirArxiusG() throws IOException {
        arxiuG = new File(path3);
        if (!arxiuG.exists()) {
            arxiuG.createNewFile();
        }
    }

    /** Funció que tanca l'arxiu*/
    public void tancarArxiusG() throws IOException {
        arxiuG = null;
        if (fr != null) {
            fr.close();
        }
        if (fw != null) {
            fw.close();
        }
    }

    /**
     * Persistencia de Partides Guanyades (Per la persistència de Ranking)
     */

    public void afegirPartidaG(String[] PartidaG) throws IOException {
        if (arxiuG == null) {
            throw new IllegalArgumentException("Error: No tienes ningun archivo abierto.");
        }
        fw = new FileWriter(arxiuG, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        out.print(generarLinea(PartidaG));
        out.close();
    }

    /**
     * Llegeix totes les partides guanyades amb id problema especific
     * @param id
     * @return
     * @throws IOException
     */
    public ArrayList<String[]> llegirPGP(Integer id) throws IOException{
        fr = new FileReader(arxiuG);
        BufferedReader in = new BufferedReader(fr);
        ArrayList<String[]> auxiliar1 = new ArrayList<>();
        String linia;
        String aux = id.toString();
        Integer a = 0;
        while ((linia = in.readLine()) != null) {
            String[] auxiliar = linia.split("_");
            if (auxiliar[0].equals(aux)) {
                in.close();
                auxiliar1.add(auxiliar);
            }
        }
        in.close();
        return auxiliar1;
    }
    /**
     * Llegeix totes les partides guanyades amb id User especific
     * @param id
     * @return
     * @throws IOException
     */
    public ArrayList<String[]> llegirPGUser(Integer id) throws IOException{
        fr = new FileReader(arxiuG);
        BufferedReader in = new BufferedReader(fr);
        ArrayList<String[]> auxiliar1 = new ArrayList<>();
        String linia;
        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            String[] auxiliar = linia.split("_");
            if (auxiliar[3].equals(aux)) {
                auxiliar1.add(auxiliar);
            }
        }
        in.close();
        return auxiliar1;
    }

    public ArrayList<String[]> llegirGTotal() throws IOException{
        fr = new FileReader(arxiuG);
        BufferedReader in = new BufferedReader(fr);
        ArrayList<String[]> auxiliar1 = new ArrayList<>();
        String linia;
        while ((linia = in.readLine()) != null) {
            String[] auxiliar = linia.split("_");
            auxiliar1.add(auxiliar);
        }
        in.close();
        return auxiliar1;
    }

    /**
     * Elimina totes les partides guanyades que tinguin id de l'usuari en questió
     * @param id
     * @throws IOException
     */
    public void eliminarGU(Integer id) throws IOException {
        if (arxiuG == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        ArrayList<String[]> partides = new ArrayList<>();
        fr = new FileReader(arxiuG);
        BufferedReader in = new BufferedReader(fr);
        String linia;

        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            if (!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                if (!auxiliar[3].equals(aux)) {
                    partides.add(auxiliar);
                }
            }
        }
        in.close();
        if (!partides.isEmpty()) {
            String[][] auxiliar1 = new String[partides.size()][partides.get(0).length];
            auxiliar1 = partides.toArray(auxiliar1);

            modificarArxiuG(auxiliar1);
        }
        else {
            String[][] auxiliar1 = new String[0][0];
            auxiliar1 = partides.toArray(auxiliar1);
            modificarArxiuG(auxiliar1);
        }
    }

    /**
     * Elimina totes les partides guanyades que tinguin id del problema en questió
     * @param id
     * @throws IOException
     */
    public void eliminarGP(Integer id) throws IOException {
        if (arxiuG == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        ArrayList<String[]> partides = new ArrayList<>();
        fr = new FileReader(arxiuG);
        BufferedReader in = new BufferedReader(fr);
        String linia;

        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                if (!auxiliar[0].equals(aux)) {
                    partides.add(auxiliar);
                }
            }
        }
        in.close();
        if (!partides.isEmpty()) {
            String[][] auxiliar1 = new String[partides.size()][partides.get(0).length];
            auxiliar1 = partides.toArray(auxiliar1);

            modificarArxiuG(auxiliar1);
        }
        else {
            String[][] auxiliar1 = new String[0][0];
            auxiliar1 = partides.toArray(auxiliar1);
            modificarArxiuG(auxiliar1);
        }
    }

    public void modificarArxiuG(String[][] Humans) throws IOException {
        if (arxiuG == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        fw = new FileWriter(arxiuG, false);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        for (int i = 0; i < Humans.length; ++i) {
            out.print(generarLinea(Humans[i]));
        }
        out.close();
    }

    /**
     * @Humans
     * Persistencia dels Usuaris Humans
     *
     */
    public void afegirHuma(String[] Huma) throws IOException {
        if (arxiuH == null) {
            throw new IllegalArgumentException("Error: No tienes ningun archivo abierto.");
        }
        fw = new FileWriter(arxiuH, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        out.print(generarLinea(Huma));
        out.close();
    }

    public String[] llegirHuma(Integer id) throws IOException{
        fr = new FileReader(arxiuH);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            String[] auxiliar = linia.split("_");
            if (auxiliar[0].equals(aux)) {
                in.close();
                return auxiliar;
            }
        }
        in.close();
        return null;
    }

    public String[] llegirHumaNC(String nom, String contra) throws IOException{
        fr = new FileReader(arxiuH);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        while ((linia = in.readLine()) != null) {
            String[] auxiliar = linia.split("_");
            if (auxiliar[1].equals(nom) && auxiliar[2].equals(contra)) {
                in.close();
                return auxiliar;
            }
        }
        in.close();
        return null;
    }

    public Boolean existeixHuma(String nom) throws IOException {
            if (arxiuH == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

            ArrayList<String[]> humans = new ArrayList<>();
            fr = new FileReader(arxiuH);
            BufferedReader in = new BufferedReader(fr);
            String linia;
            while ((linia = in.readLine()) != null) {
                if(!linia.isEmpty()) {
                    String[] auxiliar = linia.split("_");
                    if (auxiliar[1].equals(nom)) return false;
                }
            }
            in.close();
            return true;
    }

    public void modificarHuma(String[] st) throws IOException {
        if (arxiuH == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        ArrayList<String[]> humans = new ArrayList<>();
        fr = new FileReader(arxiuH);
        BufferedReader in = new BufferedReader(fr);
        String linia;

        String aux = st[0];
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                if (auxiliar[0].equals(aux)) {
                    humans.add(st);
                } else humans.add(auxiliar);
            }
        }
        in.close();

        String[][] auxiliar1 = new String[humans.size()][humans.get(0).length];
        auxiliar1 = humans.toArray(auxiliar1);

        modificarArxiuH(auxiliar1);
    }

    public void modificarArxiuH(String[][] Humans) throws IOException {
        if (arxiuH == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        fw = new FileWriter(arxiuH, false);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        for (int i = 0; i < Humans.length; ++i) {
            out.print(generarLinea(Humans[i]));
        }
        out.close();
    }

    public Integer retornaIdDispH() throws IOException {
        if (arxiuH == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        fr = new FileReader(arxiuH);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        String aux = null;
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                aux = auxiliar[0];
            }
        }
        in.close();
        Integer ret;
        if(aux == null || aux.isEmpty()) {
            ret = 1;
        }
        else {
            ret = Integer.parseInt(aux) + 1;
        }
        return ret;
    }

    public ArrayList<Integer> retornaTotesIdH() throws IOException{
        if (arxiuH == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        ArrayList<Integer> retorn = new ArrayList<>();
        fr = new FileReader(arxiuH);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar;
                auxiliar = linia.split("_");
                retorn.add(Integer.parseInt(auxiliar[0]));
            }
        }
        in.close();
        return retorn;
    }

    public void eliminarH(Integer id) throws IOException {
        if (arxiuH == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        ArrayList<String[]> partides = new ArrayList<>();
        fr = new FileReader(arxiuH);
        BufferedReader in = new BufferedReader(fr);
        String linia;

        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                if (!auxiliar[0].equals(aux)) {
                    partides.add(auxiliar);
                }
            }
        }
        in.close();
        if(!partides.isEmpty()) {
            String[][] auxiliar1 = new String[partides.size()][partides.get(0).length];
            auxiliar1 = partides.toArray(auxiliar1);

            modificarArxiuH(auxiliar1);
        }
        else {
            String[][] auxiliar1 = new String[0][0];
            auxiliar1 = partides.toArray(auxiliar1);
            modificarArxiuH(auxiliar1);
        }
    }


    /**
     * Persistencia dels Problemes
     */
    public void afegirPartida(String[] Partida) throws IOException {
        if (arxiuP == null) {
            throw new IllegalArgumentException("Error: No tienes ningun archivo abierto.");
        }
        fw = new FileWriter(arxiuP, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        out.print(generarLinea(Partida));
        out.close();
    }

    public void eliminarP(Integer id) throws IOException {
        if (arxiuP == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        ArrayList<String[]> partides = new ArrayList<>();
        fr = new FileReader(arxiuP);
        BufferedReader in = new BufferedReader(fr);
        String linia;

        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                if (!auxiliar[0].equals(aux)) {
                    partides.add(auxiliar);
                }
            }
        }
        in.close();
        if (!partides.isEmpty()) {
            String[][] auxiliar1 = new String[partides.size()][partides.get(0).length];
            auxiliar1 = partides.toArray(auxiliar1);

            modificarArxiuP(auxiliar1);
        }
        else {
            String[][] auxiliar1 = new String[0][0];
            auxiliar1 = partides.toArray(auxiliar1);
            modificarArxiuP(auxiliar1);
        }
    }



    /**
     *
     * @param id és la id del problema a trobar
     * @return  Retorna un vector de Strings del problema o retorna a la posició 0 del vector un -1 si no l'ha trobat.
     * @throws IOException
     */

    public String[] llegirProblema(Integer id) throws IOException{
        fr = new FileReader(arxiuP);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        String aux = id.toString();
        while ((linia = in.readLine()) != null) {
            String[] auxiliar = linia.split("_");
            if (auxiliar[0].equals(aux)) {
                in.close();
                return auxiliar;
            }
        }
        in.close();
        return null;
    }

    /**
     *
     * @return retorna un ArrayList de tots els problemes de la base de dades en Strings.
     */

    public ArrayList<String[]> llegirProblemes() throws IOException {
        if(arxiuP == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        fr = new FileReader(arxiuP);
        ArrayList<String[]> partides = new ArrayList<>();
        BufferedReader in = new BufferedReader(fr);
        String linia;
        while((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                partides.add(linia.split("_"));
            }
        }
        in.close();
        return partides;
    }

    /**
     * Donat un string[] modificat aquest l'actualitza a la base de dades.
     * @param st
     * @throws IOException
     */
    public void modificarProblema(String[] st) throws IOException {
        if (arxiuP == null) throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");

        ArrayList<String[]> partides = new ArrayList<>();
        fr = new FileReader(arxiuP);
        BufferedReader in = new BufferedReader(fr);
        String linia;

        String aux = st[0];
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                if (auxiliar[0].equals(aux)) {
                    partides.add(st);
                } else partides.add(auxiliar);
            }
        }
        in.close();

        String[][] auxiliar1 = new String[partides.size()][partides.get(0).length];
        auxiliar1 = partides.toArray(auxiliar1);

        modificarArxiuP(auxiliar1);
    }


    private String generarLinea(String[] partida) {
        String res;
        int n = partida.length;
        res = partida[0];
        for (int i = 1; i < n; ++i) {
            res += "_" + partida[i];
        }
        res += "\n";

        return res;
    }

    public void modificarArxiuP(String[][] Partides) throws IOException {
        if (arxiuP == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        fw = new FileWriter(arxiuP, false);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        for (int i = 0; i < Partides.length; ++i) {
            out.print(generarLinea(Partides[i]));
        }
        out.close();
    }

    /**
     *
     * @return Retorna la primera ID disponible en les dades de problema.
     */
    public Integer retornaIdDisponible() throws IOException {
        if (arxiuP == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        fr = new FileReader(arxiuP);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        String aux = null;
;
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar = linia.split("_");
                aux = auxiliar[0];
            }
        }
        in.close();
        Integer ret;
        if(aux == null || aux.isEmpty()) {
            ret = 1;
        }
        else {
            ret = Integer.parseInt(aux) + 1;
        }
        return ret;
    }

    public ArrayList<Integer> retornaTotesId() throws IOException{
        if (arxiuP == null) {
            throw new IllegalArgumentException("Error: No hi ha cap arxiu obert.");
        }
        ArrayList<Integer> retorn = new ArrayList<>();
        fr = new FileReader(arxiuP);
        BufferedReader in = new BufferedReader(fr);
        String linia;
        while ((linia = in.readLine()) != null) {
            if(!linia.isEmpty()) {
                String[] auxiliar;
                auxiliar = linia.split("_");
                retorn.add(Integer.parseInt(auxiliar[0]));
            }
        }
        in.close();
        return retorn;
    }
}
