import javafx.util.Pair;

import java.util.ArrayList;

public class Dama extends Peca {
    public boolean posiciocorrecte(Integer ix, Integer iy, Integer fx, Integer fy) {
        if(estaAlTaulell(ix, iy, fx, fy)) {
            if(ix.equals(fx) || iy.equals(fy)) return true;
            else if(ix < fx) {
                if(iy > fy && (iy == (fx-ix+fy))) return true;
                else if(iy < fy && (fy == (fx-ix+iy))) return true;
                return false;
            }
            else {
                if (iy > fy && (iy == (ix - fx + fy))) return true;
                else if (iy < fy && fy == (ix - fx + iy)) return true;
                return false;
            }
        }
        return false;
    }

    public ArrayList<Pair<Integer, Integer>> direccioMoviment(Integer ix, Integer iy, Integer fx, Integer fy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if(ix.equals(fx)) { //si entra ja enviarà els moviments que s'haurà de fer i no comprovarà els altres if.
            if (fy > iy) {
                for (Integer i = iy + 1; i < fy; i++) {
                    moviments.add(new Pair<>(fx, i));
                }
            } else {
                for (Integer j = iy - 1; j > fy; j--) {
                    moviments.add(new Pair<>(fx, j));
                }
            }
            return moviments;
        }
        else if (fy.equals(iy)) {
            if (fx > ix) {
                for (Integer i = ix + 1; i < fx; i++) {
                    moviments.add(new Pair<>(i, fy));
                }
            } else {
                for (Integer j = ix - 1; j > fx; j--) {
                    moviments.add(new Pair<>(j, fy));
                }
            }
            return moviments;
        }
        else if(ix < fx) {
            if(iy > fy) {
                Integer auxfy = iy-1;
                for(Integer i = ix+1; i<fx; i++) {
                    moviments.add(new Pair<>(i,auxfy));
                    auxfy--;
                }
                return moviments;
            }
            else {
                Integer auxfy = iy+1;
                for(Integer i = ix+1; i<fx; i++) {
                    moviments.add(new Pair<>(i,auxfy));
                    auxfy++;
                }
                return moviments;
            }

        }
        else {
            if(iy > fy) {
                Integer auxfy = iy-1;
                for(Integer i = ix-1; i>fx; i--) {
                    moviments.add(new Pair<>(i,auxfy));
                    auxfy--;
                }
                return moviments;
            }
            else {
                Integer auxfy = iy+1;
                for(Integer i = ix-1; i>fx; i--) {
                    moviments.add(new Pair<>(i,auxfy));
                    auxfy++;
                }
                return moviments;
            }
        }
    }
    public ArrayList<Pair <Integer, Integer>> movimentsPossibles(Integer ix, Integer iy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();

        if(!(ix < 0 || ix > 7 || iy < 0 || iy > 7)) {
            Integer auxiliar = iy - 1;

            for (Integer i = ix + 1; i < 8; i++) {
                if (auxiliar >= 0) {
                    moviments.add(new Pair<>(i, auxiliar));
                }
                moviments.add(new Pair<>(i, iy));
                auxiliar--;
            }
            auxiliar = ix + 1;
            for (Integer i = iy + 1; i < 8; i++) {
                if (auxiliar <= 7) {
                    moviments.add(new Pair<>(auxiliar, i));
                }
                moviments.add(new Pair<>(ix, i));
                auxiliar++;
            }
            auxiliar = iy + 1;
            for (Integer i = ix - 1; i >= 0; i--) {
                if (auxiliar <= 7) {
                    moviments.add(new Pair<>(i, auxiliar));
                }
                moviments.add(new Pair<>(i, iy));
                auxiliar++;
            }
            auxiliar = ix - 1;
            for (Integer i = iy - 1; i >= 0; i--) {
                if (auxiliar >= 0) {
                    moviments.add(new Pair<>(auxiliar, i));
                }
                moviments.add(new Pair<>(ix, i));
                auxiliar--;
            }
        }
        return moviments;
    }
}