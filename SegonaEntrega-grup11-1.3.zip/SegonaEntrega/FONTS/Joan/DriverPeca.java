import javafx.util.Pair;
import java.util.ArrayList;
import java.util.Scanner;

public class DriverPeca {
    public static void main(String[] args) { //per probar la classe
        Scanner scan = new Scanner(System.in);
        while (true) { //Prova de peons
            ArrayList<ArrayList<Character>> matrix = new ArrayList<>();
            for (int i = 0; i < 8; i++) {
                matrix.add(new ArrayList<>());
                for (int j = 0; j < 8; j++) {
                    matrix.get(i).add('/');
                }
            }

            java.util.ArrayList<Pair<Integer, Integer>> moviments;
            java.util.ArrayList<Pair<Integer, Integer>> movimentsposibles;
            //
            System.out.printf("Esculli la posicio inicial x [0,7]: %n");
            Integer ix = scan.nextInt();
            System.out.printf("Esculli la posicio inicial y [0,7]: %n");

            Integer iy = scan.nextInt();
            System.out.printf("Esculli la posicio final x [0,7]: %n");

            Integer fx = scan.nextInt();
            System.out.printf("Esculli la posicio final y [0,7]: %n");

            Integer fy = scan.nextInt();

            Boolean posicio = false;


            System.out.printf("Esculli una peça a comprovar: %n");
            System.out.printf("0 Alfil, 1 Cavall 2 Dama 3 Peo 4 Torre 5 Rei %n");
            Integer peca = scan.nextInt();


            if (peca.equals(0)) {
                Alfil a = new Alfil();
                posicio = a.posiciocorrecte(ix, iy, fx, fy);
                moviments = a.direccioMoviment(ix, iy, fx, fy);

                movimentsposibles = a.movimentsPossibles(ix, iy);

                System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                if (posicio) {
                    System.out.printf("Camins  disponibles:%n");
                    for (Integer i = 0; i < moviments.size(); i++) {
                        System.out.printf("Cami: %s %n", moviments.get(i));
                    }
                    System.out.printf("%n");
                } else System.out.printf(" cami vuit%n");

                System.out.printf(" Moviments possibles:%n");
                for (Integer i = 0; i < movimentsposibles.size(); i++) {
                    Pair<Integer, Integer> pair = movimentsposibles.get(i);
                    matrix.get(pair.getKey()).set(pair.getValue(), '0');
                    System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                }
            } else if (peca.equals(1)) {
                Cavall c = new Cavall();
                posicio = c.posiciocorrecte(ix, iy, fx, fy);
                moviments = c.direccioMoviment(ix, iy, fx, fy);

                movimentsposibles = c.movimentsPossibles(ix, iy);

                System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                if (posicio) {
                    System.out.printf("Camins  disponibles:%n");
                    for (Integer i = 0; i < moviments.size(); i++) {
                        System.out.printf("Cami: %s %n", moviments.get(i));
                    }
                    System.out.printf("%n");
                } else System.out.printf(" cami vuit%n");

                for (Integer i = 0; i < movimentsposibles.size(); i++) {
                    Pair<Integer, Integer> pair = movimentsposibles.get(i);
                    matrix.get(pair.getKey()).set(pair.getValue(), '0');
                    System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                }
            } else if (peca.equals(2)) {
                Dama d = new Dama();
                posicio = d.posiciocorrecte(ix, iy, fx, fy);
                moviments = d.direccioMoviment(ix, iy, fx, fy);

                movimentsposibles = d.movimentsPossibles(ix, iy);

                System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                if (posicio) {
                    System.out.printf("Camins  disponibles:%n");
                    for (Integer i = 0; i < moviments.size(); i++) {
                        System.out.printf("Cami: %s %n", moviments.get(i));
                    }
                    System.out.printf("%n");
                } else System.out.printf(" cami vuit%n");

                System.out.printf(" Moviments possibles:%n");
                for (Integer i = 0; i < movimentsposibles.size(); i++) {
                    Pair<Integer, Integer> pair = movimentsposibles.get(i);
                    matrix.get(pair.getKey()).set(pair.getValue(), '0');
                    System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                }

            } else if (peca.equals(3)) {
                System.out.printf("Tria el color del peo: 1 negre 0 blanc %n");
                if (scan.nextInt() == 0) {
                    Peo pb = new Peo(); //peo blanc
                    pb.setColor(false);
                    posicio = pb.posiciocorrecte(ix, iy, fx, fy);
                    moviments = pb.direccioMoviment(ix, iy, fx, fy);

                    movimentsposibles = pb.movimentsPossibles(ix, iy);

                    System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                    if (posicio) {
                        System.out.printf("Camins  disponibles:%n");
                        for (Integer i = 0; i < moviments.size(); i++) {
                            System.out.printf("Cami: %s %n", moviments.get(i));
                        }
                        System.out.printf("%n");
                    } else System.out.printf(" cami vuit%n");

                    System.out.printf(" Moviments possibles:%n");
                    for (Integer i = 0; i < movimentsposibles.size(); i++) {
                        Pair<Integer, Integer> pair = movimentsposibles.get(i);
                        matrix.get(pair.getKey()).set(pair.getValue(), '0');
                        System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                    }
                } else {
                    Peo pn = new Peo(); //peo negre
                    pn.setColor(true);
                    posicio = pn.posiciocorrecte(ix, iy, fx, fy);
                    moviments = pn.direccioMoviment(ix, iy, fx, fy);

                    movimentsposibles = pn.movimentsPossibles(ix, iy);

                    System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                    if (posicio) {
                        System.out.printf("Camins  disponibles:%n");
                        for (Integer i = 0; i < moviments.size(); i++) {
                            System.out.printf("Cami: %s %n", moviments.get(i));
                        }
                        System.out.printf("%n");
                    } else System.out.printf(" cami vuit%n");

                    System.out.printf(" Moviments possibles:%n");
                    for (Integer i = 0; i < movimentsposibles.size(); i++) {
                        Pair<Integer, Integer> pair = movimentsposibles.get(i);
                        matrix.get(pair.getKey()).set(pair.getValue(), '0');
                        System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                    }
                }
            } else if (peca.equals(4)) {
                Torre t = new Torre();
                posicio = t.posiciocorrecte(ix, iy, fx, fy);
                moviments = t.direccioMoviment(ix, iy, fx, fy);

                movimentsposibles = t.movimentsPossibles(ix, iy);

                System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                if (posicio) {
                    System.out.printf("Camins  disponibles:%n");
                    for (Integer i = 0; i < moviments.size(); i++) {
                        System.out.printf("Cami: %s %n", moviments.get(i));
                    }
                    System.out.printf("%n");
                } else System.out.printf(" cami vuit:%n");

                System.out.printf(" Moviments possibles:%n");
                for (Integer i = 0; i < movimentsposibles.size(); i++) {
                    Pair<Integer, Integer> pair = movimentsposibles.get(i);
                    matrix.get(pair.getKey()).set(pair.getValue(), '0');
                    System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                }
            } else if (peca.equals(5)) {
                Rei r = new Rei();
                posicio = r.posiciocorrecte(ix, iy, fx, fy);
                moviments = r.direccioMoviment(ix, iy, fx, fy);

                movimentsposibles = r.movimentsPossibles(ix, iy);

                System.out.printf("La posicio inicial " + ix + ":" + iy + " i final " + fx + ":" + fy + " es: %n%s %n", posicio);
                if (posicio) {
                    System.out.printf("Camins  disponibles:%n");
                    for (Integer i = 0; i < moviments.size(); i++) {
                        System.out.printf("Cami: %s %n", moviments.get(i));
                    }
                    System.out.printf("%n");
                } else System.out.printf(" cami vuit%n");

                System.out.printf(" Moviments possibles:%n");
                for (Integer i = 0; i < movimentsposibles.size(); i++) {
                    Pair<Integer, Integer> pair = movimentsposibles.get(i);
                    matrix.get(pair.getKey()).set(pair.getValue(), '0');
                    System.out.printf(" cami: %s %n", movimentsposibles.get(i));
                }

            }
            System.out.printf("\n");
            System.out.println("  0 1 2 3 4 5 6 7");
            for (int i = 0; i < 8; ++i) {
                System.out.printf("%c", i + 65);
                for (int j = 0; j < 8; ++j) {
                    System.out.printf(" %s", matrix.get(i).get(j));
                }
                System.out.printf("%n");
            }
        }
    }
}

