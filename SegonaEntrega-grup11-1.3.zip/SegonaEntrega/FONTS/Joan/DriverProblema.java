import javafx.util.Pair;
import java.util.ArrayList;
import java.util.Scanner;

public class DriverProblema {

    public static void main(String[] args) { //per probar la classe

        while(true) {
            Problema prova = new Problema();
            Scanner scan = new Scanner(System.in);
            System.out.printf("Introdueixi el FEN del problema: %n");
            String fen = scan.nextLine();

            while(prova.setFEN(fen).equals(-1)) {
                System.out.printf("Introdueixi el FEN del problema: %n");
                fen = scan.nextLine();
            }
            System.out.printf("Introdueixi el numero de moviments: Mínim 1 %n");
            Integer ix = scan.nextInt();
            Integer a = prova.setMoviments(ix);
            if(a.equals(0)) {
                String comenca;
                if(prova.isStart()) comenca = "Blanques";
                else comenca = "Negres";
                prova.setEnunciat("Escac en "+ ix + " moviments, comença " + comenca + ", té " + prova.getPecesblanques() + " peces blanques i " + prova.getPecesnegres() + " peces negres i té una Dificultat " + prova.getDificultat());
                System.out.printf(prova.getEnunciat() + "%n");
            }
            else if(a > 0){
                System.out.printf("Masses moviments: es pot fer escac i mat en: %d moviments.%n",ix - a  );
            }
            else if(a.equals(-2)){
                System.out.println("S'ha acabat la partida sense escac i mat");
            }
            else {
                System.out.println("Error");
            }
        }
    }
}


