import java.util.ArrayList;

public class PartidaGuanyada {
    private Long temps; //Temps del guanyador!!
    private Problema problema;
    private Integer numeroMoviments;
    private Integer puntuacioguanyador;
    private Partida partidaguanyadora;
    private Huma usuariguanyador;
    private String nomusuari;
    private ArrayList< ArrayList< ArrayList<Character>>> estatsTaulell; //tots els taulells que shan donat durant la partida


    public Long getTemps() {
        return temps;
    }

    public Integer getPuntuacioguanyador() {
        return puntuacioguanyador;
    }

    public String getNomusuari() { return nomusuari; }

    public Partida getPartidaguanyadora() { return partidaguanyadora; }

    public Huma getUsuariguanyador() {
        return usuariguanyador;
    }

    public Problema getProblema() { return problema; }



    public void setProblema(Problema p) { this.problema = p; }

    public void setTemps(Long temps) { this.temps = temps; }

    public void setPuntuacioguanyador(Integer puntuacioguanyador) {
        this.puntuacioguanyador = puntuacioguanyador;
    }

    public void setNomusuari(String nomusuari) { this.nomusuari = nomusuari; }

    public void setPartidaguanyadora(Partida partidaguanyadora) {
        this.partidaguanyadora = partidaguanyadora;
    }

    public void setUsuariguanyador(Huma usuariguanyador) {
        this.usuariguanyador = usuariguanyador;
    }



    public PartidaGuanyada(Long temps, Integer puntuacio, Problema p, Huma h){
        this.temps = temps;
        this.puntuacioguanyador = puntuacio;
        this.problema = p;
        this.usuariguanyador = h;
    }

    public PartidaGuanyada(Integer numeroMoviments){
        this.numeroMoviments = numeroMoviments;
    }

}
