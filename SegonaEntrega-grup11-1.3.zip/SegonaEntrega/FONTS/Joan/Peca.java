import javafx.util.Pair;

import java.util.ArrayList;

//todo:
public abstract class Peca {
    protected Integer CoordX;
    protected Integer CoordY;

    public Integer getCoordX() { return this.CoordX; }

    public Integer getCoordY() { return this.CoordY; }

    public void setCoordX(Integer coordX) { CoordX = coordX; }

    public void setCoordY(Integer coordY) { CoordY = coordY; }
    //Pre:
    //Post: Retorna si la posició final en una posició final es correcte
    abstract boolean posiciocorrecte(Integer ix, Integer iy, Integer fx, Integer fy);//

    //Pre: La posició final ha de ser una posiciocorrecte()
    //Post: Retorna un Array del camí que ha de fer per arribar a la posicio final
    abstract ArrayList<Pair <Integer, Integer>> direccioMoviment(Integer ix, Integer iy, Integer fx, Integer fy);

    //Pre:
    //Post: Torna un array de posicions posibles que pot fer aquella peça en una posicio inicial donada.
    //La posicio inicial no estara en aquest arraylist, ja que no es un moviment possible.
    abstract ArrayList<Pair <Integer, Integer>> movimentsPossibles(Integer ix, Integer iy);

    
    public boolean estaAlTaulell(Integer ix, Integer iy, Integer fx, Integer fy) {
        if(ix.equals(fx) && iy.equals(fy)) return false;
        if(ix < 0 || ix > 7 || fx < 0 || fx > 7 || iy < 0 || iy > 7 || fy <0 || fy > 7) return false;
        return true;
    }
    
}
