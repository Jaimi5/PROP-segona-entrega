import javafx.util.Pair;

import java.util.ArrayList;

public class Peo extends Peca {

    private Boolean negre;
    public Boolean getColor() {

        return negre;
    }
    public void setColor(Boolean color) {

        this.negre = color;
    }

    public boolean posiciocorrecte(Integer ix, Integer iy, Integer fx, Integer fy) {
        if(estaAlTaulell(ix, iy, fx, fy)) {
            if (this.negre != null && this.negre) {
                if (ix == 1) {
                    if ((ix + 1 == fx || ix + 2 == fx) && (iy.equals(fy))) return true;
                } else if ((ix + 1 == fx) && (iy.equals(fy))) return true;

                return false;
            }
            else if(this.negre != null){
                if (ix == 6) {
                    if ((ix - 1 == fx || ix - 2 == fx) && (iy.equals(fy))) return true;

                } else if ((ix - 1 == fx) && (iy.equals(fy))) return true;

                return false;
            }
        }
        return false;
    }

    public ArrayList<Pair<Integer, Integer>> direccioMoviment(Integer ix, Integer iy, Integer fx, Integer fy) {
        java.util.ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if (this.negre != null && this.negre) {
            if (ix == 1 && ix+2 == fx) {
                moviments.add(new Pair<>(ix+1,fy));
                return moviments;
            }
        }
        else if(this.negre != null) {
            if(ix == 6 && ix-2 == fx) {
                moviments.add(new Pair<>(ix-1,fy));
                return moviments;
            }
        }
        return moviments;
    }

    public ArrayList<Pair <Integer, Integer>> movimentsPossibles(Integer ix, Integer iy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if(!(ix < 0 || ix > 7 || iy < 0 || iy > 7)) {
            if (this.negre != null && this.negre) {
                if (ix == 1) {
                    moviments.add(new Pair<>(ix + 2, iy));
                }
                if (ix + 1 < 8) {
                    moviments.add(new Pair<>(ix + 1, iy));
                }
            } else if(this.negre != null){
                if (ix == 6) {
                    moviments.add(new Pair<>(ix - 2, iy));
                }
                if (ix - 1 >= 0) {
                    moviments.add(new Pair<>(ix - 1, iy));
                }
            }
        }
        return moviments;
    }

}
