import javafx.util.Pair;

import java.io.Console;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


public class Problema {

    private String enunciat; //descripció que dirà quin problema és. Ex: "escac en 3 per blanques".

    private String FEN;

    private ArrayList<ArrayList <Character> > matrix = new ArrayList<>();

    private boolean start; // true blanques, false negres

    private Integer id;

    //classificacio d'aquest problema

    private Integer pecesblanques = 0;

    private Integer pecesnegres = 0;

    private Integer moviments;

    private String dificultat; //Dificultat Baixa, Dificultat Mitja i Dificultat Alta



    public ArrayList<ArrayList<Character>> getMatrix() {
        return matrix;
    }

    public Integer getMoviments() { return moviments; }

    public boolean isStart() { return start; }

    public void setStart(boolean start) { this.start = start; }

    public void setMatrix(ArrayList<ArrayList<Character>> matrix) { this.matrix = matrix; }

    public Integer getPecesblanques() { return pecesblanques; }

    public String getFEN() { return this.FEN; }

    public String getDificultat() { return this.dificultat; }

    public String getEnunciat() { return this.enunciat; }

    public Integer getPecesnegres() { return pecesnegres; }

    public Integer getId() { return this.id; }



    public void setPecesnegres(Integer pecesnegres) { this.pecesnegres = pecesnegres; }

    public void setPecesblanques(Integer pecesblanques) { this.pecesblanques = pecesblanques; }

    public void setEnunciat(String enun) { this.enunciat = enun; }

    public void setId(Integer id1) { id = id1; }

    public void setMovimentss(Integer moviments) { this.moviments = moviments;    }

    public void escriuPecesBlanques() { System.out.printf("num peces = %s%n", this.pecesblanques); }

    public void escriuPecesNegres() { System.out.printf("num peces = %s%n", this.pecesnegres); }


    public Integer setFEN(String FEN) {
        setMatrix();
        this.FEN = FEN;
        return convert(FEN);
    }

    public Integer setMoviments(Integer moviments) {
        this.moviments = moviments;
        defineixDificultat();
        return esPossible();
    }

    public void setMatrix() {
        for(int i = 0; i<8; i++) {
            matrix.add(new ArrayList<>());
            for(int j = 0; j<8; j++) {
                matrix.get(i).add('/');
            }
        }
    }
    public void escriuMatrix() {
        System.out.printf("\n");
        System.out.println("  0 1 2 3 4 5 6 7");
        for (int i = 0; i < 8; ++i) {
            System.out.printf("%c", i + 65);
            for (int j = 0; j < 8; ++j) {
                System.out.printf(" %s", matrix.get(i).get(j));
            }
            System.out.printf("%n");
        }
    }

    public Integer esPossible() {

        MaquinaSmart m1 = new MaquinaSmart(true);
        Taulell taulell = new Taulell();
        taulell.inicialitzarTaulell(matrix);
        if(m1.validar(taulell, !this.start, moviments)) {
            return 0;
        }
        else return -1;
        /*
        MaquinaGreedy m2 = new MaquinaGreedy(false);
        Partida p = new Partida();
        Problema prob = new Problema();
        prob.setMatrix(this.getMatrix());
        prob.setMovimentss(this.getMoviments());
        prob.setStart(this.isStart());
        p.inicialitzarPartida(m1, m2, prob);
        prob.escriuMatrix();
        p.jugar();
        if(p.getEndGame() && p.getMoviments_restants().equals(0)) {
            return 0;
        }
        else if(p.getEndGame() && p.getMoviments_restants() > 0){
            return p.getMoviments_restants();
        }
        else if(!p.getEndGame()) {
            return -2;
        }
        return -1;*/
    }

    private void defineixDificultat() {//definir la dificultat del problema en funcio dels moviments i el numero de peces
        if(start) {
            if(pecesblanques < 5 && moviments < 3) dificultat = "Baixa";
            else if (pecesblanques >= 5 && moviments >=3 && pecesblanques < 10 && moviments <6) dificultat = "Mitja";
            else dificultat = "Dificil";
        }
        else {
            if(pecesnegres < 5 && moviments < 3) dificultat = "Baixa";
            else if (pecesnegres >= 5 && moviments >=3 && pecesnegres < 10 && moviments <6) dificultat = "Mitja";
            else dificultat = "Dificil";
        }
    }

    private void converteix(){
        ArrayList<ArrayList<Character>> hola = new ArrayList<>();
        Integer x = 7;
        for(Integer i = 0; i<8; i++) {
            hola.add(i, this.matrix.get(x));
            x--;
        }
        matrix = hola;
    }

    private Integer convert(String FEN) {
        Integer reib = 0;
        Integer rein = 0;
        Integer x = 7;
        Integer barra = 0;
        Integer linies = 0;
        Integer numeros = 0;
        Integer espais = 0;
        int y = 0;

        for (int i = 0; i < FEN.length(); ++i) {
            Character b = FEN.charAt(i);
            if (x == 0 && y > 7) {
                Character c = FEN.charAt(i);

                if(espais.equals(0)) {
                    espais++;
                    if(!(c.equals(' '))){
                        System.out.printf("Error en la posició %s del FEN, error en els espais.%n", i);
                        return -1;
                    }
                }

                else if(espais.equals(1)) {
                    espais++;
                    if (c == 'w') start = true;
                    else if (c == 'b') start = false;
                    else {
                        System.out.printf("Error en la posició %s del FEN, el primer jugador indicat no és el correcte.%n", i);
                        return -1;
                    }
                }


                else {
                    if(c.equals(' ')) {
                        espais++;
                        if(espais > 10) {
                            System.out.printf("Error en la posició %s del FEN, Massa espais.%n", i);
                            return -1;
                        }
                    }
                    else if(c.equals('–') || c.equals('-')) {
                        linies++;
                        if(linies > 2) {
                            System.out.printf("Error en la posició %s del FEN, Massa línies. %n", i);
                            return -1;
                        }
                    }
                    else if(c.equals('1') || c.equals('0')) {
                        numeros++;
                        if(numeros > 2) {
                            System.out.printf("Error en la posició %s del FEN, Massa números al final.%n", i);
                            return -1;
                        }
                    }
                    else {
                        System.out.printf("Error en la posició %s del FEN.%n", i);
                        return -1;
                    }
                }

            }
            else if (y > 8) {
                System.out.printf("Error en la posició %s del FEN, s'ha superat el limit d'espais i/o peces de la línia. %n", i);
                return -1;
            }
            else if (Character.isDigit(FEN.charAt(i))) {
                y += FEN.charAt(i) - '0';
            }

            else if (Character.isLetter(FEN.charAt(i))) {
                if(b.equals('n') || b.equals('N') ||  b.equals('b') || b.equals('B') || b.equals('r') || b.equals('R') || b.equals('P') ||
                        b.equals('p') || b.equals('q') || b.equals('Q') || b.equals('k') || b.equals('K')) {
                    if(Character.isUpperCase(FEN.charAt(i))) this.pecesblanques++;
                    else this.pecesnegres++;
                    Character t = FEN.charAt(i);
                    matrix.get(x).set(y, t);
                    y += 1;

                    if (b.equals('k')) {
                        rein += 1;
                        if (rein > 1) {
                            System.out.printf("Error en la posició %s del FEN, hi ha més de dos reis negres %n", i);
                            return -1;
                        }
                    } else if (b.equals('K')) {
                        reib += 1;
                        if (reib > 1) {
                            System.out.printf("Error en la posició %s del FEN, hi ha més de dos reis blancs %n", i);
                            return -1;
                        }
                    }
                }
                else {
                    System.out.printf("La peça %s no es cap peça reconeguda %n", b);
                    return -1;
                }
            }
            else if (b.equals('/')) {
                barra++;
                if(y < 7) {
                    System.out.printf("Error en la posició %s del FEN, falten valors dins del la línia %n", i);
                    return -1;
                }
                else {
                    y = 0;
                    x -= 1;
                }
            }
        }
        if (barra != 7) {
            System.out.printf("Error: Falten línies a declarar %n");
            return -1;
        }
        converteix();
        return 1;
    }
}

