import com.sun.org.apache.xpath.internal.operations.Bool;
import javafx.util.Pair;

import java.util.ArrayList;

public class Ranking {
    private ArrayList<Problema> problemesTotals = new ArrayList<>(); //Array de problemes que han aconseguit una partida guanyada.
    private ArrayList<PartidaGuanyada> partidesguanyadores = new ArrayList<>();
    private ArrayList<ArrayList<PartidaGuanyada>> pguanyatsid = new ArrayList<>(); //Classificacio per ID
    private ArrayList<ArrayList<PartidaGuanyada>> pguanyatspunts = new ArrayList<>(); //Classificacio per ID i punts
    private ArrayList<ArrayList<PartidaGuanyada>> pguanyatstemps = new ArrayList<>(); //Classificacio per ID i temps
    private ArrayList<PartidaGuanyada> tempsglobal = new ArrayList<>(); //Classificacio per temps global
    private ArrayList<PartidaGuanyada> puntuacioglobal = new ArrayList<>(); //Classificacio per punts global


    public ArrayList<Problema> getProblemesTotals() { return problemesTotals; }

    public ArrayList<PartidaGuanyada> getPartidesguanyadores() { return partidesguanyadores;    }

    public ArrayList<ArrayList<PartidaGuanyada>> getPguanyatsid() { return pguanyatsid;    }

    public ArrayList<ArrayList<PartidaGuanyada>> getPguanyatspunts() { return pguanyatspunts;    }

    public ArrayList<ArrayList<PartidaGuanyada>> getPguanyatstemps() { return pguanyatstemps;    }

    public ArrayList<PartidaGuanyada> getTempsglobal() { return tempsglobal;    }

    public ArrayList<PartidaGuanyada> getPuntuacioglobal() { return puntuacioglobal;    }


    //Post: retorna -1 si no ha trobat el problema, retorna la posicio dels rankings del problema
    public Integer buscaProblema(Problema p) {
        Integer id = -1;
        for(int i = 0; i < problemesTotals.size() && id.equals(-1); i++) {
            if(problemesTotals.get(i).getId() == p.getId()) id = i;
        }
        return id;
    }

    //PRE: El problema p ha d'estar a dins de problemesTotals
    //POST: Elimina totes les partides guanyades que contenen la partida p
    public void eliminadeRankings(Problema p) { //Elimina un problema de tots els rankings
        int id = this.buscaProblema(p);
        if(this.problemesTotals.size() == 1) {
            this.problemesTotals = new ArrayList<>(); //Array de problemes que han aconseguit una partida guanyada.
            this.partidesguanyadores = new ArrayList<>();
            this.pguanyatsid = new ArrayList<>(); //Classificacio per ID
            this.pguanyatspunts = new ArrayList<>(); //Classificacio per ID i punts
            this.pguanyatstemps = new ArrayList<>(); //Classificacio per ID i temps
            this.tempsglobal = new ArrayList<>(); //Classificacio per temps global
            this.puntuacioglobal = new ArrayList<>(); //Classificacio per temps global
        }
        else {
            this.problemesTotals.remove(id);

            for (int i = 0; i < 10; i++) {
                Boolean trobat = false;
                if (i < this.partidesguanyadores.size() && this.partidesguanyadores.get(i).getProblema().getId() == p.getId()) {
                    this.partidesguanyadores.remove(i);
                    trobat = true;
                }

                if (i < this.tempsglobal.size() && this.tempsglobal.get(i).getProblema().getId() == p.getId()) {
                    this.tempsglobal.remove(i);
                    trobat = true;
                }

                if (i < this.puntuacioglobal.size() && this.puntuacioglobal.get(i).getProblema().getId() == p.getId()) {
                    this.puntuacioglobal.remove(i);
                    trobat = true;
                }
                if(trobat) i--;
            }
            this.pguanyatsid.remove(id);
            this.pguanyatstemps.remove(id);
            this.pguanyatspunts.remove(id);
        }
    }

    public void afegirPartida(PartidaGuanyada p) {
        Boolean trobat = false;
        Integer x = 0;
        if(this.problemesTotals.size() == 0) {
            this.problemesTotals.add(p.getProblema());
            trobat = true;
        }
        while(!trobat && this.problemesTotals.size() > x) {
            if(problemesTotals.get(x).getId() == p.getProblema().getId()) {
                trobat = true;
            }
            x++;
        }
        if(!trobat) {
            this.problemesTotals.add(p.getProblema());
        }
        this.partidesguanyadores.add(p);
        this.setPguanyatsid(p);
        this.setPguanyatspunts(p);
        this.setPguanyatstemps(p);
        this.setPglobaltemps(p);
        this.setPglobalPuntuacio(p);
    }

    public void setPartidesguanyadores(ArrayList<PartidaGuanyada> partidesguanyadores) {
        this.partidesguanyadores = partidesguanyadores;
    }

    public void setPguanyatsid(PartidaGuanyada p) {
        Problema r = p.getProblema();
        Integer ix = this.buscaProblema(r);
        if(this.pguanyatsid.size() <= ix) {
            ArrayList<PartidaGuanyada> l = new ArrayList<>();
            l.add(p);
            this.pguanyatsid.add(l);
        }
        else if(this.pguanyatsid.size() > ix){
            this.pguanyatsid.get(ix).add(p);
        }
    }

    public void setPguanyatspunts(PartidaGuanyada p) {
        Integer i = p.getPuntuacioguanyador();
        Problema r = p.getProblema();
        Integer ix = this.buscaProblema(r);
        Integer x = 0;
        Boolean nottrobat = false;
        if(this.pguanyatspunts.size() <= ix) {
            ArrayList<PartidaGuanyada> l = new ArrayList<>();
            l.add(p);
            this.pguanyatspunts.add(l);
            nottrobat = true;
        }
        while (!nottrobat && x < this.pguanyatspunts.get(ix).size()) {
            Integer a = this.pguanyatspunts.get(ix).get(x).getPuntuacioguanyador();
            if (a < i) {
                this.pguanyatspunts.get(ix).add(x, p);
                nottrobat = true;
                while(this.pguanyatspunts.get(ix).size() > 10) this.pguanyatspunts.get(ix).remove(10);

            }
            x++;
        }
        if(x < 10 && !nottrobat) {
            this.pguanyatspunts.get(ix).add(x, p);
        }
    }

    public void setPglobalPuntuacio(PartidaGuanyada p) {
        Integer i = p.getPuntuacioguanyador();
        Integer x = 0;
        Boolean nottrobat = false;

        if(this.puntuacioglobal.size() == 0) {
            this.puntuacioglobal.add(p);
            nottrobat = true;
        }
        while (!nottrobat && x < this.puntuacioglobal.size()) {
            Integer a = this.puntuacioglobal.get(x).getPuntuacioguanyador();
            if (a < i) {
                this.puntuacioglobal.add(x, p);
                nottrobat = true;
                while(this.puntuacioglobal.size() > 10) this.puntuacioglobal.remove(10);
            }
            x++;
        }
        if(x < 10 && !nottrobat) {
            this.puntuacioglobal.add(x, p);
        }
    }


    public void setPglobaltemps(PartidaGuanyada p) {
        Long temps = p.getTemps();
        Integer x = 0;
        Boolean nottrobat = false;

        if(this.tempsglobal.size() == 0) {
            this.tempsglobal.add(p);
            nottrobat = true;
        }

        while (!nottrobat && x < this.tempsglobal.size()) {
            Long a = this.tempsglobal.get(x).getTemps();
            if (temps < a) {
                this.tempsglobal.add(x, p);
                nottrobat = true;
                while(this.tempsglobal.size() > 10) this.tempsglobal.remove(10);
            }
            x++;
        }
        if(x < 10 && !nottrobat) {
            this.tempsglobal.add(x, p);
        }
    }

    public void setPguanyatstemps(PartidaGuanyada p) {
        Long temps = p.getTemps();
        Problema r = p.getProblema();
        Integer ix = this.buscaProblema(r);

        Integer x = 0;
        Boolean nottrobat = false;

        if(this.pguanyatstemps.size() <= ix) {
            ArrayList<PartidaGuanyada> l = new ArrayList<>();
            l.add(p);
            this.pguanyatstemps.add(l);
            nottrobat = true;
        }

        while (!nottrobat && x < this.pguanyatstemps.get(ix).size()) {
            Long a = this.pguanyatstemps.get(ix).get(x).getTemps();
            if (temps < a) {
                this.pguanyatstemps.get(ix).add(x, p);
                nottrobat = true;
                while(this.pguanyatstemps.get(ix).size() > 10) this.pguanyatstemps.get(ix).remove(10);

            }
            x++;
        }
        if(x < 10 && !nottrobat) {
            this.pguanyatstemps.get(ix).add(x, p);
        }

    }

}
