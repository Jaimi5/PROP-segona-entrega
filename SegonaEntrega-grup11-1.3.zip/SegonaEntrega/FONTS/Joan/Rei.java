import javafx.util.Pair;

import java.util.ArrayList;

public class Rei extends Peca {



    public boolean posiciocorrecte(Integer ix, Integer iy, Integer fx, Integer fy) {
        if(estaAlTaulell(ix, iy, fx, fy)) {
            if ((ix - 1 == fx && iy.equals(fy)) || (ix + 1 == fx && iy.equals(fy)) || (ix.equals(fx) && iy - 1 == fy) || (ix.equals(fx) && iy + 1 == fy) ||
                    (ix - 1 == fx && iy - 1 == fy) || (ix - 1 == fx && iy + 1 == fy) || (ix + 1 == fx && iy - 1 == fy) || (ix + 1 == fx && iy + 1 == fy)) return true;
            else return false;
        }

        return false;

    }

    public ArrayList<Pair<Integer, Integer>> direccioMoviment(Integer ix, Integer iy, Integer fx, Integer fy) {
        java.util.ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        return moviments;
    }

    public ArrayList<Pair <Integer, Integer>> movimentsPossibles(Integer ix, Integer iy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if(!(ix < 0 || ix > 7 || iy < 0 || iy > 7)) {
            for (Integer i = ix - 1; i < ix + 2; i++) {
                for (Integer j = iy - 1; j < iy + 2; j++) {
                    if (!((i.equals(ix) && j.equals(iy)) || i < 0 || j < 0 || i > 7 || j > 7)) {
                        moviments.add(new Pair<>(i, j));
                    }
                }
            }
        }
        return moviments;
    }

}
