import javafx.util.Pair;

import java.util.ArrayList;

public class Torre extends Peca {

    public boolean posiciocorrecte(Integer ix, Integer iy, Integer fx, Integer fy) {
        if(estaAlTaulell(ix, iy, fx, fy)) {
            if(ix.equals(fx) || iy.equals(fy)) return true;
            return false;
        }
        return false;
    }

    public ArrayList<Pair<Integer, Integer>> direccioMoviment(Integer ix, Integer iy, Integer fx, Integer fy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if (ix.equals(fx)) { //si entra ja enviarà els moviments que s'haurà de fer i no comprovarà els altres if.
            if (fy > iy) {
                for (Integer i = iy + 1; i < fy; i++) {
                    moviments.add(new Pair<>(fx, i));
                }
            } else {
                for (Integer j = iy - 1; j > fy; j--) {
                    moviments.add(new Pair<>(fx, j));
                }
            }
            return moviments;
        } else if (fy.equals(iy)) {
            if (fx > ix) {
                for (Integer i = ix + 1; i < fx; i++) {
                    moviments.add(new Pair<>(i, fy));
                }
            } else {
                for (Integer j = ix - 1; j > fx; j--) {
                    moviments.add(new Pair<>(j, fy));
                }
            }
            return moviments;
        }
        return moviments;
    }

    public ArrayList<Pair <Integer, Integer>> movimentsPossibles(Integer ix, Integer iy) {
        ArrayList<Pair<Integer, Integer>> moviments = new ArrayList<>();
        if(!(ix < 0 || ix > 7 || iy < 0 || iy > 7)) {
            for (Integer i = ix + 1; i < 8; i++) moviments.add(new Pair<>(i, iy));
            for (Integer i = iy + 1; i < 8; i++) moviments.add(new Pair<>(ix, i));
            for (Integer i = ix - 1; i >= 0; i--) moviments.add(new Pair<>(i, iy));
            for (Integer i = iy - 1; i >= 0; i--) moviments.add(new Pair<>(ix, i));
        }

        return moviments;
    }

}
