import org.junit.Test;
import java.util.ArrayList;
import java.util.Arrays;
import static org.junit.Assert.*;


public class jUnitRanking {
    private Problema p1;
    private Problema p2;
    private Problema p3;
    private Problema p4;
    private PartidaGuanyada pg1;
    private PartidaGuanyada pg2;
    private PartidaGuanyada pg3;
    private PartidaGuanyada pg4;
    private Integer puntuacio1;
    private Integer puntuacio2;
    private Long temps1;
    private Long temps2;

    @Test
    /**
     * Afegim dos Partides Guanyades i comprovem si s'afegeixen els problemes de les partides guanyades
     * al arraylist de problemes
     */
    public void getProblemesTotals() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(temps1, puntuacio1, this.p1, null);
        this.pg2 = new PartidaGuanyada(temps2,  puntuacio2, this.p2, null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg2);
        ArrayList<Problema> expected = new ArrayList<Problema>(Arrays.asList(p1,p2));
        assertEquals(expected, r.getProblemesTotals());
    }

    @Test
    /**
     * Afegim tres Partides Guanyades i comprovem si s'afegeixen els problemes al arraylist de partides guanyades
     */
    public void getPartidesguanyadores() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(temps1, puntuacio1, this.p1, null);
        this.pg2 = new PartidaGuanyada(temps2,  puntuacio2, this.p2, null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg2);
        r.afegirPartida(pg1);
        ArrayList<PartidaGuanyada> expected = new ArrayList<PartidaGuanyada>(Arrays.asList(pg1,pg2, pg1));
        assertEquals(expected, r.getPartidesguanyadores());
    }

    @Test
    /**
     * Afegim 4 partides guanyades on pg1 i pg3 conté el 1 problema i pg2 té un altre problema
     * El que es vol estudiar es si al cridar getPguanyatsid() ens retorna dos arraylist classificat per
     * problemes i ordenat per punts.
     */
    public void getPguanyatsid() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(temps1,puntuacio1, this.p1, null);
        this.pg2 = new PartidaGuanyada(temps2,  puntuacio2, this.p2,null);
        this.pg3 = new PartidaGuanyada(temps1,  puntuacio1, this.p1,null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg2);
        r.afegirPartida(pg1);
        r.afegirPartida(pg3);
        ArrayList<PartidaGuanyada> array1 = new ArrayList<PartidaGuanyada>(Arrays.asList(pg1,pg1,pg3));
        ArrayList<PartidaGuanyada> array2 = new ArrayList<PartidaGuanyada>(Arrays.asList(pg2));
        ArrayList<ArrayList<PartidaGuanyada>> expected = new ArrayList<ArrayList<PartidaGuanyada>>(Arrays.asList(array1, array2));
        assertEquals(expected, r.getPguanyatsid());
    }

    @Test
    /**
     * Afegim 14 partides guanyades on pg1 i pg3 conté el 1 problema i pg2 i pg4 té un altre problema
     * El que es vol estudiar es si al cridar getPguanyatsid() ens retorna dos arraylist classificat per
     * problemes i ordenat per punts i que si es supera en 10 les partides guanyades en un ranking,
     * aquest ranking nomes hi haurà 10 i no més
     */
    public void getPguanyatspunts() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(temps1, 5, this.p1, null);
        this.pg2 = new PartidaGuanyada(temps2,  7, this.p2, null);
        this.pg3 = new PartidaGuanyada(temps1,  20, this.p1, null);
        this.pg4 = new PartidaGuanyada(temps2,  10, this.p2, null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);
        r.afegirPartida(pg4);
        r.afegirPartida(pg2);
        r.afegirPartida(pg1);
        r.afegirPartida(pg3);
        r.afegirPartida(pg3);
        r.afegirPartida(pg1);

        ArrayList<PartidaGuanyada> array1 = new ArrayList<PartidaGuanyada>(Arrays.asList(pg3, pg3, pg1, pg1, pg1, pg1, pg1, pg1, pg1, pg1));
        ArrayList<PartidaGuanyada> array2 = new ArrayList<PartidaGuanyada>(Arrays.asList(pg4, pg2));
        ArrayList<ArrayList<PartidaGuanyada>> expected = new ArrayList<ArrayList<PartidaGuanyada>>(Arrays.asList(array1, array2));
        assertEquals(expected, r.getPguanyatspunts());
    }

    @Test
    public void getPguanyatstemps() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(temps1, 5, this.p1, null);
        this.pg2 = new PartidaGuanyada(temps2,  7, this.p2, null);
        this.pg3 = new PartidaGuanyada(2L,  4, this.p1, null);
        this.pg4 = new PartidaGuanyada(3L,  10, this.p2, null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg4);
        r.afegirPartida(pg2);
        r.afegirPartida(pg1);
        r.afegirPartida(pg3);

        ArrayList<PartidaGuanyada> array1 = new ArrayList<PartidaGuanyada>(Arrays.asList(pg3, pg1, pg1));
        ArrayList<PartidaGuanyada> array2 = new ArrayList<PartidaGuanyada>(Arrays.asList(pg4, pg2));
        ArrayList<ArrayList<PartidaGuanyada>> expected = new ArrayList<ArrayList<PartidaGuanyada>>(Arrays.asList(array1, array2));
        assertEquals(expected, r.getPguanyatstemps());
    }

    @Test
    public void getTempsglobal() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(4L, 5, this.p1, null);
        this.pg2 = new PartidaGuanyada(5L,  7, this.p2, null);
        this.pg3 = new PartidaGuanyada(2L,  4, this.p1, null);
        this.pg4 = new PartidaGuanyada(3L,  10, this.p2, null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg4);
        r.afegirPartida(pg2);
        r.afegirPartida(pg1);
        r.afegirPartida(pg3);
        r.eliminadeRankings(p1);
        r.afegirPartida(pg3);
        ArrayList<Problema> expected1 = new ArrayList<Problema>(Arrays.asList(p2,p1));
        assertEquals(expected1, r.getProblemesTotals());
        ArrayList<PartidaGuanyada> expected = new ArrayList<PartidaGuanyada>(Arrays.asList(pg3,pg4,pg2));
        assertEquals(expected, r.getTempsglobal());
    }

    @Test
    public void getPuntuacioglobal() {
        Ranking r = new Ranking();
        this.p1 = new Problema();
        p1.setId(1);
        this.p2 = new Problema();
        p2.setId(2);
        this.p3 = new Problema();
        p3.setId(10);
        this.p4 = new Problema();
        p4.setId(11);
        this.temps1 = 3L;
        this.temps2 = 4L;
        this.puntuacio1 = 50;
        this.puntuacio2 = 40;
        this.pg1 = new PartidaGuanyada(4L, 5, this.p1, null);
        this.pg2 = new PartidaGuanyada(5L,  7, this.p2, null);
        this.pg3 = new PartidaGuanyada(2L,  4, this.p3, null);
        this.pg4 = new PartidaGuanyada(3L,  10, this.p4, null);
        r.afegirPartida(pg1);
        r.afegirPartida(pg4);
        r.afegirPartida(pg2);
        r.afegirPartida(pg1);
        r.afegirPartida(pg3);
        r.eliminadeRankings(p4);
        r.eliminadeRankings(p1);
        r.afegirPartida(pg3);
        r.afegirPartida(pg1);
        r.afegirPartida(pg1);

        ArrayList<PartidaGuanyada> expected = new ArrayList<PartidaGuanyada>(Arrays.asList(pg2,pg1,pg1,pg3, pg3));
        assertEquals(expected, r.getPuntuacioglobal());
    }
}

