import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ControladorPresentacioConsultarProblema implements Initializable {

    private Stage st;
    private Integer idUser;

    public ComboBox llista;
    public GridPane graella;
    public Label Labelnumero;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuProblema.fxml").openStream());
        ControladorPresentacioMenuProblema controller = loader.getController();
        controller.setStage(st);

        st.setTitle("Administració de problemes");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            ControladorDomini r = new ControladorDomini();
            ArrayList<Integer> a = r.getIDProblemes();
            llista.getItems().add(0, "Null");
            for(int i = 0; i<a.size(); i++) {
                llista.getItems().add(i+1, a.get(i).toString());
            }
            llista.getSelectionModel().selectFirst();
        }
        catch(IOException a) {
            System.out.println("Error");
        }
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                Node blank = new ImageView(new LocatedImage("Images/blank.png"));
                ((ImageView) blank).setFitHeight(75.);
                ((ImageView) blank).setFitWidth(75.);
                graella.setRowIndex(blank, x);
                graella.setColumnIndex(blank, y);
                graella.getChildren().addAll(blank);
            }
        }
    }

    public void printTaulell(ArrayList<ArrayList<Character>> taulell) {
        for (int x = 0; x < taulell.size(); x++) {
            for (int y = 0; y < taulell.get(0).size(); y++) {
                Node peca = graella.getChildren().get(x*8+y);
                if (taulell.get(x).get(y) == '/') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/blank.png"));
                }
                else if (taulell.get(x).get(y) == 'b') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_bishop.png"));
                }
                else if (taulell.get(x).get(y) == 'k') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_king.png"));
                }
                else if (taulell.get(x).get(y) == 'n') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_knight.png"));
                }
                else if (taulell.get(x).get(y) == 'p') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_pawn.png"));
                }
                else if (taulell.get(x).get(y) == 'q') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_queen.png"));
                }
                else if (taulell.get(x).get(y) == 'r') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_rook.png"));
                }
                else if (taulell.get(x).get(y) == 'B') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_bishop.png"));
                }
                else if (taulell.get(x).get(y) == 'K') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_king.png"));
                }
                else if (taulell.get(x).get(y) == 'N') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_knight.png"));
                }
                else if (taulell.get(x).get(y) == 'P') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_pawn.png"));
                }
                else if (taulell.get(x).get(y) == 'Q') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_queen.png"));
                }
                else if (taulell.get(x).get(y) == 'R') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_rook.png"));
                }
            }
        }
    }

    public void print(ActionEvent event) throws IOException {
        ControladorDomini domainController = new ControladorDomini();
        domainController.getProblema(Integer.parseInt(llista.getValue().toString()));
        printTaulell(domainController.getTaulellProblema());
        Labelnumero.setText("Mat en " + domainController.problema.getMoviments().toString());
    }

}
