import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class ControladorPresentacioException {

    private Stage st;
    private Integer idUser;

    public Button NO;
    public Button YES;
    public Button OK;
    public Button TORNAR;
    public Label LabelGran;
    public Label LabelPetita;

    public void setStage(Stage st) { this.st = st; }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void exit() {
        LabelGran.setText("Estàs segur de que vols sortir de la partida?");
        LabelPetita.setText("(Tot els progresos es perdràn y tornaràs al Menú Principal)");
        NO.setVisible(true);
        YES.setVisible(true);
        OK.setVisible(false);
        TORNAR.setVisible(false);
    }

    public void rankingBuit() {
        LabelGran.setText("El ranking és buit");
        LabelPetita.setText("(Primer s'ha de registrar alguna partida guanyada)");
        NO.setVisible(false);
        YES.setVisible(false);
        OK.setVisible(true);
        TORNAR.setVisible(false);
    }

    public void partidaPerduda() {
        LabelGran.setText("Has perdut la partida");
        LabelPetita.setText("");
        NO.setVisible(false);
        YES.setVisible(false);
        OK.setVisible(false);
        TORNAR.setVisible(true);
    }

    public void unloggedInUser() {
        LabelGran.setText("No s'ha iniciat sessió");
        LabelPetita.setText("(No s'ha guardat la partida al Ranking)");
        NO.setVisible(false);
        YES.setVisible(false);
        OK.setVisible(true);
        TORNAR.setVisible(false);
    }
    public void partidaGuardada() {
        LabelGran.setText("La partida s'ha guardat!");
        LabelPetita.setText("(Pots consultar el Ranking per veure si t'has classificat)");
        NO.setVisible(false);
        YES.setVisible(false);
        OK.setVisible(true);
        TORNAR.setVisible(false);
    }

    public void eliminarUser(boolean correcte) {
        if (correcte) {
            LabelGran.setText("L'usuari s'ha eliminat");
            LabelPetita.setText("(La sessió s'ha tancat)");
        }
        else {
            LabelGran.setText("No hi ha cap sessió iniciada");
            LabelPetita.setText("(Primer s'ha d'iniciar sessió per poder eliminar l'usuari)");
        }
        NO.setVisible(false);
        YES.setVisible(false);
        OK.setVisible(true);
        TORNAR.setVisible(false);
    }

    public void ok(ActionEvent event) {
        Stage stage = (Stage) OK.getScene().getWindow();
        stage.close();
    }

    public void no(ActionEvent event) {
        Stage stage = (Stage) NO.getScene().getWindow();
        stage.close();
    }

    public void yes(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuPrincipal.fxml").openStream());
        ControladorPresentacioMenuPrincipal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(idUser);
        if(idUser != null) controller.setLabelLogIn("Sessió iniciada");

        st.setTitle("MENÚ PRINCIPAL");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());

        Stage stage = (Stage) YES.getScene().getWindow();
        stage.close();

        st.show();
    }

}
