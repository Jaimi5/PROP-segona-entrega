import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ControladorPresentacioIniciaSessio {

    private Integer id;
    private ControladorPresentacioMenuPrincipal controller;

    public void setController(ControladorPresentacioMenuPrincipal ct) { this.controller = ct; }

    public TextField nom;
    public PasswordField contra;
    public Label nomUsu;
    public Label correcte;

    public void logIn(ActionEvent event) throws IOException {
        ControladorDomini c = new ControladorDomini();
        id = c.trobaHumaNC(nom.getText(), contra.getText());
        if(id == null) {
            nomUsu.setText("La informació introduïda no es correcte.");
            controller.setLabelLogIn("");
            controller.setIdUser(id);
        }
        else {
            controller.setLabelLogIn("Sessió iniciada");
            controller.setIdUser(id);
            Stage stage = (Stage) nom.getScene().getWindow();
            stage.close();
        }
    }
}
