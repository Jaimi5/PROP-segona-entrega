import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class ControladorPresentacioJugarPartida implements Initializable {

    private Stage st;
    private Integer idUser;
    private ControladorDomini domainController;
    private Integer PosX;
    private Integer PosY;
    private Integer taulell;
    private Integer tipusPartida;

    public GridPane graella;
    public Label Error;
    public Label LabelTitol;
    public Label LabelTorn;
    public Button ButtonEnrere;
    public Button ButtonEndavant;
    public Button ButtonMenuPrincipal;
    public Button ButtonCalcular;

    public void setStage(Stage stage) {
        this.st = stage;
    }

    public void setDomainController(ControladorDomini domainController) { this.domainController = domainController; }

    public void setTipusPartida(Integer tipusPartida) { this.tipusPartida = tipusPartida; }

    public void setIdUser(Integer id) { this.idUser = id; }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                Node blank = new ImageView(new LocatedImage("Images/blank.png"));
                ((ImageView) blank).setFitHeight(75.);
                ((ImageView) blank).setFitWidth(75.);
                graella.setRowIndex(blank, x);
                graella.setColumnIndex(blank, y);
                graella.getChildren().addAll(blank);
                blank.setOnMouseClicked(this::click);
            }
        }
        ButtonEndavant.setVisible(false);
        ButtonEnrere.setVisible(false);
        ButtonMenuPrincipal.setVisible(false);
        ButtonCalcular.setVisible(false);
    }

    public void disableClicksOnBoard() {
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                Node cell = graella.getChildren().get(x*8+y);
                cell.setOnMouseClicked(null);
            }
        }
    }

    public void MvsM() {
        ButtonCalcular.setVisible(true);
    }

    public void calcularMoviment(ActionEvent event) throws IOException {
        boolean finalPartida = domainController.realitzarMovimentMaquina();
        printTaulell(domainController.getTaulellActual());
        if (finalPartida) {
            if (domainController.guanyada()) {
                LabelTorn.setText("");
                LabelTitol.setText("Mostrar pasos de la partida");
                ButtonCalcular.setVisible(false);
                ButtonEnrere.setVisible(true);
                ButtonEndavant.setVisible(true);
                ButtonMenuPrincipal.setVisible(true);
                taulell = new Integer(0);
                printTaulell(domainController.getTaulellIndex(taulell));
            }
            else {
                FXMLLoader loader = new FXMLLoader();
                Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
                ControladorPresentacioException controller = loader.getController();
                controller.setStage(this.st);
                controller.partidaPerduda();

                Stage st = new Stage();

                st.setTitle("Alerta!");
                Scene scene = new Scene(root, 550, 300);
                st.setScene(scene);
                st.minHeightProperty().bind(scene.heightProperty());
                st.minWidthProperty().bind(scene.heightProperty());
                st.show();
            }
        }
        setLabelTorn();
    }

    public void printTaulell(ArrayList<ArrayList<Character>> taulell) {
        for (int x = 0; x < taulell.size(); x++) {
            for (int y = 0; y < taulell.get(0).size(); y++) {
                Node peca = graella.getChildren().get(x*8+y);
                if (taulell.get(x).get(y) == '/') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/blank.png"));
                }
                else if (taulell.get(x).get(y) == 'b') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_bishop.png"));
                }
                else if (taulell.get(x).get(y) == 'k') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_king.png"));
                }
                else if (taulell.get(x).get(y) == 'n') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_knight.png"));
                }
                else if (taulell.get(x).get(y) == 'p') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_pawn.png"));
                }
                else if (taulell.get(x).get(y) == 'q') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_queen.png"));
                }
                else if (taulell.get(x).get(y) == 'r') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/black_rook.png"));
                }
                else if (taulell.get(x).get(y) == 'B') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_bishop.png"));
                }
                else if (taulell.get(x).get(y) == 'K') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_king.png"));
                }
                else if (taulell.get(x).get(y) == 'N') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_knight.png"));
                }
                else if (taulell.get(x).get(y) == 'P') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_pawn.png"));
                }
                else if (taulell.get(x).get(y) == 'Q') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_queen.png"));
                }
                else if (taulell.get(x).get(y) == 'R') {
                    ((ImageView) peca).setImage(new LocatedImage("Images/white_rook.png"));
                }
            }
        }
    }

    public void setLabelTorn() {
        if (domainController.comprovarTorn()) LabelTorn.setText("TORN: blanques");
        else LabelTorn.setText("TORN: negres");
    }

    public void click(MouseEvent event) {
        Node cell = (Node)event.getTarget();
        Error.setText("");

        if (((LocatedImage)((ImageView) cell).getImage()).getURL().contains("marcar")){//per les caselles marcades (tant si hi ha o no una peça perquè després de realitzarMoviment printejo de nou el taulell).
            ArrayList<Integer> moviment = new ArrayList<>();
            moviment.add(PosX);
            moviment.add(PosY);
            moviment.add(graella.getRowIndex(cell));
            moviment.add(graella.getColumnIndex(cell));
            try {
                boolean finalPartida = domainController.realitzarMoviment(moviment);
                setLabelTorn();
                printTaulell(domainController.getTaulellActual());
                if (finalPartida) {
                    try {
                        if (domainController.guanyada()) { //s'ha acabat guanyant.
                            LabelTorn.setText("");
                            LabelTitol.setText("Mostrar pasos de la partida");
                            ButtonEnrere.setVisible(true);
                            ButtonEndavant.setVisible(true);
                            ButtonMenuPrincipal.setVisible(true);
                            taulell = new Integer(0);
                            printTaulell(domainController.getTaulellIndex(taulell));
                        } else {// s'ha acabat perdent.
                            FXMLLoader loader = new FXMLLoader();
                            Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
                            ControladorPresentacioException controller = loader.getController();
                            controller.setStage(this.st);
                            controller.partidaPerduda();

                            Stage st = new Stage();

                            st.setTitle("Alerta!");
                            Scene scene = new Scene(root, 550, 300);
                            st.setScene(scene);
                            st.minHeightProperty().bind(scene.heightProperty());
                            st.minWidthProperty().bind(scene.heightProperty());
                            st.show();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    if (tipusPartida.equals(1) || tipusPartida.equals(2)) {
                        domainController.realitzarMovimentMaquina();
                        printTaulell(domainController.getTaulellActual());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Error.setText("Moviment il·legal");
            }
        }
        else if (!((LocatedImage)((ImageView) cell).getImage()).getURL().equals("Images/blank.png")) { //per les peces, marcar el seu camí.
            printTaulell(domainController.getTaulellActual());
            if (((LocatedImage)((ImageView) cell).getImage()).getURL().contains("white")) {
                if (domainController.comprovarTorn()) {
                    PosX = new Integer(graella.getRowIndex(cell));
                    PosY = new Integer(graella.getColumnIndex(cell));
                    ArrayList<Pair<Integer,Integer>> cells = domainController.marcarMoviments(PosX, PosY);
                    for (int i = 0; i < cells.size(); i++) {
                        System.out.println(cells.get(i).getKey() + "   " + cells.get(i).getValue());
                        Node square = graella.getChildren().get(cells.get(i).getKey()*8+cells.get(i).getValue());
                        if (((LocatedImage)((ImageView) square).getImage()).getURL().equals("Images/blank.png")) {
                            System.out.println("Hola");
                            ((ImageView) square).setImage(new LocatedImage("Images/marcar.png"));
                        }
                        else { //un per cada peça.
                            String x = ((LocatedImage)((ImageView) square).getImage()).getURL();
                            if (x.equals("Images/black_pawn.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_peo_negre.png"));
                            else if (x.equals("Images/black_king.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_rei_negre.png"));
                            else if (x.equals("Images/black_queen.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_reina_negre.png"));
                            else if (x.equals("Images/black_bishop.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_alfil_negre.png"));
                            else if (x.equals("Images/black_rook.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_torre_negre.png"));
                            else if (x.equals("Images/black_knight.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_cavall_negre.png"));
                        }
                    }
                }
                else Error.setText("La peça no és teva");
            }
            else {
                if (!domainController.comprovarTorn()) {
                    PosX = new Integer(graella.getRowIndex(cell));
                    PosY = new Integer(graella.getColumnIndex(cell));
                    ArrayList<Pair<Integer,Integer>> cells = domainController.marcarMoviments(PosX, PosY);
                    for (int i = 0; i < cells.size(); i++) {
                        System.out.println(cells.get(i).getKey() + "   " + cells.get(i).getValue());
                        Node square = graella.getChildren().get(cells.get(i).getKey()*8+cells.get(i).getValue());
                        if (((LocatedImage)((ImageView) square).getImage()).getURL().equals("Images/blank.png")) {
                            System.out.println("Hola");
                            ((ImageView) square).setImage(new LocatedImage("Images/marcar.png"));
                        }
                        else { //un per cada peça.
                            String x = ((LocatedImage)((ImageView) square).getImage()).getURL();
                            if (x.equals("Images/white_pawn.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_peo_blanc.png"));
                            else if (x.equals("Images/white_king.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_rei_blanc.png"));
                            else if (x.equals("Images/white_queen.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_reina_blanca.png"));
                            else if (x.equals("Images/white_bishop.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_alfil_blanc.png"));
                            else if (x.equals("Images/white_rook.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_torre_blanca.png"));
                            else if (x.equals("Images/white_knight.png")) ((ImageView) square).setImage(new LocatedImage("Images/marcar_cavall_blanc.png"));
                        }
                    }
                }
                else Error.setText("La peça no és teva");
            }
        }
    }

    public void enrere(ActionEvent event) {
        Error.setText("");
        taulell--;
        try {
            printTaulell(domainController.getTaulellIndex(taulell));
        } catch (IndexOutOfBoundsException e) {
            taulell++;
            Error.setText("És el primer taulell");
        }
    }

    public void endavant(ActionEvent event) {
        Error.setText("");
        taulell++;
        try {
            printTaulell(domainController.getTaulellIndex(taulell));
        } catch (IndexOutOfBoundsException e) {
            taulell--;
            Error.setText("És l'últim taulell");
        }
    }

    public void menuPrincipal(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuPrincipal.fxml").openStream());
        ControladorPresentacioMenuPrincipal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(idUser);
        if (idUser != null) controller.setLabelLogIn("Sessió iniciada");

        st.setTitle("MENÚ PRINCIPAL");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());

        st.show();
        try {
            if (tipusPartida < 3) {
                domainController.afegirPG(domainController.getPG());
                partidaGuardada();
            }
        } catch (NullPointerException e) {
            unlogged();
        }
    }

    public void partidaGuardada() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
        ControladorPresentacioException controller = loader.getController();
        controller.setStage(this.st);
        controller.partidaGuardada();

        Stage st = new Stage();

        st.setTitle("Alerta!");
        Scene scene = new Scene(root, 550, 300);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void unlogged() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
        ControladorPresentacioException controller = loader.getController();
        controller.setStage(this.st);
        controller.unloggedInUser();

        Stage st = new Stage();

        st.setTitle("Alerta!");
        Scene scene = new Scene(root, 550, 300);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void keyPressed(KeyEvent key) throws IOException {
        if(key.getCode().equals(KeyCode.ESCAPE)){
            domainController.stopTimers();
            FXMLLoader loader = new FXMLLoader();
            Parent root = loader.load(getClass().getResource("Pausa.fxml").openStream());
            ControladorPresentacioPausa controller = loader.getController();
            controller.setStage(st);
            controller.setIdUser(this.idUser);
            controller.setController(this);
            controller.setDomainController(this.domainController);

            st.setTitle("PAUSA");
            Scene scene = new Scene(root, 900, 700);
            st.setScene(scene);
            st.minHeightProperty().bind(scene.heightProperty());
            st.minWidthProperty().bind(scene.heightProperty());
            st.show();
        }
    }
}
