import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

//TODO: per triar problema no puc posar aquí un Problema, s'ha de trobar una manera per saber com triar el problema des de la capa de Domini.
public class ControladorPresentacioMenuPartida implements Initializable {

    private Stage st;
    private Integer idUser;
    private ControladorDomini domainController = new ControladorDomini();

    public ComboBox ComboBoxModalitat;
    public ComboBox ComboBoxProblema;
    public Button ButtonJugar;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setIdUser(Integer id) { this.idUser = id; }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ComboBoxModalitat.getItems().setAll("Humà vs Humà", "Humà vs Màquina Greedy", "Humà vs Màquina Smart", "MàquinaS vs MàquinaG", "MàquinaG vs MàquinaS", "MàquinaG vs MàquinaG", "MàquinaS vs MàquinaS");
        ComboBoxModalitat.getSelectionModel().selectFirst();
        try {
            ArrayList<Integer> IDs = domainController.getIDProblemes();
            for (int i = 0; i < IDs.size(); i++) {
                ComboBoxProblema.getItems().add(String.valueOf(IDs.get(i)));
            }
            ComboBoxProblema.getSelectionModel().selectFirst();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void jugarPartida(ActionEvent event) throws IOException {
        domainController.getProblema(Integer.parseInt(ComboBoxProblema.getValue().toString()));
        if (idUser != null) domainController.trobaHuma(idUser);
        Integer tipusPartida;
        if (ComboBoxModalitat.getValue().toString().equals("Humà vs Humà")) { domainController.setPartida(0); tipusPartida = new Integer(0); }
        else if (ComboBoxModalitat.getValue().toString().equals("Humà vs Màquina Greedy")) { domainController.setPartida(1); tipusPartida = new Integer(1); }
        else if (ComboBoxModalitat.getValue().toString().equals("Humà vs Màquina Smart")) { domainController.setPartida(2); tipusPartida = new Integer(2); }
        else if (ComboBoxModalitat.getValue().toString().equals("MàquinaS vs MàquinaG")){ domainController.setPartida(3); tipusPartida = new Integer(3); }
        else if (ComboBoxModalitat.getValue().toString().equals("MàquinaG vs MàquinaS")){ domainController.setPartida(4); tipusPartida = new Integer(4); }
        else if (ComboBoxModalitat.getValue().toString().equals("MàquinaG vs MàquinaG")){ domainController.setPartida(5); tipusPartida = new Integer(5); }
        else { domainController.setPartida(6); tipusPartida = new Integer(6); }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JugarPartida.fxml"));
        ControladorPresentacioJugarPartida controllerJugar = new ControladorPresentacioJugarPartida();
        loader.setController(controllerJugar);
        Parent root = loader.load();
        controllerJugar.setStage(st);
        controllerJugar.setDomainController(domainController);
        controllerJugar.setTipusPartida(tipusPartida);
        controllerJugar.setIdUser(this.idUser);

        controllerJugar.printTaulell(domainController.getTaulellActual());
        controllerJugar.setLabelTorn();
        if (tipusPartida > 2) { controllerJugar.disableClicksOnBoard(); controllerJugar.MvsM(); }

        st.setTitle("Jugar");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
        scene.getRoot().requestFocus();
    }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuPrincipal.fxml").openStream());
        ControladorPresentacioMenuPrincipal controller = loader.getController();
        controller.setStage(st);
        if (idUser != null) controller.setLabelLogIn("Sessió iniciada");

        st.setTitle("MENÚ PRINCIPAL");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

}
