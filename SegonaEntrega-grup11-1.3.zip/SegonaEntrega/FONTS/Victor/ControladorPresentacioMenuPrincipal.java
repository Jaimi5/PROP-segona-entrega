import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class ControladorPresentacioMenuPrincipal {

    private Stage st;
    private Integer idUser;
    public Label LabelLogIn;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setLabelLogIn(String text) { LabelLogIn.setText(text); }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void menuPartida(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuPartida.fxml").openStream());
        ControladorPresentacioMenuPartida controllerMenuPartida = loader.getController();
        controllerMenuPartida.setStage(this.st);
        controllerMenuPartida.setIdUser(this.idUser);

        st.setTitle("Menú Partida");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void menuProblema(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuProblema.fxml"));
        Parent root = loader.load();
        ControladorPresentacioMenuProblema controllerProblema = loader.getController();
        controllerProblema.setStage(st);
        controllerProblema.setIdUser(this.idUser);

        st.setTitle("Administració de problemes");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void menuUsuari(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("GestioUsuari.fxml"));
        Parent root = loader.load();

        Stage st = new Stage();

        st.setTitle("Administració d'Usuaris");
        Scene scene = new Scene(root, 500, 300);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void menuLogIn(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("LogIn.fxml"));
        Parent root = loader.load();
        ControladorPresentacioIniciaSessio controller = loader.getController();
        controller.setController(this);

        Stage st = new Stage();

        st.setTitle("Administració d'Usuaris");
        Scene scene = new Scene(root, 500, 300);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void eliminarUsuari(ActionEvent event) throws IOException {
        boolean correcte;
        ControladorDomini domainController = new ControladorDomini();
        if (idUser == null) { correcte = false; }
        else { correcte = true; domainController.eliminaHuma(idUser); }
        idUser = null;
        setLabelLogIn("");

        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
        ControladorPresentacioException controller = loader.getController();
        controller.setStage(this.st);
        controller.eliminarUser(correcte);

        Stage st = new Stage();

        st.setTitle("Alerta!");
        Scene scene = new Scene(root, 550, 300);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void menuRanking(ActionEvent event) throws IOException {
        ControladorDomini domainController = new ControladorDomini();
        domainController.actualitzaRanking();
        if (domainController.rankingBuit()) {
            FXMLLoader loader = new FXMLLoader();
            Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
            ControladorPresentacioException controller = loader.getController();
            controller.setStage(this.st);
            controller.rankingBuit();

            Stage st = new Stage();

            st.setTitle("Alerta!");
            Scene scene = new Scene(root, 550, 300);
            st.setScene(scene);
            st.minHeightProperty().bind(scene.heightProperty());
            st.minWidthProperty().bind(scene.heightProperty());
            st.show();
        }
        else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuRanking.fxml"));
            Parent root = loader.load();
            ControladorPresentacioMenuRanking controllerRanking = loader.getController();
            controllerRanking.setStage(st);
            controllerRanking.setIdUser(this.idUser);

            st.setTitle("Administració de Ranking");
            Scene scene = new Scene(root, 900, 700);
            st.setScene(scene);
            st.minHeightProperty().bind(scene.heightProperty());
            st.minWidthProperty().bind(scene.heightProperty());
            st.show();
        }
    }

}
