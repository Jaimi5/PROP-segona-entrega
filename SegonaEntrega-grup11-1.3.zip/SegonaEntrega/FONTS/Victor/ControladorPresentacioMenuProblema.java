import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
import java.io.IOException;

public class ControladorPresentacioMenuProblema {

    private Stage st;
    private Integer idUser;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void crearProblema(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("CrearProblema.fxml").openStream());
        ControladorPresentacioCrearProblema controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Crear Problema");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void modificarProblema(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("ModificarProblema.fxml").openStream());
        ControladorPresentacioModificarProblema controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Modificar Problema");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void consultarProblema(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("ConsultarProblema.fxml").openStream());
        ControladorPresentacioConsultarProblema controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Consultar Problema");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void eliminarProblema(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("EliminarProblema.fxml").openStream());
        ControladorPresentacioEliminarProblema controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Eliminar Problema");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuPrincipal.fxml").openStream());
        ControladorPresentacioMenuPrincipal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);
        if (idUser != null) controller.setLabelLogIn("Sessió iniciada");

        st.setTitle("MENÚ PRINCIPAL");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

}
