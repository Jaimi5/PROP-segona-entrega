import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ControladorPresentacioMenuRanking {

    private Stage st;
    private Integer idUser;

    public void setStage(Stage st) { this.st = st; }
    public void setIdUser(Integer id) { this.idUser = id; }

    public void menuRankingGlobal(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("RankingGlobal.fxml").openStream());
        ControladorPresentacioRankingGlobal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Ranking Global");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void menuRankingProblema(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("RankingProblema.fxml").openStream());
        ControladorPresentacioRankingProblema controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Ranking per Problema");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("MenuPrincipal.fxml").openStream());
        ControladorPresentacioMenuPrincipal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(idUser);
        if (idUser != null) controller.setLabelLogIn("Sessió iniciada");

        st.setTitle("MENÚ PRINCIPAL");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

}
