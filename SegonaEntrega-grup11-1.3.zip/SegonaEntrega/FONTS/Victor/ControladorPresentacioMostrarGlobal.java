import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class ControladorPresentacioMostrarGlobal {

    private Stage st;
    private Integer idUser;

    public GridPane graella;
    public Label LabelModalitat;


    public void setStage(Stage st) { this.st = st; }
    public void setIdUser(Integer id) { this.idUser = id; }
    public void setLabelModalitat(String text) { LabelModalitat.setText(text); }

    public void setGraella(boolean temps) throws IOException {
        ControladorDomini domainController = new ControladorDomini();
        domainController.actualitzaRanking();
        ArrayList<PartidaGuanyada> llista;
        if (temps) {
            llista = domainController.ranking.getTempsglobal();
            for (int i = 0; i < llista.size(); i++) {
                Node node = new Label();
                ((Label)node).setText(llista.get(i).getUsuariguanyador().getNom());
                ((Label)node).setAlignment(Pos.CENTER);
                ((Label)node).setPrefWidth(233);
                ((Label)node).setPrefHeight(62);
                graella.setRowIndex(node,i+1);
                graella.setColumnIndex(node,1);
                graella.getChildren().addAll(node);

                node = new Label();
                ((Label)node).setText(llista.get(i).getProblema().getId().toString());
                ((Label)node).setAlignment(Pos.CENTER);
                ((Label)node).setPrefWidth(230);
                ((Label)node).setPrefHeight(62);
                graella.setRowIndex(node,i+1);
                graella.setColumnIndex(node,2);
                graella.getChildren().addAll(node);

                node = new Label();
                ((Label)node).setText(llista.get(i).getTemps().toString());
                ((Label)node).setAlignment(Pos.CENTER);
                ((Label)node).setPrefWidth(282);
                ((Label)node).setPrefHeight(62);
                graella.setRowIndex(node,i+1);
                graella.setColumnIndex(node,3);
                graella.getChildren().addAll(node);
            }
        }
        else {
            llista = domainController.ranking.getPuntuacioglobal();
            for (int i = 0; i < llista.size(); i++) {
                Node node = new Label();
                ((Label)node).setText(llista.get(i).getUsuariguanyador().getNom());
                ((Label)node).setAlignment(Pos.CENTER);
                ((Label)node).setPrefWidth(233);
                ((Label)node).setPrefHeight(62);
                graella.setRowIndex(node,i+1);
                graella.setColumnIndex(node,1);
                graella.getChildren().addAll(node);

                node = new Label();
                ((Label)node).setText(llista.get(i).getProblema().getId().toString());
                ((Label)node).setAlignment(Pos.CENTER);
                ((Label)node).setPrefWidth(230);
                ((Label)node).setPrefHeight(62);
                graella.setRowIndex(node,i+1);
                graella.setColumnIndex(node,2);
                graella.getChildren().addAll(node);

                node = new Label();
                ((Label)node).setText(llista.get(i).getPuntuacioguanyador().toString());
                ((Label)node).setAlignment(Pos.CENTER);
                ((Label)node).setPrefWidth(282);
                ((Label)node).setPrefHeight(62);
                graella.setRowIndex(node,i+1);
                graella.setColumnIndex(node,3);
                graella.getChildren().addAll(node);
            }
        }
    }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("RankingGlobal.fxml").openStream());
        ControladorPresentacioRankingGlobal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);

        st.setTitle("Ranking Global");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

}
