import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ControladorPresentacioPausa {

    private Stage st;
    private Integer idUser;
    private ControladorPresentacioJugarPartida controller;
    private ControladorDomini domainController;

    public void setStage(Stage stage) {
        this.st = stage;
    }
    public void setIdUser(Integer id) { this.idUser = id; }
    public void setController(ControladorPresentacioJugarPartida controller) {
        this.controller = controller;
    }
    public void setDomainController(ControladorDomini domainController) { this.domainController = domainController; }

    public void resume(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("JugarPartida.fxml"));
        loader.setController(this.controller);
        Parent root = loader.load();

        controller.setIdUser(this.idUser);
        controller.setDomainController(this.domainController);
        controller.printTaulell(domainController.getTaulellActual());
        domainController.resumeTimers();

        st.setTitle("Jugar");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
        scene.getRoot().requestFocus();
    }

    public void exitWindow(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        Parent root = loader.load(getClass().getResource("exceptionWindow.fxml").openStream());
        ControladorPresentacioException controller = loader.getController();
        controller.setStage(this.st);
        controller.setIdUser(this.idUser);
        controller.exit();

        Stage st = new Stage();

        st.setTitle("Alerta!");
        Scene scene = new Scene(root, 550, 300);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

}
