import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ControladorPresentacioRankingGlobal implements Initializable {

    private Stage st;
    private Integer idUser;

    public ComboBox ComboBoxModalitat;

    public void setStage(Stage st) { this.st = st; }
    public void setIdUser(Integer id) { this.idUser = id; }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ComboBoxModalitat.getItems().setAll("Ranking per temps", "Ranking per punts");
        ComboBoxModalitat.getSelectionModel().selectFirst();
    }

    public void mostrar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MostrarGlobal.fxml"));
        Parent root = loader.load();
        ControladorPresentacioMostrarGlobal controller = loader.getController();
        controller.setStage(st);
        controller.setIdUser(this.idUser);
        if (ComboBoxModalitat.getValue().toString().equals("Ranking per temps")) { controller.setLabelModalitat("Temps"); controller.setGraella(true); }
        else { controller.setLabelModalitat("Punts"); controller.setGraella(false); }

        st.setTitle("Ranking Global");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

    public void tornar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuRanking.fxml"));
        Parent root = loader.load();
        ControladorPresentacioMenuRanking controllerRanking = loader.getController();
        controllerRanking.setStage(st);
        controllerRanking.setIdUser(this.idUser);

        st.setTitle("Administració de Ranking");
        Scene scene = new Scene(root, 900, 700);
        st.setScene(scene);
        st.minHeightProperty().bind(scene.heightProperty());
        st.minWidthProperty().bind(scene.heightProperty());
        st.show();
    }

}
