import javafx.util.Pair;

import java.util.ArrayList;
import java.util.Scanner;

public class DriverHuma {

    public static void testIsMaquina() {
        Usuari u = new Huma(true);
        if (!u.isMaquina()) System.out.println("IsMaquina funciona.");
        else System.out.println("IsMaquina no funciona.");
    }

    public static void testConstructora(Huma h, String input) {
        if (input.equals("1") && h.isAtacant()) System.out.println("la constructora si l'Humà es atacant funciona.");
        else if (input.equals("1") && !h.isAtacant()) System.out.println("la constructora si l'Humà es atacant no funciona.");
        else if (input.equals("2") && !h.isAtacant()) System.out.println("la constructora si l'Humà no es atacant funciona.");
        else if (input.equals("2") && h.isAtacant()) System.out.println("la constructora si l'Humà no es atacant no funciona.");
    }

    public static Taulell introdueixTaulell(){

        Scanner input = new Scanner(System.in);
        Taulell taulell = new Taulell();
        System.out.println("Introdueix un taulell com aquest per exemple:");
        System.out.print("/ / / / / / / /\n" +
                "/ / / / / / K /\n" +
                "/ / / / / / / /\n" +
                "/ / Q / / / / /\n" +
                "/ / / / / R / /\n" +
                "/ n / / / / / /\n" +
                "/ / / p / / / /\n" +
                "k / / / / / b /\n\n");
        ArrayList<ArrayList<Character>> matrix = new ArrayList<>();
        for(int i = 0; i < 8; ++i){
            ArrayList<Character> fila = new ArrayList<>();
            for(int j = 0; j < 8; ++j){
                Character c = input.next().charAt(0);
                fila.add(c);
            }
            matrix.add(fila);
        }
        taulell.inicialitzarTaulell(matrix);
        return taulell;
    }
    private static void imprimeixTaulell(ArrayList<ArrayList<Character>> matrix){
        System.out.printf("\n");
        System.out.println("  0 1 2 3 4 5 6 7");
        for(int i = 0; i < 8; ++i){
            System.out.printf("%c", i+65);
            for(int j = 0; j < 8; ++j){
                System.out.printf(" %s", matrix.get(i).get(j));
            }
            System.out.printf("%n");
        }
    }

    public static boolean testGetmoviment(Huma h) {
        System.out.println("Test de getMoviment. Segueix les intruccions que es demanen.");
        Taulell t = introdueixTaulell();
        imprimeixTaulell(t.getTaulell());
        ArrayList<Integer> moviment = h.getMoviment(t, false, 5);
        Pair<Boolean,Character> correcte = t.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));
        if (correcte.getKey()) {
            t.ferMoviment(moviment);
            System.out.println("El moviment s'ha realitzat correctament:\n");
            imprimeixTaulell(t.getTaulell()); }
        else System.out.println("El moviment no es posible.");
        System.out.println("Vols provar un altre cop? Escriu 1 o 2 si vols o no vols respectivament:");
        Scanner s = new Scanner(System.in);
        int input = s.nextInt();
        if (input == 1) return true;
        else return false;
    }

    public static void main(String args[]) {
        testIsMaquina();

        System.out.println("Test per la contructora:");
        System.out.println("Escriu 1 si vols que l'humà sigui atacant.");
        System.out.println("Escriu 2 si vols que l'humà no sigui atacant.");
        Scanner s = new Scanner(System.in);
        String input = s.next();
        Huma h;
        if (input.equals("1")) h = new Huma(true);
        else h = new Huma(false);
        testConstructora(h,input);

        Huma h1 = new Huma(true);
        boolean continuar = testGetmoviment(h1);
        while (continuar) {
            continuar = testGetmoviment(h1);
        }
    }
}
