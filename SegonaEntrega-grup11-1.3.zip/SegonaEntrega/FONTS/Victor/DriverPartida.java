import java.util.ArrayList;
import java.util.Scanner;

public class DriverPartida {

    public static void testInicialitzarPartida(Partida p, Usuari u1, Usuari u2, Problema prob) {
        System.out.println("Test de inicialitzar partida:");
        p.inicialitzarPartida(u1, u2, prob);
        Taulell t = new Taulell();
        t.inicialitzarTaulell(prob.getMatrix());
        if (p.getUsuari1().equals(u1) && p.getUsuari2().equals(u2) && p.getEstatsTaulell().size() == 1 && p.getMoviments_restants().equals(prob.getMoviments() * 2 - 1)) {
            if (((u1.isAtacant() && p.getTorn_actual()) || (u2.isAtacant() && !p.getTorn_actual()))) System.out.println("Funciona.");
            else System.out.println("No funciona.");
        }
        else System.out.println("No funciona.");
    }

    public static void testGetProblema(Partida partida, Problema p) {
        System.out.println("Test de getProblema:");
        if (partida.getProblema().equals(p)) System.out.println("Funciona.");
        else System.out.println("No funciona.");
    }

    public static void testCanviDeTorn(Partida p, boolean torn, Integer moviments_restants_abans, Long temps1, Long temps2, Long moment_anterior) {
        System.out.println("Test de afegirTempsTranscorregut:");
        p.afegirTempsTranscorregut(true);
        if (torn != p.getTorn_actual() && moviments_restants_abans.equals(p.getMoviments_restants() + 1) && (torn && temps1 < p.getTemps1() || !torn && temps2 < p.getTemps2()) && moment_anterior < p.getMoment_final()) {
            System.out.println("Funciona.");
        }
        else System.out.println("No funciona.");
    }

    public static void testJugar(Partida p) {
        System.out.println("Estat del taulell número 0 (inicial)\n");
        System.out.println("  0 1 2 3 4 5 6 7");
        for (int x = 0; x < p.getTaulell().getTaulell().size(); x++) {
            System.out.printf("%c ", x+65);
            for (int y = 0; y < p.getTaulell().getTaulell().get(x).size(); y++) {
                System.out.print(p.getTaulell().getTaulell().get(x).get(y) + " ");
            }
            System.out.println();
        }
        p.jugar();
        for (int i = 1; i < p.getEstatsTaulell().size(); i++) {
            System.out.println("Estat del taulell número " + i);
            for (int x = 0; x < p.getTaulell().getTaulell().size(); x++) {
                for (int y = 0; y < p.getTaulell().getTaulell().get(x).size(); y++) {
                    System.out.print(p.getTaulell().getTaulell().get(x).get(y) + " ");
                }
                System.out.println();
            }
        }
        System.out.println("Moviments restants de la partida: " + p.getMoviments_restants()/2);
        boolean endGame = p.getPartidaGuanyadora() != null;
        if (endGame) System.out.println("La partida ha acabat per escac i mat");
        else System.out.println("La partida ha acabat per falta de moviments i no per escac i mat.");
        System.out.println("S'ha creat una partida Guanyadora: " + endGame);
    }

    public static void main(String args[]) {
        Usuari u1 = new Huma(true);
        Usuari u2 = new MaquinaGreedy(false);
        Problema prob = new Problema();

        Scanner input = new Scanner(System.in);
        Taulell taulell = new Taulell();
        System.out.println("Introdueix un taulell a jugar com per exemple:");
        System.out.print("/ / / / / / / /\n" +
                "/ / / / / / K /\n" +
                "/ / / / / / / /\n" +
                "/ / Q / / / B /\n" +
                "/ / / / / R / /\n" +
                "/ / / / / / / /\n" +
                "/ / / / p / / /\n" +
                "k / / / / / b /\nExemple de mat per blanques en 2.\n\n");
        ArrayList<ArrayList<Character>> matrix = new ArrayList<>();
        for(int i = 0; i < 8; ++i){
            ArrayList<Character> fila = new ArrayList<>();
            for(int j = 0; j < 8; ++j){
                Character c = input.next().charAt(0);
                fila.add(c);
            }
            matrix.add(fila);
        }
        prob.setMatrix(matrix);
        System.out.println("Defineix el numero de moviments per fer escac:");
        int mov = input.nextInt();
        prob.setMovimentss(mov);

        Partida p = new Partida();

        testInicialitzarPartida(p, u1, u2, prob);
        testGetProblema(p, prob);
        testCanviDeTorn(p, p.getTorn_actual(), p.getMoviments_restants(), p.getTemps1(), p.getTemps2(), p.getMoment_final());

        System.out.println("Per provar la funció de jugar una partida es fa una partida humà vs humà en la que es veu cada moviment i al final es veuen tots els estats vàlids.");
        Partida prova = new Partida();
        Usuari h1 = new Huma(true);
        Usuari h2 = new Huma(false);
        prova.inicialitzarPartida(h1, h2, prob);
        testJugar(prova);
    }
}
