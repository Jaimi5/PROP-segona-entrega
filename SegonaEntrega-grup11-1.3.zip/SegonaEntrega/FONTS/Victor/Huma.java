import java.util.ArrayList;
import java.util.Scanner;

public class Huma extends Usuari {
    private String Nom;
    private String Contrasenya;
    private Integer Id;


    public String getNom() { return Nom; }

    private void setNom(String nom) { Nom = nom; }

    public String getContrasenya() { return Contrasenya; }

    private void setContrasenya(String contrasenya) { Contrasenya = contrasenya; }

    public Integer getId() { return Id; }

    private void setId(Integer id) { Id = id; }

    public boolean isMaquina() { return false; }

    public void setAtacant(Boolean a) { this.atacant = a; }

    public Huma(Boolean a) {
        atacant = a;
    }

    public void setHuma(String n, String c, Integer id) {
        setNom(n);
        setId(id);
        setContrasenya(c);
    }

    //demanar per teclat de moment.
    public ArrayList<Integer> getMoviment(Taulell tActual, Boolean tornNegres, Integer N) {
        System.out.println("Escriu la fila (A-H || a-h) i columna (0-7) de la peça que vols moure i a on la vols moure separat per un guío (-) (Exemple: a0-H7):");
        Scanner s = new Scanner(System.in);
        String moviment = s.next();
        ArrayList<Integer> resultat = new ArrayList<>();

        while (moviment.length() != 5 || !Character.isDigit(moviment.charAt(1)) || !Character.isDigit(moviment.charAt(4)) || !Character.isLetter(moviment.charAt(0)) || !Character.isLetter(moviment.charAt(3)) || moviment.charAt(2) != '-') {
            System.out.println("Format incorrecte, sisplau entra una posició en el format especificat (Exemple: a0-H7):");
            moviment = s.next();
        }

        if (Character.isUpperCase(moviment.charAt(0))) resultat.add(new Integer(moviment.charAt(0) - 65));
        else resultat.add(new Integer(moviment.charAt(0) - 97));

        resultat.add(Character.getNumericValue(moviment.charAt(1)));

        if (Character.isUpperCase(moviment.charAt(3))) resultat.add(new Integer(moviment.charAt(3) - 65));
        else resultat.add(new Integer(moviment.charAt(3) - 97));

        resultat.add(Character.getNumericValue(moviment.charAt(4)));

        while(resultat.get(0) > 7 || resultat.get(1) > 7 || resultat.get(2) > 7 || resultat.get(3) > 7) {
            resultat = new ArrayList<>();
            System.out.println("Aquest moviment no té sentit. Torna-ho a provar:");
            moviment = s.next();

            while (!Character.isDigit(moviment.charAt(1)) || !Character.isDigit(moviment.charAt(4)) || !Character.isLetter(moviment.charAt(0)) || !Character.isLetter(moviment.charAt(3)) || moviment.charAt(2) != '-' || moviment.length() != 5) {
                System.out.println("Format incorrecte, sisplau entra una posició en el format especificat (Exemple: a0-H7):");
                moviment = s.next();
            }

            if (Character.isUpperCase(moviment.charAt(0))) resultat.add(new Integer(moviment.charAt(0) - 65));
            else resultat.add(new Integer(moviment.charAt(0) - 97));

            Integer posicio1 = new Integer(Character.getNumericValue(moviment.charAt(1)));
            resultat.add(posicio1);

            if (Character.isUpperCase(moviment.charAt(3))) resultat.add(new Integer(moviment.charAt(3) - 65));
            else resultat.add(new Integer(moviment.charAt(3) - 97));

            Integer posicio4 = new Integer(Character.getNumericValue(moviment.charAt(4)));
            resultat.add(posicio4);
        }

        return resultat;
    }


}
