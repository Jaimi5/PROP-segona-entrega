import java.util.ArrayList;

public abstract class Maquina extends Usuari{

    public boolean isMaquina() { return true; }

    public ArrayList<Integer> getMoviment(Taulell tActual, Boolean tornNegres, Integer N) {
        ArrayList<Integer> resultat;
        resultat = ferMoviment(tActual, tornNegres, N);
        return resultat;
    }

    abstract ArrayList<Integer> ferMoviment(Taulell tActual, Boolean tornNegres, Integer N);
}
