import javafx.util.Pair;

import java.util.ArrayList;

public class Partida {
    private Usuari usuari1; //blanques.
    private Usuari usuari2; //negres.
    private Problema problema;
    private Taulell taulell;
    private Integer moviments_restants;
    private boolean torn_actual; //true = usuari1 | false = usuari2
    private Long temps1; //temps de partida de l'usuari1 en milisegons
    private Long temps2; //temps de partida de l'usuari2 en milisegons
    private Integer puntuacio1;
    private Integer puntuacio2;
    private Boolean endGame;

    public Long getMoment_final() {
        return moment_final;
    }

    private Long moment_final; //per guardar l'últim moment en el que s'ha delegat el torn a l'usuari1

    public PartidaGuanyada getPartidaGuanyadora() { return partidaGuanyadora; }

    private PartidaGuanyada partidaGuanyadora;

    //AQUI GUARDAR TOTS ELS TAULELLS PERQUE A PARTIDAGUANYADA ES PUGUI FER UNA REPETICIO
    private ArrayList< ArrayList< ArrayList< Character>>> estatsTaulell;



    public void setUsuari1(Usuari u) {
        this.usuari1 = u;
    }

    public void setUsuari2(Usuari u) {
        this.usuari2 = u;
    }

    public void setProblema(Problema p) {
        this.problema = p;
    }

    public void setTorn_actual(Boolean b) { this.torn_actual = b;}

    public void setEndGame(Boolean endGame) { this.endGame = endGame; }

    public Problema getProblema() { return problema; }

    public Boolean getEndGame() { return endGame; }

    public void setMoviments_restants(Integer moviments_restants) {
        this.moviments_restants = moviments_restants;
    }

    //Aquests dos següents només serviran al principi. el parametre serà setMoment_finalX(System.currentTimeMillis())
    public void setMoment_final(Long moment_final) { this.moment_final = moment_final; }

    public Usuari getUsuari1() {
        return usuari1;
    }

    public Usuari getUsuari2() {
        return usuari2;
    }

    public Taulell getTaulell() { return taulell; }

    public Integer getMoviments_restants() {
        return moviments_restants;
    }

    public Boolean getTorn_actual() {
        return torn_actual;
    }

    public Long getTemps1() {
        return temps1;
    }

    public Long getTemps2() {
        return temps2;
    }

    public ArrayList< ArrayList< ArrayList< Character>>> getEstatsTaulell(){ return this.estatsTaulell; }

    private void canviDeTorn() {
        moviments_restants -= 1;
        torn_actual = !torn_actual;
    }

    public void inicialitzarPartida(Usuari u1, Usuari u2, Problema p) {
        usuari1 = u1;
        usuari2 = u2;
        problema = p;
        taulell = new Taulell();
        taulell.inicialitzarTaulell(problema.getMatrix());

        moviments_restants = (problema.getMoviments() * 2) - 1;

        if (usuari1.isAtacant()) torn_actual = true;
        else torn_actual = false;
        temps1 = new Long(0);
        temps2 = new Long(0);
        puntuacio1 = new Integer(0);
        puntuacio2 = new Integer(0);
        moment_final = System.currentTimeMillis();
        estatsTaulell = new ArrayList<>();
        Taulell estatNou = new Taulell(taulell);
        estatsTaulell.add(estatNou.getTaulell());
        endGame = false;
    }

    public ArrayList<Pair <Integer, Integer>> marcarMoviments(Integer PosX, Integer PosY) {
        return taulell.marcarMoviments(PosX, PosY);
    }

    public boolean movimentMaquina() {
        moment_final = System.currentTimeMillis();
        ArrayList<Integer> moviment;
        if (torn_actual) moviment = usuari1.getMoviment(taulell, false, moviments_restants/2 + 1);
        else moviment = usuari2.getMoviment(taulell, true, problema.getMoviments());

        taulell.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));

        Taulell nouEstat = new Taulell(taulell);
        estatsTaulell.add(nouEstat.getTaulell());

        if (taulell.escacImat(usuari2.isAtacant())) endGame = true;

        if (!endGame) afegirTempsTranscorregut(true);

        return (endGame || moviments_restants.equals(0));
    }

    public boolean moviment(ArrayList<Integer> moviment) throws Exception {

        Pair<Boolean, Character> correcte = taulell.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));
        if (!correcte.getKey()) throw new Exception();

        if (correcte.getValue() != '/') {
            Character pecaMorta = correcte.getValue();
            if (pecaMorta == 'K' || pecaMorta == 'k') endGame = true;
            else if (pecaMorta == 'p') puntuacio1 += 5;
            else if (pecaMorta == 'P') puntuacio2 += 5;
            else if (pecaMorta == 'b') puntuacio1 += 15;
            else if (pecaMorta == 'B') puntuacio2 += 15;
            else if (pecaMorta == 'n') puntuacio1 += 20;
            else if (pecaMorta == 'N') puntuacio2 += 20;
            else if (pecaMorta == 'r') puntuacio1 += 30;
            else if (pecaMorta == 'R') puntuacio2 += 30;
            else if (pecaMorta == 'q') puntuacio1 += 50;
            else if (pecaMorta == 'Q') puntuacio2 += 50;
        }

        if (taulell.escacImat(usuari2.isAtacant())) endGame = true;

        Taulell nouEstat = new Taulell(taulell);
        estatsTaulell.add(nouEstat.getTaulell());

        if (endGame) {
            if (!usuari1.isMaquina() && usuari1.isAtacant()) {
                partidaGuanyadora = new PartidaGuanyada(temps1, puntuacio1, problema, (Huma) usuari1);
            }
            else if (!usuari2.isMaquina() && usuari2.isAtacant()) {
                partidaGuanyadora = new PartidaGuanyada(temps2, puntuacio2, problema, (Huma) usuari2);
            }
        }
        else afegirTempsTranscorregut(true);
        return (endGame || moviments_restants.equals(0));
    }

    //mentres no es mori un dels dos reis es seguirà executant el while.

    public void jugar() {
        endGame = false;
        moment_final = System.currentTimeMillis();

        while (!endGame && moviments_restants > 0) {
            if (torn_actual) {
                ArrayList<Integer> moviment = usuari1.getMoviment(taulell, !torn_actual, problema.getMoviments());
                while (!Character.isUpperCase(taulell.getTaulell().get(moviment.get(0)).get(moviment.get(1)))) {
                    System.out.println("Aquesta peça no es teva.");
                    System.out.println(moviment);
                    moviment = usuari1.getMoviment(taulell, !torn_actual, problema.getMoviments());
                }
                Pair<Boolean, Character> correcte = taulell.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));
                if (!usuari1.isMaquina()) {
                    while (correcte.getKey().equals(Boolean.FALSE)) {
                        System.out.println("No es un moviment correcte.");
                        System.out.println(moviment);
                        moviment = usuari1.getMoviment(taulell, !torn_actual, problema.getMoviments());
                        while (!Character.isUpperCase(taulell.getTaulell().get(moviment.get(0)).get(moviment.get(1)))) {
                            System.out.println("Aquesta peça no es teva.");
                            System.out.println(moviment);
                            moviment = usuari1.getMoviment(taulell, !torn_actual, problema.getMoviments());
                        }
                        correcte = taulell.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));
                    }
                    if (correcte.getValue() != '/') {
                        Character pecaMorta = correcte.getValue();
                        if (pecaMorta == 'K' || pecaMorta == 'k') endGame = true;
                        else if (pecaMorta == 'P' || pecaMorta == 'p') puntuacio1 += 5;
                        else if (pecaMorta == 'B' || pecaMorta == 'b') puntuacio1 += 15;
                        else if (pecaMorta == 'N' || pecaMorta == 'n') puntuacio1 += 20;
                        else if (pecaMorta == 'R' || pecaMorta == 'r') puntuacio1 += 30;
                        else if (pecaMorta == 'Q' || pecaMorta == 'q') puntuacio1 += 50;
                    }
                }
                if (taulell.escacImat(usuari2.isAtacant())) endGame = true;
            }
            else {
                ArrayList<Integer> moviment = usuari2.getMoviment(taulell, !torn_actual, problema.getMoviments());
                while (Character.isUpperCase(taulell.getTaulell().get(moviment.get(0)).get(moviment.get(1)))) {
                    System.out.println("Aquesta peça no es teva.");
                    System.out.println(moviment);
                    moviment = usuari1.getMoviment(taulell, !torn_actual, problema.getMoviments());
                }
                Pair<Boolean, Character> correcte = taulell.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));
                if (!usuari2.isMaquina()) {
                    while (correcte.getKey().equals(Boolean.FALSE)) {
                        System.out.println("No es un moviment correcte.");
                        System.out.println(moviment);
                        moviment = usuari2.getMoviment(taulell, !torn_actual, problema.getMoviments());
                        while (Character.isUpperCase(taulell.getTaulell().get(moviment.get(0)).get(moviment.get(1)))) {
                            System.out.println("Aquesta peça no es teva.");
                            System.out.println(moviment);
                            moviment = usuari1.getMoviment(taulell, !torn_actual, problema.getMoviments());
                        }
                        correcte = taulell.movimentPosible(moviment.get(0), moviment.get(1), moviment.get(2), moviment.get(3));
                    }
                    if (correcte.getValue() != '/') {
                        Character pecaMorta = correcte.getValue();
                        if (pecaMorta == 'K' || pecaMorta == 'k') endGame = true;
                        else if (pecaMorta == 'P' || pecaMorta == 'p') puntuacio2 += 5;
                        else if (pecaMorta == 'B' || pecaMorta == 'b') puntuacio2 += 15;
                        else if (pecaMorta == 'N' || pecaMorta == 'n') puntuacio2 += 20;
                        else if (pecaMorta == 'R' || pecaMorta == 'r') puntuacio2 += 30;
                        else if (pecaMorta == 'Q' || pecaMorta == 'q') puntuacio2 += 50;
                    }
                }
                if (taulell.escacImat(usuari2.isAtacant())) endGame = true;
            }
            //actualitzar el taulell si es pot.
            afegirTempsTranscorregut(true);
            Taulell nouEstat = new Taulell(taulell);
            imprimeixTaulell(nouEstat.getTaulell());
            estatsTaulell.add(nouEstat.getTaulell());
        }
        if (endGame) {
            if (torn_actual) {
                if(!usuari2.isMaquina()) partidaGuanyadora = new PartidaGuanyada(temps2,  puntuacio2, problema, null);
            }
            else {
                if(!usuari1.isMaquina()) partidaGuanyadora = new PartidaGuanyada(temps1,  puntuacio1, problema, null);
            }
        }
    }

    //funció per la primera entrega
    private static void imprimeixTaulell(ArrayList<ArrayList<Character>> matrix){
        System.out.printf("\n");
        System.out.println("  0 1 2 3 4 5 6 7");
        for(int i = 0; i < 8; ++i){
            System.out.printf("%c", i+65);
            for(int j = 0; j < 8; ++j){
                System.out.printf(" %s", matrix.get(i).get(j));
            }
            System.out.printf("%n");
        }
    }

    public void afegirTempsTranscorregut(boolean canvi) {
        System.out.println("TPM " + temps1);
        System.out.println("TPM " + moment_final);
        System.out.println("TPM " + System.currentTimeMillis());
        System.out.println("TPM " + (System.currentTimeMillis() - moment_final));
        if (torn_actual) temps1 += System.currentTimeMillis() - moment_final;
        else temps2 += System.currentTimeMillis() - moment_final;
        if (canvi) canviDeTorn();
        moment_final = System.currentTimeMillis();
    }

}
