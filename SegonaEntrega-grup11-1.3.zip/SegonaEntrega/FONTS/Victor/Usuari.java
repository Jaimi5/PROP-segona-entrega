import java.util.ArrayList;

public abstract class Usuari {

    protected boolean atacant;

    //private boolean maquina;

    abstract boolean isMaquina();//abstracte perquè serà a humà i a mquina on sabren si posarlo a true o false.

    //public void setMaquina(boolean maquina) { this.maquina = maquina; }


    // no necesitem setter de id ja que el id un cop creat no s'hauria de modificar (pot portar problemes).
    // Està bé que sigui private i prou.
    //public void setId(Integer id) { this.id = id; }

    //Pos inicial i pos final de la peça que es vol moure.
    abstract ArrayList<Integer> getMoviment(Taulell tActual, Boolean tornNegres, Integer N);//la mecànica es diferent depenent de qui ho implementa: humá pot retornar una posició no posible (partida haurà de comprobar-ho i tornar a demanar).

    public boolean isAtacant() {
        return atacant;
    }

}
